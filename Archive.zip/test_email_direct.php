<?php

require __DIR__ . '/vendor/autoload.php';

$app = require_once __DIR__ . '/bootstrap/app.php';
$app->make('Illuminate\Contracts\Console\Kernel')->bootstrap();

use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Facades\Config;
use Illuminate\Support\Facades\Log;

echo "Testing email configuration...\n";
echo "MAIL_HOST: " . Config::get('mail.mailers.smtp.host') . "\n";
echo "MAIL_PORT: " . Config::get('mail.mailers.smtp.port') . "\n";
echo "MAIL_USERNAME: " . Config::get('mail.mailers.smtp.username') . "\n";
echo "MAIL_FROM: " . Config::get('mail.from.address') . "\n\n";

$testEmail = 'priyanshs042005@gmail.com';

try {
    Mail::raw("This is a test OTP: 1234. If you receive this, email is working correctly!", function ($message) use ($testEmail) {
        $message->to($testEmail)
                ->subject('Test OTP Email - Sports Opinion App');
    });
    
    echo "✓ Email sent successfully to {$testEmail}\n";
    echo "Please check your inbox (and spam folder) at {$testEmail}\n";
} catch (\Throwable $e) {
    echo "✗ Error sending email: " . $e->getMessage() . "\n";
    echo "Stack trace:\n" . $e->getTraceAsString() . "\n";
}
