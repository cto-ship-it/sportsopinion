<?php
require __DIR__ . '/vendor/autoload.php';

$app = require_once __DIR__ . '/bootstrap/app.php';
$app->make('Illuminate\Contracts\Console\Kernel')->bootstrap();

use Illuminate\Support\Facades\Mail;

try {
    Mail::raw('This is a test email from Laravel. If you received this, email configuration is working!', function ($message) {
        $message->to('priyanshs042005@gmail.com')
                ->subject('Laravel Email Test');
    });
    
    echo "✅ Email sent successfully! Check your inbox at priyanshs042005@gmail.com\n";
} catch (Exception $e) {
    echo "❌ Email failed: " . $e->getMessage() . "\n";
}
