# SubSubCategory API Documentation

**Endpoint:** `GET /api/customer/subsubcategories/{subcategoryId}`

Use this endpoint to retrieve a list of active sub-subcategories for a specific subcategory.

## Request

- **Method:** `GET`
- **URL:** `http://<your-domain>/api/customer/subsubcategories/{subcategoryId}`
- **Headers:**
    - `Authorization`: `Bearer <token>` (Required: Customer authentication token)
    - `Accept`: `application/json`
    - `X-Language` or `Accept-Language`: Language code (e.g., `en`, `hi`, `mr`) for translations. Optional. Default is `en`.

## Path Parameters

| Parameter | Type | Description |
| :--- | :--- | :--- |
| `subcategoryId` | `integer` | The ID of the parent subcategory. |

## Response

### Success (200 OK)

```json
{
    "success": true,
    "data": [
        {
            "id": 1,
            "subcategory_id": 10,
            "name": "Specific Topic Name",
            "description": "Description of the topic",
            "status": 1,
            "created_at": "2024-01-07T10:00:00.000000Z",
            "updated_at": "2024-01-07T10:00:00.000000Z"
        },
        {
            "id": 2,
            "subcategory_id": 10,
            "name": "Another Topic",
            "description": null,
            "status": 1,
            "created_at": "2024-01-07T11:00:00.000000Z",
            "updated_at": "2024-01-07T11:00:00.000000Z"
        }
    ],
    "language": "en"
}
```

### Error (500 Internal Server Error)

```json
{
    "success": false,
    "message": "Failed to load sub subcategories",
    "error": "Error details..."
}
```

## Notes

- Only sub-subcategories with `status = 1` (Active) are returned.
- If a language other than `en` is requested, `name` and `description` fields will be translated dynamically if a translation service is configured.
