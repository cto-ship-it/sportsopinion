<?php

return [
    // API Messages
    'success' => 'Succès',
    'error' => 'Erreur',
    'created' => 'Créé avec succès',
    'updated' => 'Mis à jour avec succès',
    'deleted' => 'Supprimé avec succès',
    
    // Authentication
    'login_success' => 'Connexion réussie',
    'login_failed' => 'Identifiants invalides',
    'logout_success' => 'Déconnexion réussie',
    'register_success' => 'Inscription réussie',
    'register_failed' => 'Échec de l\'inscription',
    'unauthorized' => 'Accès non autorisé',
    'token_expired' => 'Le jeton a expiré',
    'token_invalid' => 'Le jeton est invalide',
    
    // User
    'user_not_found' => 'Utilisateur non trouvé',
    'user_created' => 'Utilisateur créé avec succès',
    'user_updated' => 'Utilisateur mis à jour avec succès',
    'user_deleted' => 'Utilisateur supprimé avec succès',
    'email_verified' => 'Email vérifié avec succès',
    'email_already_verified' => 'Email déjà vérifié',
    
    // Questions
    'question_not_found' => 'Question non trouvée',
    'question_created' => 'Question créée avec succès',
    'question_updated' => 'Question mise à jour avec succès',
    'question_deleted' => 'Question supprimée avec succès',
    'question_published' => 'Question publiée avec succès',
    'no_questions_available' => 'Aucune question disponible',
    
    // Answers
    'answer_submitted' => 'Réponse soumise avec succès',
    'answer_updated' => 'Réponse mise à jour avec succès',
    'answer_already_submitted' => 'Vous avez déjà répondu à cette question',
    'invalid_answer' => 'Réponse invalide',
    
    // Validation
    'validation_failed' => 'Échec de la validation',
    'required_field' => 'Ce champ est obligatoire',
    'invalid_email' => 'Adresse email invalide',
    'password_min_length' => 'Le mot de passe doit contenir au moins :min caractères',
    'password_mismatch' => 'Les mots de passe ne correspondent pas',
    
    // General
    'not_found' => 'Ressource non trouvée',
    'server_error' => 'Erreur interne du serveur',
    'forbidden' => 'Accès interdit',
    'too_many_requests' => 'Trop de requêtes',
];
