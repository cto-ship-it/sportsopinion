<?php

return [
    // API Messages
    'success' => 'Success',
    'error' => 'Error',
    'created' => 'Created successfully',
    'updated' => 'Updated successfully',
    'deleted' => 'Deleted successfully',
    
    // Authentication
    'login_success' => 'Login successful',
    'login_failed' => 'Invalid credentials',
    'logout_success' => 'Logout successful',
    'register_success' => 'Registration successful',
    'register_failed' => 'Registration failed',
    'unauthorized' => 'Unauthorised access',
    'token_expired' => 'Token has expired',
    'token_invalid' => 'Token is invalid',
    
    // User
    'user_not_found' => 'User not found',
    'user_created' => 'User created successfully',
    'user_updated' => 'User updated successfully',
    'user_deleted' => 'User deleted successfully',
    'email_verified' => 'Email verified successfully',
    'email_already_verified' => 'Email already verified',
    
    // Questions
    'question_not_found' => 'Question not found',
    'question_created' => 'Question created successfully',
    'question_updated' => 'Question updated successfully',
    'question_deleted' => 'Question deleted successfully',
    'question_published' => 'Question published successfully',
    'no_questions_available' => 'No questions available',
    
    // Answers
    'answer_submitted' => 'Answer submitted successfully',
    'answer_updated' => 'Answer updated successfully',
    'answer_already_submitted' => 'You have already answered this question',
    'invalid_answer' => 'Invalid answer',
    
    // Validation
    'validation_failed' => 'Validation failed',
    'required_field' => 'This field is required',
    'invalid_email' => 'Invalid email address',
    'password_min_length' => 'Password must be at least :min characters',
    'password_mismatch' => 'Passwords do not match',
    
    // General
    'not_found' => 'Resource not found',
    'server_error' => 'Internal server error',
    'forbidden' => 'Access forbidden',
    'too_many_requests' => 'Too many requests',
];
