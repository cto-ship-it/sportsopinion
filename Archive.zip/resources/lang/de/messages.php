<?php

return [
    // API Messages
    'success' => 'Erfolgreich',
    'error' => 'Fehler',
    'created' => 'Erfolgreich erstellt',
    'updated' => 'Erfolgreich aktualisiert',
    'deleted' => 'Erfolgreich gelöscht',
    
    // Authentication
    'login_success' => 'Anmeldung erfolgreich',
    'login_failed' => 'Ungültige Anmeldedaten',
    'logout_success' => 'Abmeldung erfolgreich',
    'register_success' => 'Registrierung erfolgreich',
    'register_failed' => 'Registrierung fehlgeschlagen',
    'unauthorized' => 'Unbefugter Zugriff',
    'token_expired' => 'Token ist abgelaufen',
    'token_invalid' => 'Token ist ungültig',
    
    // User
    'user_not_found' => 'Benutzer nicht gefunden',
    'user_created' => 'Benutzer erfolgreich erstellt',
    'user_updated' => 'Benutzer erfolgreich aktualisiert',
    'user_deleted' => 'Benutzer erfolgreich gelöscht',
    'email_verified' => 'E-Mail erfolgreich verifiziert',
    'email_already_verified' => 'E-Mail bereits verifiziert',
    
    // Questions
    'question_not_found' => 'Frage nicht gefunden',
    'question_created' => 'Frage erfolgreich erstellt',
    'question_updated' => 'Frage erfolgreich aktualisiert',
    'question_deleted' => 'Frage erfolgreich gelöscht',
    'question_published' => 'Frage erfolgreich veröffentlicht',
    'no_questions_available' => 'Keine Fragen verfügbar',
    
    // Answers
    'answer_submitted' => 'Antwort erfolgreich eingereicht',
    'answer_updated' => 'Antwort erfolgreich aktualisiert',
    'answer_already_submitted' => 'Sie haben diese Frage bereits beantwortet',
    'invalid_answer' => 'Ungültige Antwort',
    
    // Validation
    'validation_failed' => 'Validierung fehlgeschlagen',
    'required_field' => 'Dieses Feld ist erforderlich',
    'invalid_email' => 'Ungültige E-Mail-Adresse',
    'password_min_length' => 'Passwort muss mindestens :min Zeichen lang sein',
    'password_mismatch' => 'Passwörter stimmen nicht überein',
    
    // General
    'not_found' => 'Ressource nicht gefunden',
    'server_error' => 'Interner Serverfehler',
    'forbidden' => 'Zugriff verboten',
    'too_many_requests' => 'Zu viele Anfragen',
];
