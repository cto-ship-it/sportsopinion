<?php

return [
    // API Messages
    'success' => 'Успешно',
    'error' => 'Ошибка',
    'created' => 'Успешно создано',
    'updated' => 'Успешно обновлено',
    'deleted' => 'Успешно удалено',
    
    // Authentication
    'login_success' => 'Вход выполнен успешно',
    'login_failed' => 'Неверные учетные данные',
    'logout_success' => 'Выход выполнен успешно',
    'register_success' => 'Регистрация успешна',
    'register_failed' => 'Регистрация не удалась',
    'unauthorized' => 'Несанкционированный доступ',
    'token_expired' => 'Срок действия токена истек',
    'token_invalid' => 'Токен недействителен',
    
    // User
    'user_not_found' => 'Пользователь не найден',
    'user_created' => 'Пользователь успешно создан',
    'user_updated' => 'Пользователь успешно обновлен',
    'user_deleted' => 'Пользователь успешно удален',
    'email_verified' => 'Электронная почта успешно подтверждена',
    'email_already_verified' => 'Электронная почта уже подтверждена',
    
    // Questions
    'question_not_found' => 'Вопрос не найден',
    'question_created' => 'Вопрос успешно создан',
    'question_updated' => 'Вопрос успешно обновлен',
    'question_deleted' => 'Вопрос успешно удален',
    'question_published' => 'Вопрос успешно опубликован',
    'no_questions_available' => 'Вопросы недоступны',
    
    // Answers
    'answer_submitted' => 'Ответ успешно отправлен',
    'answer_updated' => 'Ответ успешно обновлен',
    'answer_already_submitted' => 'Вы уже ответили на этот вопрос',
    'invalid_answer' => 'Неверный ответ',
    
    // Validation
    'validation_failed' => 'Проверка не удалась',
    'required_field' => 'Это поле обязательно',
    'invalid_email' => 'Неверный адрес электронной почты',
    'password_min_length' => 'Пароль должен содержать не менее :min символов',
    'password_mismatch' => 'Пароли не совпадают',
    
    // General
    'not_found' => 'Ресурс не найден',
    'server_error' => 'Внутренняя ошибка сервера',
    'forbidden' => 'Доступ запрещен',
    'too_many_requests' => 'Слишком много запросов',
];
