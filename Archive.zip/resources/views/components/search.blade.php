<div class="col-md-8">
    <form method="GET" action="{{ $action ?? url()->current() }}" class="input-group me-3" style="width: 250px">
        <input
            type="text"
            name="search"
            value="{{ request('search') }}"
            class="form-control form-control-sm"
            placeholder="{{ $placeholder ?? 'Search...' }}"
        />
        <button class="btn btn-sm btn-outline-secondary" type="submit">
            <i class="fas fa-search"></i>
        </button>
    </form>
</div>
