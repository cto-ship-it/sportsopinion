<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Privacy Policy - Sport Opinion</title>
    <link
      href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css"
      rel="stylesheet"
    />
    <link
      href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css"
      rel="stylesheet"
      integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC"
      crossorigin="anonymous"
    />
    <link rel="stylesheet" href="{{ asset('admin/style.css') }}" />
  </head>

  <body>
    {{-- <nav class="navbar navbar-expand-lg navbar-dark fixed-top">
      <div class="container">
        <a class="navbar-brand" href="index.html">
          <img src="" alt="Sport Opinion Logo" />
        </a>
        <button
          class="navbar-toggler"
          type="button"
          data-bs-toggle="collapse"
          data-bs-target="#navbarNav"
          aria-controls="navbarNav"
          aria-expanded="false"
          aria-label="Toggle navigation"
        >
          <span class="navbar-toggler-icon"></span>
        </button>
        <div
          class="collapse navbar-collapse justify-content-end"
          id="navbarNav"
        >
          <ul class="navbar-nav">
            <li class="nav-item">
              <a class="nav-link" href="index.html#about">About Us</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="index.html#features">Features</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="index.html#how-it-works"
                >How It Works</a
              >
            </li>

            <li class="nav-item">
              <a class="nav-link" href="index.html#testimonials"
                >Testimonials</a
              >
            </li>
            <li class="nav-item">
              <a class="nav-link" href="index.html#download">Download</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="index.html#contact">Contact</a>
            </li>
          </ul>
        </div>
      </div>
    </nav> --}}

    <!-- Privacy Policy Content -->
    <section class="content-section">
      <div class="container">
        <h1 class="section-title">Privacy Policy</h1>
        <div class="policy-content">
          <div class="highlight">
            <p>
              <strong
                >At Sports Opinion, we are committed to protecting your privacy
                and ensuring the security of your personal information. This
                Privacy Policy explains how we collect, use, and safeguard your
                data when you use our platform to share sports opinions, predict
                outcomes, earn points, and redeem rewards.</strong
              >
            </p>
          </div>

          <div class="policy-section">
            <h2>1. Information Collection</h2>
            <p>
              We may collect personal information such as your
              <strong>name</strong>, <strong>email address</strong>,
              <strong>phone number</strong> when you sign up or participate in
              polls or predictions.
            </p>
            <p>
              We also collect non-personal information, such as
              <strong>device type</strong>, <strong>browser type</strong>, and
              <strong>IP address</strong>, to analyze usage and improve your app
              experience.
            </p>
            <p>Types of information we collect:</p>
            <ul>
              <li>Contact information (name, email, phone number)</li>
              <li>
                Account activity (poll participation, points earned, rewards
                redeemed)
              </li>
              <li>
                Technical information (IP address, browser type, device
                information)
              </li>
              <li>
                Usage data (pages visited, features used, app interactions)
              </li>
            </ul>
          </div>

          <div class="policy-section">
            <h2>2. Use of Information</h2>
            <p>Your information is used to:</p>
            <ul>
              <li>
                <strong>Provide and manage</strong> the Sports Opinion platform
                and features
              </li>
              <li>
                <strong>Process points and rewards</strong> earned through
                sports predictions and opinions
              </li>
              <li>
                <strong>Communicate updates</strong>, new polls, promotional
                offers, and app notifications
              </li>
              <li>Enhance platform experience and ensure fair participation</li>
              <li>Analyze usage to improve features and fan engagement</li>
            </ul>
            <p>
              We do not sell, trade, or share your personal information with
              third parties without consent, except as required by law or to
              operate our platform (e.g., processing rewards through third-party
              payment services).
            </p>
          </div>

          <div class="policy-section">
            <h2>3. Data Security</h2>
            <p>
              We implement
              <strong>industry-standard security measures</strong> to protect
              your data from unauthorized access, alteration, or disclosure.
              Measures include:
            </p>
            <ul>
              <li>Encryption of sensitive data</li>
              <li>Secure server infrastructure</li>
              <li>Regular security assessments</li>
              <li>Access controls and authentication protocols</li>
            </ul>
            <p>
              While we strive to protect your data, no system is completely
              secure. Please take precautions to protect your account and
              personal information.
            </p>
          </div>

          <div class="policy-section">
            <h2>4. Cookies</h2>
            <p>
              Our website and app may use <strong>cookies</strong> to enhance
              your experience. Cookies help us:
            </p>
            <ul>
              <li>Remember your login and preferences</li>
              <li>Analyze fan engagement and interactions</li>
              <li>Personalize polls and sports recommendations</li>
              <li>Improve features and overall app performance</li>
            </ul>
            <p>
              You can disable cookies in your browser, but this may affect
              functionality. By using Sports Opinion, you consent to our use of
              cookies as described here.
            </p>
          </div>

          <div class="policy-section">
            <h2>5. Your Rights</h2>
            <p>You have the right to:</p>
            <ul>
              <li>
                <strong>Access</strong> the personal information we hold about
                you
              </li>
              <li><strong>Update</strong> or correct inaccurate information</li>
              <li>
                <strong>Delete</strong> your personal information, subject to
                legal obligations
              </li>
              <li>Object to or restrict certain processing activities</li>
              <li>Receive your data in a portable format</li>
            </ul>
            <p>
              To exercise these rights, please contact us at
              <strong>info.startup2025@gmail.com</strong>. We will respond
              within 30 days.
            </p>
          </div>

          <div class="policy-section">
            <h2>6. Data Retention</h2>
            <p>
              We retain personal information only as long as necessary to
              operate Sports Opinion, manage accounts, and process rewards,
              unless a longer period is required by law.
            </p>
            <p>Factors considered include:</p>
            <ul>
              <li>Your account activity and engagement</li>
              <li>Legal obligations</li>
              <li>Operational needs and system maintenance</li>
            </ul>
          </div>

          <div class="policy-section">
            <h2>7. Policy Updates</h2>
            <p>
              We may update this Privacy Policy to reflect changes in our
              practices or legal requirements. Updates will be posted here, and
              continued use constitutes acceptance.
            </p>
            <p>
              Material changes will be communicated via in-app notifications or
              email when appropriate.
            </p>
          </div>

          <div class="policy-section">
            <h2>8. Contact Information</h2>
            <p>
              If you have questions about this Privacy Policy or our data
              practices, contact us:
            </p>
            <ul>
              <li><strong>Email:</strong> info.startup2025@gmail.com</li>
              <li><strong>Phone:</strong> +91 870 868 0041</li>
              <li><strong>Address:</strong> Hisar, Haryana, India</li>
            </ul>
            <p>
              We take privacy seriously and will respond promptly to your
              inquiries.
            </p>
          </div>

          <div class="highlight">
            <p><strong>Last updated:</strong> October 13, 2025</p>
            <p>
              We encourage you to review this policy regularly to stay informed
              about how we protect your information while using Sports Opinion.
            </p>
          </div>
        </div>
      </div>
    </section>

    <footer id="contact" class="footer py-5">
      <div class="container overflow-x-hidden">
        <div class="row g-4">
          <div class="col-md-6 col-lg-3">
            <h5 class="fw-bold text-white mb-3">Sports Opinion</h5>
            <p class="footer-nav">
              A dynamic platform where every fan’s voice matters. Share your
              sports opinions, predict match outcomes, earn points for winning
              takes, and redeem exciting rewards — all in one fun and engaging
              app.
            </p>

            <div class="social-links mt-3">
              <a
                href="https://www.facebook.com/profile.php?id=61582237433267"
                target="_blank"
                aria-label="Facebook"
                ><i class="fab fa-facebook-f"></i
              ></a>
              <a href="#" aria-label="Instagram"
                ><i class="fab fa-instagram"></i
              ></a>
            </div>
          </div>

          <div class="col-md-6 col-lg-9">
            <div class="row g-2">
              <!-- smaller gap only for these three columns -->
              <div class="col-md-3">
                <h5 class="fw-bold text-white mb-3">Quick Links</h5>
                <ul class="list-unstyled">
                  <li>
                    <a href="#about" class="text-decoration-none footer-nav"
                      >About Us</a
                    >
                  </li>
                  <li>
                    <a href="#features" class="text-decoration-none footer-nav"
                      >Features</a
                    >
                  </li>
                  <li>
                    <a
                      href="#how-it-works"
                      class="text-decoration-none footer-nav"
                      >How It Works</a
                    >
                  </li>
                  <li>
                    <a
                      href="#testimonials"
                      class="text-decoration-none footer-nav"
                      >Testimonials</a
                    >
                  </li>
                </ul>
              </div>

              <div class="col-md-4">
                <h5 class="fw-bold text-white mb-3">Legal</h5>
                <ul class="list-unstyled">
                  <li>
                    <a href="terms.html" class="text-decoration-none footer-nav"
                      >Terms and Conditions</a
                    >
                  </li>
                  <li>
                    <a
                      href="{{ route('website.privacy') }}"
                      class="text-decoration-none footer-nav"
                      >Privacy Policy</a
                    >
                  </li>
                </ul>
              </div>

              <div class="col-md-5">
                <h5 class="fw-bold text-white mb-3">Contact Us</h5>
                <ul class="list-unstyled">
                  <li>
                    <i class="fa-solid fa-envelope me-2"></i>
                    <a
                      href="mailto:info.startup2025@gmail.com"
                      class="footer-nav text-decoration-none"
                      >Email: info.startup2025@gmail.com
                    </a>
                  </li>
                  <li>
                    <i class="fa-solid fa-phone me-2"></i>
                    <a
                      href="tel:+918708680041"
                      class="footer-nav text-decoration-none"
                    >
                      Phone: +91 870 868 0041
                    </a>
                  </li>
                  <li>
                    <i class="fa-solid fa-map-pin me-2"></i>
                    <span class="footer-nav text-decoration-none">
                      Address: Hisar, Haryana, India
                    </span>
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </div>

        <hr class="mt-5" />
        <div class="text-center pt-3">
          <p class="text-white mb-0">
            &copy; 2025 Harbhala Enterprises. All rights reserved | Created by
            <a
              href="https://bmdu.net/"
              target="_blank"
              style="text-decoration: none; color: inherit"
              >BMDU</a
            >.
          </p>
        </div>
      </div>
    </footer>

    <script
      src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"
      integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM"
      crossorigin="anonymous"
    ></script>
    <script src="{{ asset('admin/script.js') }}"></script>
  </body>
</html>
