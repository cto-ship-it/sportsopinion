<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Terms and Conditions - Sport Opinion</title>
    <link
      href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css"
      rel="stylesheet"
    />
    <link
      href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css"
      rel="stylesheet"
      integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC"
      crossorigin="anonymous"
    />
    <link rel="stylesheet" href="{{ asset('website/style.css') }}" />
  </head>

  <body>
    <nav class="navbar navbar-expand-lg navbar-dark fixed-top">
      <div class="container">
        <a class="navbar-brand" href="index.html">
          <img src="{{ asset('images/logo.png') }}" alt="Sport Opinion Logo" />
        </a>
        <button
          class="navbar-toggler"
          type="button"
          data-bs-toggle="collapse"
          data-bs-target="#navbarNav"
          aria-controls="navbarNav"
          aria-expanded="false"
          aria-label="Toggle navigation"
        >
          <span class="navbar-toggler-icon"></span>
        </button>
        <div
          class="collapse navbar-collapse justify-content-end"
          id="navbarNav"
        >
          <ul class="navbar-nav">
            <li class="nav-item">
              <a class="nav-link" href="index.html#about">About Us</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="index.html#features">Features</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="index.html#how-it-works"
                >How It Works</a
              >
            </li>

            <li class="nav-item">
              <a class="nav-link" href="index.html#testimonials"
                >Testimonials</a
              >
            </li>
            <li class="nav-item">
              <a class="nav-link" href="index.html#download">Download</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="index.html#contact">Contact</a>
            </li>
          </ul>
        </div>
      </div>
    </nav>

    <!-- Terms and Conditions Content -->
    <section class="content-section">
      <div class="container">
        <h1 class="section-title">Terms and Conditions</h1>
        <div class="terms-content">
          <div class="highlight">
            <p>
              <strong>Welcome to Sports Opinion.</strong> By accessing and using
              our platform, you agree to comply with and be bound by the
              following terms and conditions. Please read them carefully.
            </p>
          </div>

          <div class="terms-section">
            <h2>1. Use of Platform</h2>
            <p>
              This platform is intended for sharing sports opinions,
              participating in polls, predicting match outcomes, and earning
              points and rewards. Unauthorized or improper use may result in
              account suspension or termination.
            </p>
            <p>
              You agree to use Sports Opinion only for lawful purposes and in a
              way that does not infringe the rights of others or disrupt the
              platform's functionality.
            </p>
          </div>

          <div class="terms-section">
            <h2>2. Intellectual Property</h2>
            <p>
              All content on the platform, including text, graphics, logos, and
              software, is the property of Sports Opinion and protected by
              intellectual property laws. Unauthorized reproduction or
              distribution is strictly prohibited.
            </p>
            <p>
              The Sports Opinion name, logo, and all related product and service
              names are trademarks of Sports Opinion. You may not use these
              trademarks without prior written permission.
            </p>
          </div>

          <div class="terms-section">
            <h2>3. Participation and Rewards</h2>
            <p>
              Users may participate in polls, share opinions, and earn points
              and rewards according to the platform’s rules. Sports Opinion
              reserves the right to modify, suspend, or discontinue any poll,
              reward, or points system without prior notice.
            </p>
            <p>
              All points and rewards are subject to verification and may be
              adjusted or revoked in cases of fraud, misuse, or rule violations.
            </p>
          </div>

          <div class="terms-section">
            <h2>4. Limitation of Liability</h2>
            <p>
              Sports Opinion shall not be liable for any indirect, incidental,
              or consequential damages arising from your use of the platform,
              including loss of points or rewards. We do not guarantee the
              accuracy of poll results, match predictions, or the outcome of any
              reward system.
            </p>
          </div>

          <div class="terms-section">
            <h2>5. Governing Law</h2>
            <p>
              These terms and conditions are governed by the laws of India. Any
              disputes will be subject to the exclusive jurisdiction of the
              courts in Hisar, Haryana, India.
            </p>
          </div>

          <div class="terms-section">
            <h2>6. Amendments</h2>
            <p>
              Sports Opinion reserves the right to update or modify these terms
              and conditions at any time without prior notice. Continued use of
              the platform constitutes acceptance of the revised terms.
            </p>
            <p>
              You are expected to check this page periodically to take notice of
              any changes, as they are binding on you.
            </p>
          </div>

          <div class="terms-section">
            <h2>7. User Accounts</h2>
            <p>
              If you create an account on Sports Opinion, you are responsible
              for maintaining the confidentiality of your account and password.
              You agree to accept responsibility for all activities that occur
              under your account or password.
            </p>
          </div>

          <div class="terms-section">
            <h2>8. Links to Other Websites</h2>
            <p>
              Sports Opinion may contain links to third-party websites or
              services. We do not control these sites and are not responsible
              for their content, privacy practices, or security. Users are
              encouraged to review the privacy policies of any external
              websites.
            </p>
          </div>

          <div class="terms-section">
            <h2>9. Termination</h2>
            <p>
              Sports Opinion may suspend or terminate your account or access to
              the platform at any time, without prior notice or liability, for
              violations of these Terms, fraudulent activity, or misuse of
              points and rewards.
            </p>
          </div>

          <div class="terms-section">
            <h2>10. Contact Information</h2>
            <p>
              If you have any questions about these Terms and Conditions, please
              contact us at:
            </p>
            <ul>
              <li><strong>Email:</strong> info.startup2025@gmail.com</li>
              <li><strong>Phone:</strong> +91 870 868 0041</li>
              <li><strong>Address:</strong> Hisar, Haryana, India</li>
            </ul>
          </div>

          <div class="highlight">
            <p><strong>Last updated:</strong> October 13, 2025</p>
            <p>
              These terms and conditions were last updated on the date indicated
              above. Any future changes will be posted on this page.
            </p>
          </div>
        </div>
      </div>
    </section>

    <footer id="contact" class="footer py-5">
      <div class="container overflow-x-hidden">
        <div class="row g-4">
          <div class="col-md-6 col-lg-3">
            <h5 class="fw-bold text-white mb-3">Sports Opinion</h5>
            <p class="footer-nav">
              A dynamic platform where every fan’s voice matters. Share your
              sports opinions, predict match outcomes, earn points for winning
              takes, and redeem exciting rewards — all in one fun and engaging
              app.
            </p>

            <div class="social-links mt-3">
              <a
                href="https://www.facebook.com/profile.php?id=61582237433267"
                target="_blank"
                aria-label="Facebook"
                ><i class="fab fa-facebook-f"></i
              ></a>
              <a href="#" aria-label="Instagram"
                ><i class="fab fa-instagram"></i
              ></a>
            </div>
          </div>

          <div class="col-md-6 col-lg-9">
            <div class="row g-2">
              <!-- smaller gap only for these three columns -->
              <div class="col-md-3">
                <h5 class="fw-bold text-white mb-3">Quick Links</h5>
                <ul class="list-unstyled">
                  <li>
                    <a href="#about" class="text-decoration-none footer-nav"
                      >About Us</a
                    >
                  </li>
                  <li>
                    <a href="#features" class="text-decoration-none footer-nav"
                      >Features</a
                    >
                  </li>
                  <li>
                    <a
                      href="#how-it-works"
                      class="text-decoration-none footer-nav"
                      >How It Works</a
                    >
                  </li>
                  <li>
                    <a
                      href="#testimonials"
                      class="text-decoration-none footer-nav"
                      >Testimonials</a
                    >
                  </li>
                </ul>
              </div>

              <div class="col-md-4">
                <h5 class="fw-bold text-white mb-3">Legal</h5>
                <ul class="list-unstyled">
                  <li>
                    <a href="terms.html" class="text-decoration-none footer-nav"
                      >Terms and Conditions</a
                    >
                  </li>
                  <li>
                    <a
                      href="privacy.html"
                      class="text-decoration-none footer-nav"
                      >Privacy Policy</a
                    >
                  </li>
                </ul>
              </div>

              <div class="col-md-5">
                <h5 class="fw-bold text-white mb-3">Contact Us</h5>
                <ul class="list-unstyled">
                  <li>
                    <i class="fa-solid fa-envelope me-2"></i>
                    <a
                      href="mailto:info.startup2025@gmail.com"
                      class="footer-nav text-decoration-none"
                      >Email: info.startup2025@gmail.com
                    </a>
                  </li>
                  <li>
                    <i class="fa-solid fa-phone me-2"></i>
                    <a
                      href="tel:+918708680041"
                      class="footer-nav text-decoration-none"
                    >
                      Phone: +91 870 868 0041
                    </a>
                  </li>
                  <li>
                    <i class="fa-solid fa-map-pin me-2"></i>
                    <span class="footer-nav text-decoration-none">
                      Address: Hisar, Haryana, India
                    </span>
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </div>

        <hr class="mt-5" />
        <div class="text-center pt-3">
          <p class="text-white mb-0">
            &copy; 2025 Harbhala Enterprises. All rights reserved | Created by
            <a
              href="https://bmdu.net/"
              target="_blank"
              style="text-decoration: none; color: inherit"
              >BMDU</a
            >.
          </p>
        </div>
      </div>
    </footer>
    <script
      src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"
      integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM"
      crossorigin="anonymous"
    ></script>
    <script src="{{ asset('website/script.js') }}"></script>
  </body>
</html>
