@extends('admin.layouts.master')

@section('title', 'Categories')

@section('content')

<!-- Categories Page -->
<div id="categories-page" class="page-content">
    <div class="page-header justify-content-between">
        <!-- Breadcrumb Navigation -->
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb">
                <li class="breadcrumb-item active" aria-current="page">
                    Categories
                </li>
            </ol>
        </nav>

        <h4 class="page-title">Category Management</h4>

        <button
            type="button"
            class="btn bg-info text-white"
            data-bs-toggle="modal"
            data-bs-target="#addCategoryModal"
        >
            <i class="fas fa-plus me-2"></i> Add Category
        </button>
    </div>

    <div class="card">
        <div class="card-body">
            <div class="row g-3 align-items-center">
                <!-- Search Bar -->
                <x-search :action="route('categories.index')" placeholder="Search categories..." />

                <!-- Export Button / Filter Button -->
                <div class="col-md-4">
                    <div class="d-flex justify-content-end gap-2">
                        <button class="btn btn-outline-secondary" id="resetFilters">
                            <i class="fas fa-sync-alt"></i>
                        </button>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="card">
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-hover" id="categoriesTable">
                    <thead>
                        <tr>
                            <th class="text-center">Sr.No.</th>
                            <th class="text-center">Date</th>
                            <th class="text-center">Image</th>
                            <th class="text-center">Name</th>
                            <th class="text-center">Description</th>
                            <th class="text-center">Status</th>
                            <th class="text-center">Edit / Delete</th>
                        </tr>
                    </thead>
                    <tbody>
                        @forelse($categories as $key => $category)
                        <tr>
                            <td class="text-center">{{ $key + 1 }}</td>
                            <td class="text-center">{{ $category->created_at ? $category->created_at->format('d M Y') : 'N/A' }}</td>
                            <td class="text-center">
                                @if($category->image)
                                    <img src="{{ asset('storage/' . $category->image) }}" alt="{{ $category->name }}" class="img-thumbnail" style="max-width: 60px; max-height: 60px;">
                                @else
                                    <span class="text-muted">No Image</span>
                                @endif
                            </td>
                            <td class="text-center">{{ $category->name }}</td>
                            <td class="text-center">{{ Str::limit($category->description, 50) }}</td>
                            <td class="text-center">
                                <span class="badge bg-{{ $category->status ? 'success' : 'secondary' }}">
                                    {{ $category->status ? 'Active' : 'Inactive' }}
                                </span>
                            </td>

                            <td class="text-center">
                                <!-- Edit Button -->
                                <button
                                    type="button"
                                    class="btn btn-sm btn-warning me-1 edit-category-btn"
                                    data-bs-toggle="modal"
                                    data-bs-target="#editCategoryModal"
                                    data-category-id="{{ $category->id }}"
                                    data-category-name="{{ $category->name }}"
                                    data-category-description="{{ $category->description }}"
                                    data-category-status="{{ $category->status }}"
                                    data-category-image="{{ $category->image }}"
                                >
                                    <i class="fas fa-edit me-1"></i> Edit
                                </button>

                                <!-- Delete Button -->
                                <form action="{{ route('categories.destroy', $category->id) }}" method="POST" class="d-inline">
                                    @csrf
                                    @method('DELETE')
                                    <button type="submit" class="btn btn-sm btn-danger" onclick="return confirm('Are you sure you want to delete this category?')">
                                        <i class="fas fa-trash me-1"></i> Delete
                                    </button>
                                </form>
                            </td>
                        </tr>
                        @empty
                        <tr>
                            <td colspan="7" class="text-center">No categories found.</td>
                        </tr>
                        @endforelse
                    </tbody>
                </table>
            </div>
            <!-- PAGINATION -->
            @if(isset($categories) && $categories->hasPages())
                @include('admin.layouts.pagination', ['paginator' => $categories])
            @endif
        </div>
    </div>
</div>

<!-- Add Category Modal -->
<div class="modal fade" id="addCategoryModal" tabindex="-1" aria-labelledby="addCategoryModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-md">
        <div class="modal-content">
            <div class="modal-header bg-primary text-white">
                <h5 class="modal-title" id="addCategoryModalLabel">Add Category</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>

            <div class="modal-body">
                <form id="addCategoryForm" method="POST" action="{{ route('categories.store') }}" enctype="multipart/form-data">
                    @csrf

                    <!-- Name -->
                    <div class="mb-3">
                        <label for="categoryName" class="form-label">Name</label>
                        <input
                            type="text"
                            name="name"
                            class="form-control"
                            id="categoryName"
                            placeholder="Enter category name"
                            value="{{ old('name') }}"
                            required
                        />
                        @error('name')
                        <span class="text-danger">{{ $message }}</span>
                        @enderror
                    </div>

                    <!-- Description -->
                    <div class="mb-3">
                        <label for="categoryDescription" class="form-label">Description</label>
                        <textarea
                            name="description"
                            class="form-control"
                            id="categoryDescription"
                            rows="3"
                            placeholder="Enter category description"
                        >{{ old('description') }}</textarea>
                        @error('description')
                        <span class="text-danger">{{ $message }}</span>
                        @enderror
                    </div>

                    <!-- Image -->
                    <div class="mb-3">
                        <label for="categoryImage" class="form-label">Image</label>
                        <input
                            type="file"
                            name="image"
                            class="form-control"
                            id="categoryImage"
                            accept="image/*"
                        />
                        <div class="form-text">Upload a category image (JPEG, PNG, JPG, GIF)</div>
                        @error('image')
                        <span class="text-danger">{{ $message }}</span>
                        @enderror
                    </div>

                    <!-- Image Preview -->
                    <div class="mb-3 d-none" id="imagePreviewContainer">
                        <label class="form-label">Image Preview</label>
                        <div>
                            <img id="imagePreview" src="#" alt="Image Preview" class="img-thumbnail" style="max-width: 200px; max-height: 200px;">
                        </div>
                    </div>

                    <!-- Status -->
                    <div class="mb-3">
                        <label class="form-label">Status</label>
                        <div>
                            <div class="form-check form-check-inline">
                                <input class="form-check-input" type="radio" name="status" id="statusActive" value="1" checked>
                                <label class="form-check-label" for="statusActive">Active</label>
                            </div>
                            <div class="form-check form-check-inline">
                                <input class="form-check-input" type="radio" name="status" id="statusInactive" value="0">
                                <label class="form-check-label" for="statusInactive">Inactive</label>
                            </div>
                        </div>
                        @error('status')
                        <span class="text-danger">{{ $message }}</span>
                        @enderror
                    </div>
                </form>
            </div>

            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">
                    Cancel
                </button>
                <button type="submit" class="btn btn-primary" form="addCategoryForm">
                    <i class="fas fa-plus me-2"></i> Add Category
                </button>
            </div>
        </div>
    </div>
</div>

<!-- Edit Category Modal -->
<div class="modal fade" id="editCategoryModal" tabindex="-1" aria-labelledby="editCategoryModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-md">
        <div class="modal-content">
            <div class="modal-header bg-warning text-white">
                <h5 class="modal-title" id="editCategoryModalLabel">Edit Category</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>

            <div class="modal-body">
                <form id="editCategoryForm" method="POST" action="" enctype="multipart/form-data">
                    @csrf
                    @method('PUT')

                    <!-- Name -->
                    <div class="mb-3">
                        <label for="editCategoryName" class="form-label">Name</label>
                        <input
                            type="text"
                            name="name"
                            class="form-control"
                            id="editCategoryName"
                            required
                        />
                    </div>

                    <!-- Description -->
                    <div class="mb-3">
                        <label for="editCategoryDescription" class="form-label">Description</label>
                        <textarea
                            name="description"
                            class="form-control"
                            id="editCategoryDescription"
                            rows="3"
                        ></textarea>
                    </div>

                    <!-- Current Image -->
                    <div class="mb-3" id="currentImageContainer">
                        <label class="form-label">Current Image</label>
                        <div>
                            <img id="currentCategoryImage" src="" alt="Current Image" class="img-thumbnail" style="max-width: 200px; max-height: 200px;">
                            <div class="form-text">Current category image</div>
                        </div>
                    </div>

                    <!-- New Image -->
                    <div class="mb-3">
                        <label for="editCategoryImage" class="form-label">Change Image (Optional)</label>
                        <input
                            type="file"
                            name="image"
                            class="form-control"
                            id="editCategoryImage"
                            accept="image/*"
                        />
                        <div class="form-text">Leave empty to keep current image</div>
                    </div>

                    <!-- New Image Preview -->
                    <div class="mb-3 d-none" id="editImagePreviewContainer">
                        <label class="form-label">New Image Preview</label>
                        <div>
                            <img id="editImagePreview" src="#" alt="New Image Preview" class="img-thumbnail" style="max-width: 200px; max-height: 200px;">
                        </div>
                    </div>

                    <!-- Status -->
                    <div class="mb-3">
                        <label class="form-label">Status</label>
                        <div>
                            <div class="form-check form-check-inline">
                                <input class="form-check-input" type="radio" name="status" id="editStatusActive" value="1">
                                <label class="form-check-label" for="editStatusActive">Active</label>
                            </div>
                            <div class="form-check form-check-inline">
                                <input class="form-check-input" type="radio" name="status" id="editStatusInactive" value="0">
                                <label class="form-check-label" for="editStatusInactive">Inactive</label>
                            </div>
                        </div>
                    </div>
                </form>
            </div>

            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                <button type="submit" class="btn btn-warning text-white" form="editCategoryForm">
                    <i class="fas fa-edit me-2"></i> Update Category
                </button>
            </div>
        </div>
    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function () {
    // Image preview for add modal
    const categoryImageInput = document.getElementById('categoryImage');
    const imagePreviewContainer = document.getElementById('imagePreviewContainer');
    const imagePreview = document.getElementById('imagePreview');
    
    if (categoryImageInput) {
        categoryImageInput.addEventListener('change', function() {
            const file = this.files[0];
            if (file) {
                const reader = new FileReader();
                reader.onload = function(e) {
                    imagePreview.src = e.target.result;
                    imagePreviewContainer.classList.remove('d-none');
                }
                reader.readAsDataURL(file);
            } else {
                imagePreviewContainer.classList.add('d-none');
            }
        });
    }

    // Image preview for edit modal
    const editCategoryImageInput = document.getElementById('editCategoryImage');
    const editImagePreviewContainer = document.getElementById('editImagePreviewContainer');
    const editImagePreview = document.getElementById('editImagePreview');
    
    if (editCategoryImageInput) {
        editCategoryImageInput.addEventListener('change', function() {
            const file = this.files[0];
            if (file) {
                const reader = new FileReader();
                reader.onload = function(e) {
                    editImagePreview.src = e.target.result;
                    editImagePreviewContainer.classList.remove('d-none');
                }
                reader.readAsDataURL(file);
            } else {
                editImagePreviewContainer.classList.add('d-none');
            }
        });
    }

    // Edit category modal functionality
    const editButtons = document.querySelectorAll('.edit-category-btn');
    const editModal = document.getElementById('editCategoryModal');
    const currentImageContainer = document.getElementById('currentImageContainer');
    const currentCategoryImage = document.getElementById('currentCategoryImage');

    editButtons.forEach(button => {
        button.addEventListener('click', function () {
            const categoryId = this.getAttribute('data-category-id');
            const categoryName = this.getAttribute('data-category-name');
            const categoryDescription = this.getAttribute('data-category-description');
            const categoryStatus = this.getAttribute('data-category-status');
            const categoryImage = this.getAttribute('data-category-image');

            // Set values in the modal form
            editModal.querySelector('form').action = `/admin/categories/${categoryId}`;
            editModal.querySelector('#editCategoryName').value = categoryName;
            editModal.querySelector('#editCategoryDescription').value = categoryDescription;
            
            // Set status radio button
            if (categoryStatus === '1') {
                document.getElementById('editStatusActive').checked = true;
            } else {
                document.getElementById('editStatusInactive').checked = true;
            }
            
            // Set current image
            if (categoryImage) {
                currentCategoryImage.src = `/storage/${categoryImage}`;
                currentImageContainer.classList.remove('d-none');
            } else {
                currentImageContainer.classList.add('d-none');
            }
            
            // Reset new image preview
            editImagePreviewContainer.classList.add('d-none');
            if (editCategoryImageInput) {
                editCategoryImageInput.value = '';
            }
        });
    });
});
</script>

@endsection