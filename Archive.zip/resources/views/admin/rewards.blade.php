@extends('admin.layouts.master')

@section('title','Rewards')

@section('content')

 <!-- Customers Page -->
        <div id="customers-page" class="page-content">
          <div class="page-header justify-content-between">
            <h4 class="page-title">Customer Management</h4>

            <button
              type="button"
              class="btn btn-outline-primary"
              data-bs-toggle="modal"
              data-bs-target="#addRewardsModal"
            >
              <i class="fas fa-star me-2"></i> Add Rewards
            </button>
          </div>

          <div class="card">
            <div class="card-body">
              <div class="row g-3 align-items-center">
                <!-- Search Bar -->
                <x-search :action="route('admin.rewards')" placeholder="Search..." />

                <!-- Export Button / Filter Button -->
                {{-- <div class="col-md-4">
                  <div class="d-flex justify-content-end gap-2">
                    <a
                      href="#"
                      class="btn btn-outline-secondary"
                      data-bs-toggle="modal"
                      data-bs-target="#exportFeedbackModal"
                    >
                      <i class="fas fa-file-export me-2"></i> Export
                    </a>
                    <!-- Filter Trigger Button -->
                    <button
                      type="button"
                      class="btn btn-outline-primary"
                      data-bs-toggle="modal"
                      data-bs-target="#customerFilterModal"
                    >
                      <i class="fas fa-filter me-1"></i> Filter
                    </button>
                    <button class="btn btn-outline-secondary" id="resetFilters">
                      <i class="fas fa-sync-alt"></i>
                    </button>
                  </div>
                </div> --}}
              </div>
            </div>
          </div>

          <div class="card">
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-hover" id="rewardsTable">
                        <thead>
                            <tr>
                                <th>Sr.No.</th>
                                <th>Image</th>
                                <th>Name</th>
                                <th>Description</th>
                                <th>Points</th>
                                <th>Expiry Date</th>
                                <th>Status</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            @foreach($rewards as $index => $reward)
                                <tr>
                                    <td>{{ $index + 1 }}</td>
                                    <td>
                                        @if($reward->image)
                                            <img src="{{ asset('storage/' . $reward->image) }}" class="customer-img" alt="{{ $reward->name }}" />
                                        @else
                                            <img src="{{ asset('asset/image/profile-pic.png') }}" class="customer-img" alt="No Image" />
                                        @endif
                                    </td>
                                    <td>{{ $reward->name }}</td>
                                    <td>{{ $reward->description }}</td>
                                    <td>{{ $reward->points }}</td>
                                    {{-- @dd($reward) --}}
                                    <td>{{ $reward->expiry_date }}</td>
                                    <td>
                                        <span class="badge {{ $reward->status == 'active' ? 'bg-success' : 'bg-danger' }}">
                                            {{ ucfirst($reward->status) }}
                                        </span>
                                    </td>
                                    <td class="text-center">
                                        <div class="dropdown">
                                            <button class="btn btn-sm" type="button" data-bs-toggle="dropdown" aria-expanded="false">
                                                <i class="fas fa-ellipsis-v"></i>
                                            </button>
                                            <ul class="dropdown-menu dropdown-menu-end">
                                                <li>
                                                    <a class="dropdown-item edit-rewards-btn"
                                                      href="#"
                                                      data-bs-toggle="modal"
                                                      data-bs-target="#editRewardsModal"
                                                      data-reward-id="{{ $reward->id }}"
                                                      data-reward-name="{{ $reward->name }}"
                                                      data-reward-description="{{ $reward->description }}"
                                                      data-reward-points="{{ $reward->points }}"
                                                      data-reward-date="{{ $reward->expiry_date }}"
                                                      data-reward-status="{{ $reward->status }}"
                                                      data-reward-image="{{ $reward->image ? asset('storage/' . $reward->image) : '' }}">
                                                      <i class="fas fa-edit me-2"></i> Edit
                                                    </a>
                                                </li>
                                                <li><hr class="dropdown-divider" /></li>
                                                <li>
                                                    <form action="{{ route('rewards.destroy', $reward->id) }}" method="POST">
                                                        @csrf
                                                        @method('DELETE')
                                                        <button type="submit" class="dropdown-item text-danger">
                                                            <i class="fas fa-trash me-2"></i> Delete
                                                        </button>
                                                    </form>
                                                </li>
                                            </ul>
                                        </div>
                                    </td>
                                </tr>
                            @endforeach

                            @if($rewards->isEmpty())
                                <tr>
                                    <td colspan="8" class="text-center">No rewards found.</td>
                                </tr>
                            @endif
                        </tbody>
                    </table>
                </div>
                <!-- PAGINATION -->
              @if(isset($rewards) && $rewards->hasPages())
                  @include('admin.layouts.pagination', ['paginator' => $rewards])
              @endif
            </div>
        </div>
        </div>

       <!-- Add Rewards Modal -->
        <div
            class="modal fade"
            id="addRewardsModal"
            tabindex="-1"
            aria-labelledby="addRewardsModalLabel"
            aria-hidden="true"
        >
            <div class="modal-dialog modal-md">
                <div class="modal-content">
                    <div class="modal-header bg-primary text-white">
                        <h5 class="modal-title" id="addRewardsModalLabel">Add Rewards</h5>
                        <button
                            type="button"
                            class="btn-close btn-close-white"
                            data-bs-dismiss="modal"
                            aria-label="Close"
                        ></button>
                    </div>

                    <form id="addRewardsForm" action="{{ route('rewards.store') }}" method="POST" enctype="multipart/form-data">
                        @csrf
                        <div class="modal-body">
                            
                            <!-- Reward Image -->
                            <div class="mb-3">
                                <label for="rewardImage" class="form-label">Reward Image</label>
                                <input
                                    type="file"
                                    class="form-control"
                                    id="rewardImage"
                                    name="image"
                                    accept="image/*"
                                    required
                                />
                            </div>

                            <!-- Reward Name -->
                            <div class="mb-3">
                                <label for="rewardName" class="form-label">Reward Name</label>
                                <input
                                    type="text"
                                    class="form-control"
                                    id="rewardName"
                                    name="name"
                                    placeholder="Enter reward name"
                                    required
                                />
                            </div>

                            <!-- Reward Description -->
                            <div class="mb-3">
                                <label for="rewardDescription" class="form-label">Reward Description</label>
                                <textarea
                                    class="form-control"
                                    id="rewardDescription"
                                    name="description"
                                    rows="3"
                                    placeholder="Describe the reward"
                                    required
                                ></textarea>
                            </div>

                            <!-- Reward Points -->
                            <div class="mb-3">
                                <label for="rewardPoints" class="form-label">Points</label>
                                <input
                                    type="number"
                                    class="form-control"
                                    id="rewardPoints"
                                    name="points"
                                    placeholder="Enter reward points"
                                    min="0"
                                    required
                                />
                            </div>

                            <!-- Reward Date -->
                            <div class="mb-3">
                                <label for="rewardDate" class="form-label">Expiry Date</label>
                                <input
                                    type="date"
                                    class="form-control"
                                    id="rewardDate"
                                    name="date"
                                    required
                                />
                            </div>

                            <!-- Reward Status -->
                            <div class="mb-3">
                                <label for="rewardStatus" class="form-label">Status</label>
                                <select
                                    class="form-select"
                                    id="rewardStatus"
                                    name="status"
                                    required
                                >
                                    <option value="" disabled selected>Select status</option>
                                    <option value="active">Active</option>
                                    <option value="inactive">Inactive</option>
                                </select>
                            </div>

                        </div>
                        <div class="modal-footer">
                            <button
                                type="button"
                                class="btn btn-secondary"
                                data-bs-dismiss="modal"
                            >
                                Cancel
                            </button>
                            <button
                                type="submit"
                                class="btn btn-primary"
                            >
                                <i class="fas fa-gift me-2"></i> Add Reward
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>


      <!-- Edit Rewards Modal -->
      <div
        class="modal fade"
        id="editRewardsModal"
        tabindex="-1"
        aria-labelledby="editRewardsModalLabel"
        aria-hidden="true"
      >
        <div class="modal-dialog modal-md">
          <div class="modal-content">
            <div class="modal-header bg-primary text-white">
              <h5 class="modal-title" id="editRewardsModalLabel">
                Edit Reward
              </h5>
              <button
                type="button"
                class="btn-close btn-close-white"
                data-bs-dismiss="modal"
                aria-label="Close"
              ></button>
            </div>
            <div class="modal-body">
                <form id="editRewardsForm" method="POST" enctype="multipart/form-data">
                    @csrf
                    @method('PUT')

                    <!-- Reward Image -->
                    <div class="mb-3">
                        <label for="editRewardImage" class="form-label">Reward Image</label>
                        <input
                            type="file"
                            class="form-control"
                            id="editRewardImage"
                            name="image"
                            accept="image/*"
                        />
                        <!-- Optional: preview existing image -->
                        <div class="mt-2">
                            <img
                                id="rewardImagePreview"
                                src=""
                                alt="Reward Image"
                                class="img-thumbnail"
                                width="100"
                            />
                        </div>
                    </div>

                    <!-- Reward Name -->
                    <div class="mb-3">
                        <label for="editRewardName" class="form-label">Reward Name</label>
                        <input
                            type="text"
                            class="form-control"
                            id="editRewardName"
                            name="name"
                            placeholder="Enter reward name"
                            required
                        />
                    </div>

                    <!-- Reward Description -->
                    <div class="mb-3">
                        <label for="editRewardDescription" class="form-label">Reward Description</label>
                        <textarea
                            class="form-control"
                            id="editRewardDescription"
                            name="description"
                            rows="3"
                            placeholder="Describe the reward"
                            required
                        ></textarea>
                    </div>

                    <!-- Reward Points -->
                    <div class="mb-3">
                        <label for="editRewardPoints" class="form-label">Points</label>
                        <input
                            type="number"
                            class="form-control"
                            id="editRewardPoints"
                            name="points"
                            placeholder="Enter points"
                            min="0"
                            required
                        />
                    </div>

                    <!-- Reward Date -->
                    <div class="mb-3">
                        <label for="editRewardDate" class="form-label">Date</label>
                        <input
                            type="date"
                            class="form-control"
                            id="editRewardDate"
                            name="date"
                            required
                        />
                    </div>

                    <!-- Reward Status -->
                    <div class="mb-3">
                        <label for="editRewardStatus" class="form-label">Status</label>
                        <select class="form-select" id="editRewardStatus" name="status" required>
                            <option value="" disabled>Select status</option>
                            <option value="active">Active</option>
                            <option value="inactive">Inactive</option>
                        </select>
                    </div>
                </form>
            </div>
            <div class="modal-footer">
              <button
                type="button"
                class="btn btn-secondary"
                data-bs-dismiss="modal"
              >
                Cancel
              </button>
              <button
                type="submit"
                class="btn btn-primary"
                form="editRewardsForm"
              >
                <i class="fas fa-edit me-2"></i> Update Reward
              </button>
            </div>
          </div>
        </div>
      </div>

      <script>
        document.addEventListener('DOMContentLoaded', function () {
    const editButtons = document.querySelectorAll('.edit-rewards-btn');

    editButtons.forEach(button => {
        button.addEventListener('click', function () {
            const rewardId = this.dataset.rewardId;
            const name = this.dataset.rewardName;
            const description = this.dataset.rewardDescription;
            const points = this.dataset.rewardPoints;
            const date = this.dataset.rewardDate;
            const status = this.dataset.rewardStatus;
            const image = this.dataset.rewardImage;

            // Set modal fields
            document.getElementById('editRewardName').value = name;
            document.getElementById('editRewardDescription').value = description;
            document.getElementById('editRewardDate').value = date;
            document.getElementById('editRewardStatus').value = status;
            
            // Preview image
            const preview = document.getElementById('rewardImagePreview');
            if(image){
                preview.src = image;
            } else {
                preview.src = "{{ asset('asset/image/profile-pic.png') }}";
            }

            // Set form action dynamically
            const form = document.getElementById('editRewardsForm');
            form.action = `/admin/rewards/${rewardId}`;
        });
    });
});

      </script>
@endsection