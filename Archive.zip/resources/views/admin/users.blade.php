@extends('admin.layouts.master')

@section('title', 'Users')

@section('content')

<div class="page-header">
          <h4 class="page-title">User Management</h4>
          <!-- <button class="btn btn-primary">Add New Karigar</button> -->
        </div>

        <!-- Karigar Page -->
        <div id="karigar-page" class="page-content">
          <div class="card">
            <div class="card-body">
              <div class="row g-3 align-items-center">
                <!-- Search Bar -->
                <x-search :action="route('admin.users')" placeholder="Search customers..." />


                <!-- Export Button / Filter Button -->
                {{-- <div class="col-md-4">
                  <div class="d-flex justify-content-end gap-2">
                    <a
                      href="#"
                      class="btn btn-outline-secondary"
                      data-bs-toggle="modal"
                      data-bs-target="#exportFeedbackModal"
                    >
                      <i class="fas fa-file-export me-2"></i> Export
                    </a>
                    <button
                      class="btn btn-outline-primary"
                      id="karigarFilterBtn"
                      data-bs-toggle="modal"
                      data-bs-target="#filterKarigarModal"
                    >
                      <i class="fas fa-filter me-2"></i> Filters
                    </button>
                    <button class="btn btn-outline-secondary" id="resetFilters">
                      <i class="fas fa-sync-alt"></i>
                    </button>
                  </div>
                </div> --}}
              </div>
            </div>
          </div>

          <div class="card">
            <div class="card-body">
              <div class="table-responsive" style="overflow-x:auto; white-space:nowrap;">
                <table class="table table-hover align-middle" id="userTable">
                  <thead class="table-light">
                    <tr>
                      <th>Sr.No.</th>
                      <th>ID</th>
                      <th>Date</th>
                      <th>User Photo</th>
                      <th>Name</th>
                      <th>Email</th>
                      <th>Phone Number</th>
                      <th>State</th>
                      <th>District</th>
                      <th>City</th>
                      <th>Address</th>
                      <th>Status</th>
                      <th>Actions</th>
                    </tr>
                  </thead>
                  <tbody>
                    @forelse ($users as $index => $user)
                      <tr>
                        <td>{{ $index + 1 }}</td>
                        <td>{{ 'USR' . str_pad($user->id, 3, '0', STR_PAD_LEFT) }}</td>
                        <td>{{ $user->created_at->format('Y-m-d') }}</td>
                        <td><img src="{{ $user->profile_pic }}" class="rounded-circle" style="width:50px; height:50px; object-fit:cover;"></td>
                        <td>{{ $user->name }}</td>
                        <td>{{ $user->email ?? 'N/A' }}</td>
                        <td>{{ $user->phone ?? 'N/A' }}</td>
                        <td>{{ $user->address->state ?? 'N/A' }}</td>
                        <td>{{ $user->address->district ?? 'N/A' }}</td>
                        <td>{{ $user->address->city ?? 'N/A' }}</td>
                        <td>{{ $user->address->address ?? 'N/A' }}</td>
                        <td>
                          @if ($user->status == 1)
                            <span class="badge bg-success">Active</span>
                          @else
                            <span class="badge bg-danger">Deactive</span>
                          @endif
                        </td>
                        <td>
                          <div class="dropdown">
                            <button class="btn btn-sm" data-bs-toggle="dropdown">
                              <i class="fas fa-ellipsis-v"></i>
                            </button>
                            <ul class="dropdown-menu dropdown-menu-end">
                              <li>
                                  <a href="{{ route('admin.users.point-history', encrypt($user->id)) }}" class="dropdown-item">
                                      <i class="fas fa-history me-2"></i> View Point History
                                  </a>
                              </li>
                              <li>
                                <a href="#" class="dropdown-item toggle-status-btn"
                                  data-user-id="{{ $user->id }}"
                                  data-current-status="{{ $user->status == 1 ? 'active' : 'deactive' }}">
                                  <i class="fas fa-power-off me-2"></i>
                                  {{ $user->status == 1 ? 'Deactivate' : 'Activate' }}
                                </a>
                              </li>
                            </ul>
                          </div>
                        </td>
                      </tr>
                    @empty
                      <tr><td colspan="13" class="text-center">No users found</td></tr>
                    @endforelse
                  </tbody>
                </table>
              </div>

              @if(isset($users) && $users->hasPages())
                @include('admin.layouts.pagination', ['paginator' => $users])
              @endif
            </div>
          </div>
        </div>

<script>
document.addEventListener('click', function(e) {
    if (e.target.closest('.toggle-status-btn')) {
        e.preventDefault();
        let btn = e.target.closest('.toggle-status-btn');
        let userId = btn.dataset.userId;

        fetch(`/admin/users/${userId}/toggle-status`, {
            method: 'POST',
            headers: {
                'X-CSRF-TOKEN': '{{ csrf_token() }}'
            }
        })
        .then(res => res.json())
        .then(data => {
            if (data.status) location.reload();
            else alert(data.message);
        });
    }
});
</script>
@endsection