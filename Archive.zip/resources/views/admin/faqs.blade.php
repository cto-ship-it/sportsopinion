@extends('admin.layouts.master')

@section('title', 'FAQs')

@section('content')

 <!-- Customers Page -->
        <div id="customers-page" class="page-content">
          <div class="page-header justify-content-between">
            <h4 class="page-title">Customer Management</h4>

            <button
              type="button"
              class="btn bg-info text-white"
              data-bs-toggle="modal"
              data-bs-target="#addFaqModal"
            >
              <i class="fas fa-star me-2"></i> Add FAQs
            </button>
          </div>

          <div class="card">
            <div class="card-body">
              <div class="row g-3 align-items-center">
                <!-- Search Bar -->
                <div class="col-md-8">
                  <div class="input-group me-3" style="width: 250px">
                    <input
                      type="text"
                      class="form-control form-control-sm"
                      placeholder="Search..."
                    />
                    <button
                      class="btn btn-sm btn-outline-secondary"
                      type="button"
                    >
                      <i class="fas fa-search"></i>
                    </button>
                  </div>
                </div>

                <!-- Export Button / Filter Button -->
                <div class="col-md-4">
                  <div class="d-flex justify-content-end gap-2">
                    <!-- <a
                      href="#"
                      class="btn btn-outline-secondary"
                      data-bs-toggle="modal"
                      data-bs-target="#exportFeedbackModal"
                    >
                      <i class="fas fa-file-export me-2"></i> Export
                    </a> -->
                    <!-- Filter Trigger Button -->
                    <!-- <button
                      type="button"
                      class="btn btn-outline-primary"
                      data-bs-toggle="modal"
                      data-bs-target="#customerFilterModal"
                    >
                      <i class="fas fa-filter me-1"></i> Filter
                    </button> -->
                    <button class="btn btn-outline-secondary" id="resetFilters">
                      <i class="fas fa-sync-alt"></i>
                    </button>
                  </div>
                </div>
              </div>
            </div>
          </div>

          <div class="card">
            <div class="card-body">
            <div class="table-responsive">
                <table class="table table-hover" id="faqsTable">
                <thead>
                    <tr>
                    <th class="text-center">Sr.No.</th>
                    <th class="text-center">Date</th>
                    <th class="text-center">Question</th>
                    <th class="text-center">Answer</th>
                    <th class="text-center">Edit / Delete</th>
                    </tr>
                </thead>
                <tbody>
                    @forelse($faqs as $key => $faq)
                    <tr>
                        <td class="text-center">{{ $key + 1 }}</td>
                        <td class="text-center">{{ $faq->created_at->format('d M Y') }}</td>
                        <td class="text-center">{{ $faq->question }}</td>
                        <td class="text-center">{{ $faq->answer }}</td>

                        <td class="text-center">
                        <!-- Edit Button -->
                        <button
                            type="button"
                            class="btn btn-sm btn-warning me-1 edit-faq-btn"
                            data-bs-toggle="modal"
                            data-bs-target="#editFaqModal"
                            data-faq-id="{{ $faq->id }}"
                            data-faq-question="{{ $faq->question }}"
                            data-faq-answer="{{ $faq->answer }}"
                        >
                            <i class="fas fa-edit me-1"></i> Edit
                        </button>

                        <!-- Delete Button -->
                        <form action="{{ route('faqs.destroy', $faq->id) }}" method="POST" class="d-inline">
                            @csrf
                            @method('DELETE')
                            <button type="submit" class="btn btn-sm btn-danger" onclick="return confirm('Are you sure you want to delete this FAQ?')">
                            <i class="fas fa-trash me-1"></i> Delete
                            </button>
                        </form>
                        </td>
                    </tr>
                    @empty
                    <tr>
                        <td colspan="5" class="text-center">No FAQs found.</td>
                    </tr>
                    @endforelse
                </tbody>
                </table>
            </div>
            </div>
          </div>
        </div>

       <!-- Add FAQ Modal -->
        <div class="modal fade" id="addFaqModal" tabindex="-1" aria-labelledby="addFaqModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-md">
            <div class="modal-content">
            <div class="modal-header bg-primary text-white">
                <h5 class="modal-title" id="addFaqModalLabel">Add FAQ</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>

            <div class="modal-body">
                <form id="addFaqForm" method="POST" action="{{ route('faqs.store') }}">
                @csrf

                <!-- Question -->
                <div class="mb-3">
                    <label for="faqQuestion" class="form-label">Question</label>
                    <textarea
                    name="question"
                    class="form-control"
                    id="faqQuestion"
                    rows="3"
                    placeholder="Enter the question here"
                    required
                    >{{ old('question') }}</textarea>
                    @error('question')
                    <span class="text-danger">{{ $message }}</span>
                    @enderror
                </div>

                <!-- Answer -->
                <div class="mb-3">
                    <label for="faqAnswer" class="form-label">Answer</label>
                    <textarea
                    name="answer"
                    class="form-control"
                    id="faqAnswer"
                    rows="5"
                    placeholder="Enter the answer here"
                    required
                    >{{ old('answer') }}</textarea>
                    @error('answer')
                    <span class="text-danger">{{ $message }}</span>
                    @enderror
                </div>
                </form>
            </div>

            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">
                Cancel
                </button>
                <button type="submit" class="btn btn-primary" form="addFaqForm">
                <i class="fas fa-question-circle me-2"></i> Add FAQ
                </button>
            </div>
            </div>
        </div>
        </div>


      <!-- User History Log Modal -->
      <div
        class="modal fade"
        id="userHistoryModal"
        tabindex="-1"
        aria-labelledby="userHistoryModalLabel"
        aria-hidden="true"
      >
        <div class="modal-dialog modal-xl">
          <!-- Made it larger -->
          <div class="modal-content">
            <div class="modal-header bg-primary text-white">
              <h5 class="modal-title" id="userHistoryModalLabel">
                User History Log
              </h5>
              <button
                type="button"
                class="btn-close btn-close-white"
                data-bs-dismiss="modal"
                aria-label="Close"
              ></button>
            </div>

            <div class="modal-body">
              <!-- Question Info -->
              <div class="mb-3">
                <label class="form-label fw-bold">Question:</label>
                <p id="historyQuestionText" class="mb-2 text-muted">
                  <!-- Dynamic Question Text -->
                  Which team will win today's match?
                </p>
              </div>

              <!-- Summary Counts -->
              <div class="row text-center mb-4">
                <div class="col-md-6">
                  <div class="border rounded py-3 bg-light">
                    <h6 class="text-success mb-1">
                      <i class="fas fa-check-circle me-1"></i> Yes
                    </h6>
                    <h4 id="yesCount">128</h4>
                  </div>
                </div>
                <div class="col-md-6">
                  <div class="border rounded py-3 bg-light">
                    <h6 class="text-danger mb-1">
                      <i class="fas fa-times-circle me-1"></i> No
                    </h6>
                    <h4 id="noCount">54</h4>
                  </div>
                </div>
              </div>

              <!-- Dual Table Layout -->
              <div class="row">
                <!-- YES Users Table -->
                <div class="col-md-6">
                  <div class="card border-success shadow-sm">
                    <div
                      class="card-header bg-success text-white text-center fw-bold"
                    >
                      Users Who Said YES
                    </div>
                    <div class="card-body p-0">
                      <div class="table-responsive">
                        <table
                          class="table table-striped table-bordered align-middle mb-0"
                        >
                          <thead class="table-success">
                            <tr>
                              <th class="text-center">#</th>
                              <th>User Name</th>
                              <th class="text-center">Date</th>
                            </tr>
                          </thead>
                          <tbody>
                            <tr>
                              <td class="text-center">1</td>
                              <td>Rohit Sharma</td>
                              <td class="text-center">2025-10-11</td>
                            </tr>
                            <tr>
                              <td class="text-center">2</td>
                              <td>Hardik Pandya</td>
                              <td class="text-center">2025-10-11</td>
                            </tr>
                            <tr>
                              <td class="text-center">3</td>
                              <td>MS Dhoni</td>
                              <td class="text-center">2025-10-10</td>
                            </tr>
                          </tbody>
                        </table>
                      </div>
                    </div>
                  </div>
                </div>

                <!-- NO Users Table -->
                <div class="col-md-6 mt-4 mt-md-0">
                  <div class="card border-danger shadow-sm">
                    <div
                      class="card-header bg-danger text-white text-center fw-bold"
                    >
                      Users Who Said NO
                    </div>
                    <div class="card-body p-0">
                      <div class="table-responsive">
                        <table
                          class="table table-striped table-bordered align-middle mb-0"
                        >
                          <thead class="table-danger">
                            <tr>
                              <th class="text-center">#</th>
                              <th>User Name</th>
                              <th class="text-center">Date</th>
                            </tr>
                          </thead>
                          <tbody>
                            <tr>
                              <td class="text-center">1</td>
                              <td>Virat Kohli</td>
                              <td class="text-center">2025-10-11</td>
                            </tr>
                            <tr>
                              <td class="text-center">2</td>
                              <td>KL Rahul</td>
                              <td class="text-center">2025-10-10</td>
                            </tr>
                            <tr>
                              <td class="text-center">3</td>
                              <td>Ravindra Jadeja</td>
                              <td class="text-center">2025-10-09</td>
                            </tr>
                          </tbody>
                        </table>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            <!-- Footer -->
            <div class="modal-footer">
              <button
                type="button"
                class="btn btn-secondary"
                data-bs-dismiss="modal"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      </div>

     <!-- Edit FAQ Modal -->
<div class="modal fade" id="editFaqModal" tabindex="-1" aria-labelledby="editFaqModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-md">
    <div class="modal-content">
      <div class="modal-header bg-warning text-white">
        <h5 class="modal-title" id="editFaqModalLabel">Edit FAQ</h5>
        <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>

      <div class="modal-body">
        <form id="editFaqForm" method="POST" action="">
          @csrf
          @method('PUT')

          <div class="mb-3">
            <label for="editFaqQuestion" class="form-label">Question</label>
            <textarea name="question" id="editFaqQuestion" class="form-control" rows="3" required></textarea>
          </div>

          <div class="mb-3">
            <label for="editFaqAnswer" class="form-label">Answer</label>
            <textarea name="answer" id="editFaqAnswer" class="form-control" rows="5" required></textarea>
          </div>
        </form>
      </div>

      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
        <button type="submit" class="btn btn-warning text-white" form="editFaqForm">
          <i class="fas fa-edit me-2"></i> Update FAQ
        </button>
      </div>
    </div>
  </div>
</div>


      <script>
document.addEventListener('DOMContentLoaded', function () {
    const editButtons = document.querySelectorAll('.edit-faq-btn');
    const editModal = document.getElementById('editFaqModal');

    editButtons.forEach(button => {
        button.addEventListener('click', function () {
            const faqId = this.getAttribute('data-faq-id');
            const faqQuestion = this.getAttribute('data-faq-question');
            const faqAnswer = this.getAttribute('data-faq-answer');

            // Set values in the modal form
            editModal.querySelector('form').action = `/admin/faqs/${faqId}`;
            editModal.querySelector('textarea[name="question"]').value = faqQuestion;
            editModal.querySelector('textarea[name="answer"]').value = faqAnswer;
        });
    });
});
</script>

@endsection