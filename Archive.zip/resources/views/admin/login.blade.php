<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Daily Opinion - Login</title>
    <!-- Bootstrap CSS -->
    <link
      href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css"
      rel="stylesheet"
    />
    <!-- Font Awesome -->
    <link
      rel="stylesheet"
      href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css"
    />
    <style>
      :root {
        --primary-color: #4361ee;
        --secondary-color: #3a0ca3;
        --light-color: #f8f9fa;
        --dark-color: #212529;
        --success-color: #4cc9f0;
        --warning-color: #f72585;
      }
      
      body {
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        min-height: 100vh;
        display: flex;
        align-items: center;
        justify-content: center;
        font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
      }
      
      .login-container {
        background-color: white;
        border-radius: 15px;
        box-shadow: 0 10px 30px rgba(0, 0, 0, 0.2);
        overflow: hidden;
        width: 100%;
        max-width: 400px;
      }
      
      .login-header {
        background-color: var(--primary-color);
        color: white;
        padding: 30px 20px;
        text-align: center;
      }
      
      .login-logo {
        width: 120px;
        margin-bottom: 15px;
      }
      
      .login-body {
        padding: 30px;
      }
      
      .form-control {
        border-radius: 8px;
        padding: 12px 15px;
        border: 1px solid #e1e5ee;
        transition: all 0.3s;
      }
      
      .form-control:focus {
        border-color: var(--primary-color);
        box-shadow: 0 0 0 0.2rem rgba(67, 97, 238, 0.25);
      }
      
      .input-group-text {
        background-color: white;
        border: 1px solid #e1e5ee;
        border-right: none;
      }
      
      .btn-login {
        background-color: var(--primary-color);
        border: none;
        color: white;
        padding: 12px;
        border-radius: 8px;
        font-weight: 600;
        transition: all 0.3s;
      }
      
      .btn-login:hover {
        background-color: var(--secondary-color);
        transform: translateY(-2px);
        box-shadow: 0 5px 15px rgba(0, 0, 0, 0.1);
      }
      
      .login-footer {
        text-align: center;
        padding: 20px;
        background-color: #f8f9fa;
        border-top: 1px solid #e1e5ee;
      }
      
      .login-footer a {
        color: var(--primary-color);
        text-decoration: none;
      }
      
      .login-footer a:hover {
        text-decoration: underline;
      }
      
      .form-check-input:checked {
        background-color: var(--primary-color);
        border-color: var(--primary-color);
      }
      
      .password-toggle {
        cursor: pointer;
        background-color: white;
        border: 1px solid #e1e5ee;
        border-left: none;
      }
      
      .alert {
        border-radius: 8px;
      }
      
      .is-invalid {
        border-color: #dc3545;
      }
      
      .invalid-feedback {
        display: block;
      }
    </style>
  </head>
  <body>
    <div class="login-container">
      <div class="login-header">
        <img src="{{ asset('images/logo.png') }}" alt="Daily Opinion Logo" class="login-logo" />
        <h3>Welcome Back</h3>
        <p class="mb-0">Sign in to your account</p>
      </div>
      
      <div class="login-body">
        <!-- Success Messages -->
        @if(session('success'))
          <div class="alert alert-success alert-dismissible fade show" role="alert">
            {{ session('success') }}
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
          </div>
        @endif

        <!-- Error Messages -->
        @if($errors->any())
          <div class="alert alert-danger alert-dismissible fade show" role="alert">
            <ul class="mb-0">
              @foreach($errors->all() as $error)
                <li>{{ $error }}</li>
              @endforeach
            </ul>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
          </div>
        @endif
        
        <form method="POST" action="{{ route('login.submit') }}">
          @csrf
          
          <div class="mb-3">
            <label for="email" class="form-label">Email Address</label>
            <div class="input-group">
              <span class="input-group-text"><i class="fas fa-envelope"></i></span>
              <input 
                type="email" 
                class="form-control @error('email') is-invalid @enderror" 
                id="email" 
                name="email"
                value="{{ old('email') }}"
                placeholder="name@example.com"
                required
                autocomplete="email"
                autofocus
              >
            </div>
            @error('email')
              <div class="invalid-feedback d-block">
                {{ $message }}
              </div>
            @enderror
          </div>
          
          <div class="mb-3">
            <label for="password" class="form-label">Password</label>
            <div class="input-group">
              <span class="input-group-text"><i class="fas fa-lock"></i></span>
              <input 
                type="password" 
                class="form-control @error('password') is-invalid @enderror" 
                id="password" 
                name="password"
                placeholder="Enter your password"
                required
                autocomplete="current-password"
              >
              <span class="input-group-text password-toggle" id="togglePassword">
                <i class="fas fa-eye"></i>
              </span>
            </div>
            @error('password')
              <div class="invalid-feedback d-block">
                {{ $message }}
              </div>
            @enderror
          </div>
          
          {{-- Uncomment if you want remember me functionality --}}
          {{-- <div class="mb-3 form-check">
            <input type="checkbox" class="form-check-input" id="remember" name="remember">
            <label class="form-check-label" for="remember">Remember me</label>
            <a href="#" class="float-end">Forgot password?</a>
          </div> --}}
          
          <button type="submit" class="btn btn-login w-100 mb-3">Log In</button>
          
          {{-- Uncomment if you want registration link --}}
          {{-- <div class="text-center">
            <p class="mb-0">Don't have an account? <a href="{{ route('register') }}">Sign up</a></p>
          </div> --}}
        </form>
      </div>
      
      <div class="login-footer">
        <small>&copy; {{ date('Y') }} Daily Opinion. All rights reserved.</small>
      </div>
    </div>

    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
    <script>
      // Toggle password visibility
      document.getElementById('togglePassword').addEventListener('click', function() {
        const passwordInput = document.getElementById('password');
        const icon = this.querySelector('i');
        
        if (passwordInput.type === 'password') {
          passwordInput.type = 'text';
          icon.classList.remove('fa-eye');
          icon.classList.add('fa-eye-slash');
        } else {
          passwordInput.type = 'password';
          icon.classList.remove('fa-eye-slash');
          icon.classList.add('fa-eye');
        }
      });

      // Auto-dismiss alerts after 5 seconds
      document.addEventListener('DOMContentLoaded', function() {
        setTimeout(function() {
          const alerts = document.querySelectorAll('.alert');
          alerts.forEach(function(alert) {
            const bsAlert = new bootstrap.Alert(alert);
            bsAlert.close();
          });
        }, 5000);
      });
    </script>
  </body>
</html>