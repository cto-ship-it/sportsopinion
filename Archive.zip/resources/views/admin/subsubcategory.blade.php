@extends('admin.layouts.master')

@section('title', 'Sub Subcategories')

@section('content')

 <!-- Sub Subcategories Page -->
        <div id="subsubcategories-page" class="page-content">
          <div class="page-header justify-content-between">
            <!-- Breadcrumb Navigation -->
            <nav aria-label="breadcrumb">
              <ol class="breadcrumb">
                <li class="breadcrumb-item">
                  <a href="{{ route('subcategories.index') }}">Subcategories</a>
                </li>
                <li class="breadcrumb-item active" aria-current="page">
                  Sub Subcategories
                </li>
              </ol>
            </nav>

            <h4 class="page-title">Sub Subcategory Management</h4>

            <button
              type="button"
              class="btn bg-info text-white"
              data-bs-toggle="modal"
              data-bs-target="#addSubSubcategoryModal"
            >
              <i class="fas fa-plus me-2"></i> Add Sub Subcategory
            </button>
          </div>

          <div class="card">
            <div class="card-body">
              <div class="row g-3 align-items-center">
                <!-- Search Bar -->
                <x-search :action="route('subsubcategories.index')" placeholder="Search sub subcategories..." />

                <!-- Export Button / Filter Button -->
                <div class="col-md-4">
                  <div class="d-flex justify-content-end gap-2">
                    <button class="btn btn-outline-secondary" id="resetFilters">
                      <i class="fas fa-sync-alt"></i>
                    </button>
                  </div>
                </div>
              </div>
            </div>
          </div>

          <div class="card">
            <div class="card-body">
            <div class="table-responsive">
                <table class="table table-hover" id="subsubcategoriesTable">
                <thead>
                    <tr>
                    <th class="text-center">Sr.No.</th>
                    <th class="text-center">Date</th>
                    <th class="text-center">Sub Category</th>
                    <th class="text-center">Name</th>
                    <th class="text-center">Description</th>
                    <th class="text-center">Status</th>
                    <th class="text-center">Edit / Delete</th>
                    </tr>
                </thead>
                <tbody>
                    @forelse($subsubcategories as $key => $subsubcategory)
                    <tr>
                        <td class="text-center">{{ $key + 1 }}</td>
                        <td class="text-center">{{ $subsubcategory->created_at ? $subsubcategory->created_at->format('d M Y') : '-' }}</td>
                        <td class="text-center">{{ $subsubcategory->subcategory->name ?? '-' }}</td>
                        <td class="text-center">{{ $subsubcategory->name }}</td>
                        <td class="text-center">{{ $subsubcategory->description }}</td>
                        <td class="text-center">
                          <span class="badge bg-{{ $subsubcategory->status ? 'success' : 'secondary' }}">
                            {{ $subsubcategory->status ? 'Active' : 'Inactive' }}
                          </span>
                        </td>

                        <td class="text-center">
                        <!-- Edit Button -->
                        <button
                            type="button"
                            class="btn btn-sm btn-warning me-1 edit-subsubcategory-btn"
                            data-bs-toggle="modal"
                            data-bs-target="#editSubSubcategoryModal"
                            data-id="{{ $subsubcategory->id }}"
                            data-name="{{ $subsubcategory->name }}"
                            data-description="{{ $subsubcategory->description }}"
                            data-status="{{ $subsubcategory->status }}"
                            data-subcategory="{{ $subsubcategory->subcategory_id }}"
                        >
                            <i class="fas fa-edit me-1"></i> Edit
                        </button>

                        <!-- Delete Button -->
                        <form action="{{ route('subsubcategories.destroy', $subsubcategory->id) }}" method="POST" class="d-inline">
                            @csrf
                            @method('DELETE')
                            <button type="submit" class="btn btn-sm btn-danger" onclick="return confirm('Are you sure you want to delete this sub subcategory?')">
                            <i class="fas fa-trash me-1"></i> Delete
                            </button>
                        </form>
                        </td>
                    </tr>
                    @empty
                    <tr>
                        <td colspan="7" class="text-center">No sub subcategories found.</td>
                    </tr>
                    @endforelse
                </tbody>
                </table>
            </div>
             <!-- PAGINATION -->
              @if(isset($subsubcategories) && $subsubcategories->hasPages())
                  @include('admin.layouts.pagination', ['paginator' => $subsubcategories])
              @endif
            </div>
          </div>
        </div>

       <!-- Add Sub Subcategory Modal -->
        <div class="modal fade" id="addSubSubcategoryModal" tabindex="-1" aria-labelledby="addSubSubcategoryModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-md">
            <div class="modal-content">
            <div class="modal-header bg-primary text-white">
                <h5 class="modal-title" id="addSubSubcategoryModalLabel">Add Sub Subcategory</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>

            <div class="modal-body">
                <form id="addSubSubcategoryForm" method="POST" action="{{ route('subsubcategories.store') }}">
                @csrf

                <!-- SubCategory -->
                <div class="mb-3">
                    <label for="subcategorySelect" class="form-label">Sub Category</label>
                    <select name="subcategory_id" class="form-select" id="subcategorySelect" required>
                      <option value="">Select Sub Category</option>
                      @foreach($subcategories as $subcategory)
                        <option value="{{ $subcategory->id }}" {{ old('subcategory_id') == $subcategory->id ? 'selected' : '' }}>
                          {{ $subcategory->name }} ({{ $subcategory->category->name ?? 'No Cat' }})
                        </option>
                      @endforeach
                    </select>
                    @error('subcategory_id')
                    <span class="text-danger">{{ $message }}</span>
                    @enderror
                </div>

                <!-- Name -->
                <div class="mb-3">
                    <label for="subsubcategoryName" class="form-label">Name</label>
                    <input
                    type="text"
                    name="name"
                    class="form-control"
                    id="subsubcategoryName"
                    placeholder="Enter name"
                    value="{{ old('name') }}"
                    required
                    />
                    @error('name')
                    <span class="text-danger">{{ $message }}</span>
                    @enderror
                </div>

                <!-- Description -->
                <div class="mb-3">
                    <label for="subsubcategoryDescription" class="form-label">Description</label>
                    <textarea
                    name="description"
                    class="form-control"
                    id="subsubcategoryDescription"
                    rows="3"
                    placeholder="Enter description"
                    >{{ old('description') }}</textarea>
                    @error('description')
                    <span class="text-danger">{{ $message }}</span>
                    @enderror
                </div>

                <!-- Status -->
                <div class="mb-3">
                  <label class="form-label">Status</label>
                  <div>
                    <div class="form-check form-check-inline">
                      <input class="form-check-input" type="radio" name="status" id="statusActive" value="1" checked>
                      <label class="form-check-label" for="statusActive">Active</label>
                    </div>
                    <div class="form-check form-check-inline">
                      <input class="form-check-input" type="radio" name="status" id="statusInactive" value="0">
                      <label class="form-check-label" for="statusInactive">Inactive</label>
                    </div>
                  </div>
                  @error('status')
                  <span class="text-danger">{{ $message }}</span>
                  @enderror
                </div>
                </form>
            </div>

            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">
                Cancel
                </button>
                <button type="submit" class="btn btn-primary" form="addSubSubcategoryForm">
                <i class="fas fa-plus me-2"></i> Add
                </button>
            </div>
            </div>
        </div>
        </div>

     <!-- Edit Sub Subcategory Modal -->
<div class="modal fade" id="editSubSubcategoryModal" tabindex="-1" aria-labelledby="editSubSubcategoryModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-md">
    <div class="modal-content">
      <div class="modal-header bg-warning text-white">
        <h5 class="modal-title" id="editSubSubcategoryModalLabel">Edit Sub Subcategory</h5>
        <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>

      <div class="modal-body">
        <form id="editSubSubcategoryForm" method="POST" action="">
          @csrf
          @method('PUT')

          <!-- SubCategory -->
          <div class="mb-3">
            <label for="editSubcategorySelect" class="form-label">Sub Category</label>
            <select name="subcategory_id" class="form-select" id="editSubcategorySelect" required>
              <option value="">Select Sub Category</option>
              @foreach($subcategories as $subcategory)
                <option value="{{ $subcategory->id }}">
                  {{ $subcategory->name }} ({{ $subcategory->category->name ?? 'No Cat' }})
                </option>
              @endforeach
            </select>
          </div>

          <!-- Name -->
          <div class="mb-3">
            <label for="editName" class="form-label">Name</label>
            <input
              type="text"
              name="name"
              class="form-control"
              id="editName"
              required
            />
          </div>

          <!-- Description -->
          <div class="mb-3">
            <label for="editDescription" class="form-label">Description</label>
            <textarea
              name="description"
              class="form-control"
              id="editDescription"
              rows="3"
            ></textarea>
          </div>

          <!-- Status -->
          <div class="mb-3">
            <label class="form-label">Status</label>
            <div>
              <div class="form-check form-check-inline">
                <input class="form-check-input" type="radio" name="status" id="editStatusActive" value="1">
                <label class="form-check-label" for="editStatusActive">Active</label>
              </div>
              <div class="form-check form-check-inline">
                <input class="form-check-input" type="radio" name="status" id="editStatusInactive" value="0">
                <label class="form-check-label" for="editStatusInactive">Inactive</label>
              </div>
            </div>
          </div>
        </form>
      </div>

      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
        <button type="submit" class="btn btn-warning text-white" form="editSubSubcategoryForm">
          <i class="fas fa-edit me-2"></i> Update
        </button>
      </div>
    </div>
  </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function () {
    const editButtons = document.querySelectorAll('.edit-subsubcategory-btn');
    const editModal = document.getElementById('editSubSubcategoryModal');

    editButtons.forEach(button => {
        button.addEventListener('click', function () {
            const id = this.getAttribute('data-id');
            const name = this.getAttribute('data-name');
            const description = this.getAttribute('data-description');
            const status = this.getAttribute('data-status');
            const subcategory = this.getAttribute('data-subcategory');

            // Set values in the modal form
            editModal.querySelector('form').action = `/admin/subsubcategories/${id}`;
            editModal.querySelector('#editName').value = name;
            editModal.querySelector('#editDescription').value = description;
            editModal.querySelector('#editSubcategorySelect').value = subcategory;
            
            // Set status radio button
            if (status === '1') {
                document.getElementById('editStatusActive').checked = true;
            } else {
                document.getElementById('editStatusInactive').checked = true;
            }
        });
    });
});
</script>

@endsection
