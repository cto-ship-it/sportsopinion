@extends('admin.layouts.master')

@section('title', 'User Point History - ' . $user->name)

@section('content')

<div class="container-fluid">
    <!-- Page Header -->
    <div class="page-header">
        <div class="row align-items-center">
            <div class="col">
                <h4 class="page-title">User Point History - {{ $user->name }}</h4>
                <p class="text-muted mb-0">Email: {{ $user->email }} | Phone: {{ $user->phone ?? 'N/A' }}</p>
            </div>
        </div>
    </div>

    <!-- User Point History Page -->
    <div id="user-point-history-page" class="page-content">

        <!-- User Point History Table -->
        <div class="card">
            <div class="card-body">
                <div class="table-responsive" style="overflow-x:auto; white-space:nowrap;">
                    <table class="table table-hover align-middle" id="userPointHistoryTable">
                        <thead class="table-light">
                            <tr>
                                <th>Sr.No.</th>
                                <th>Question</th>
                                <th>User Answer</th>
                                <th>Points</th>
                                <th>Date</th>
                                <th>Reason</th>
                                <th>Status</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td>1</td>
                                <td class="question-text"><div class="fw-bold">N/A</div></td>
                                <td class="answer-text">N/A</td>
                                <td><span class="badge bg-secondary points-badge">100</span></td>
                                <td>{{ $user->created_at }}</td>
                                <td>SignUp Points</td>
                                <td><span class="badge bg-secondary">Given</span></td>
                            </tr>
                            @forelse($customerAnswers as $index => $answer)
                                <tr>
                                    <td>{{ $index + 2 }}</td>
                                    <td class="question-text">
                                        <div class="fw-bold">{{ $answer->question->question ?? 'N/A' }}</div>
                                    </td>
                                    <td class="answer-text">{{ $answer->answer ?? 'No answer provided' }}</td>
                                    <td>
                                        <span class="badge {{ $answer->points > 0 ? 'bg-success' : 'bg-danger' }} points-badge">
                                            {{ $answer->points > 0 ? '+' : '' }}{{ $answer->points }}
                                        </span>
                                    </td>
                                    <td>{{ $answer->created_at }}</td>
                                    <td>Answer Given</td>
                                    <td>
                                        @if($answer->points > 0)
                                            <span class="badge bg-success">Correct</span>
                                        @else
                                            <span class="badge bg-danger">Incorrect</span>
                                        @endif
                                    </td>
                                </tr>
                            @empty
                                <tr>
                                    <td colspan="7" class="text-center py-4">
                                        <div class="text-muted">
                                            <i class="fas fa-inbox fa-3x mb-3"></i>
                                            <p>No answers found for this user.</p>
                                        </div>
                                    </td>
                                </tr>
                            @endforelse
                        </tbody>
                    </table>
                </div>

                <!-- PAGINATION -->
              @if(isset($customerAnswers) && $customerAnswers->hasPages())
                  @include('admin.layouts.pagination', ['paginator' => $customerAnswers])
              @endif
            </div>
        </div>
    </div>
</div>


<style>
.question-text {
    max-width: 300px;
    white-space: normal;
    word-wrap: break-word;
}
.answer-text {
    max-width: 250px;
    white-space: normal;
    word-wrap: break-word;
}
.points-badge {
    font-size: 0.9em;
    padding: 0.35em 0.65em;
}
</style>
@endsection