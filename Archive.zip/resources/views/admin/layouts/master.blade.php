<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>@yield('title', 'Sport Opinion')</title>
    <!-- Bootstrap CSS -->
    <link
      href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css"
      rel="stylesheet"
    />
    <!-- Chart.js -->
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <!-- Font Awesome -->
    <link
      rel="stylesheet"
      href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css"
    />
    <!-- DataTables -->
    <link
      rel="stylesheet"
      href="https://cdn.datatables.net/1.13.4/css/dataTables.bootstrap5.min.css"
    />
    <style>
        :root {
            --dark-blue: #1e3a5f;
            --yellow: #ffc107;
            --white: #ffffff;
            --light-blue: #2c5282;
            --light-gray: #f7f9fc;
        }
        
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #f8f9fa;
        }
        
        /* Header Styling */
        .navbar {
            background-color: var(--white);
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
            border-bottom: 3px solid var(--yellow);
        }
        
        .navbar-brand {
            color: var(--dark-blue) !important;
            font-weight: 700;
        }
        
        .user-info {
            color: var(--dark-blue);
            font-weight: 500;
        }
        
        /* Alert Styling */
        .alert-success {
            background-color: rgba(40, 167, 69, 0.1);
            border-color: #28a745;
            color: #155724;
        }
        
        .alert-danger {
            background-color: rgba(220, 53, 69, 0.1);
            border-color: #dc3545;
            color: #721c24;
        }
        
        /* Button Styling */
        .btn-primary {
            background-color: var(--dark-blue);
            border-color: var(--dark-blue);
        }
        
        .btn-primary:hover {
            background-color: var(--light-blue);
            border-color: var(--light-blue);
        }
        
        .btn-warning {
            background-color: var(--yellow);
            border-color: var(--yellow);
            color: var(--dark-blue);
        }
        
        .btn-warning:hover {
            background-color: #e0a800;
            border-color: #e0a800;
            color: var(--dark-blue);
        }
        
        /* Card Styling */
        .card {
            border: none;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            border-top: 3px solid var(--yellow);
        }
        
        .card-header {
            background-color: var(--dark-blue);
            color: var(--white);
            font-weight: 600;
        }
        
        /* Table Styling */
        .table thead {
            background-color: var(--dark-blue);
            color: var(--white);
        }
        
        .table tbody tr:hover {
            background-color: rgba(255, 193, 7, 0.1);
        }
        
        /* Footer Styling */
        footer {
            background-color: var(--dark-blue);
            color: var(--white);
            border-top: 3px solid var(--yellow);
        }
        
        /* Modal Styling */
        .modal-header {
            background-color: var(--dark-blue);
            color: var(--white);
        }
        
        .modal-footer {
            border-top: 1px solid #dee2e6;
        }
        
        /* DataTables Customization */
        .dataTables_wrapper .dataTables_length,
        .dataTables_wrapper .dataTables_filter,
        .dataTables_wrapper .dataTables_info,
        .dataTables_wrapper .dataTables_processing,
        .dataTables_wrapper .dataTables_paginate {
            color: var(--dark-blue);
        }
        
        .dataTables_wrapper .dataTables_paginate .paginate_button {
            color: var(--dark-blue) !important;
        }
        
        .dataTables_wrapper .dataTables_paginate .paginate_button.current {
            background: var(--yellow) !important;
            border-color: var(--yellow) !important;
            color: var(--dark-blue) !important;
        }
        
        /* Main Content Area */
        .main-content {
            background-color: var(--light-gray);
            min-height: 100vh;
        }
        
        /* Custom Badges */
        .badge-primary {
            background-color: var(--dark-blue);
            color: var(--white);
        }
        
        .badge-warning {
            background-color: var(--yellow);
            color: var(--dark-blue);
        }
        
        /* Progress Bars */
        .progress {
            background-color: #e9ecef;
        }
        
        .progress-bar {
            background-color: var(--dark-blue);
        }
        
        /* Form Controls */
        .form-control:focus {
            border-color: var(--yellow);
            box-shadow: 0 0 0 0.2rem rgba(255, 193, 7, 0.25);
        }
        
        .form-select:focus {
            border-color: var(--yellow);
            box-shadow: 0 0 0 0.2rem rgba(255, 193, 7, 0.25);
        }
    </style>
    <link rel="stylesheet" href="{{ asset('admin/style.css') }}" />
    <link rel="icon" type="image/png" href="{{ asset('images/logo.png') }}">
  </head>
  <body>
    <div class="d-flex">

    @include('admin.layouts.sidebar')

      <!-- Main Content -->
      <div class="main-content w-100">
        @include('admin.layouts.header')
        
        <!-- Success Message -->
        @if(session('success'))
            <div class="alert alert-success alert-dismissible fade show mt-3 mx-3" role="alert">
                <i class="fas fa-check-circle me-2"></i>
                {{ session('success') }}
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        @endif

        <!-- Error Message -->
        @if(session('error'))
            <div class="alert alert-danger alert-dismissible fade show mt-3 mx-3" role="alert">
                <i class="fas fa-exclamation-circle me-2"></i>
                {{ session('error') }}
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        @endif

        <!-- Validation Errors -->
        @if ($errors->any())
            <div class="alert alert-danger alert-dismissible fade show mt-3 mx-3" role="alert">
                <i class="fas fa-exclamation-triangle me-2"></i>
                <strong>Please fix the following errors:</strong>
                <ul class="mb-0 mt-2">
                    @foreach ($errors->all() as $error)
                        <li>{{ $error }}</li>
                    @endforeach
                </ul>
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        @endif

         @yield('content')
      </div>
    </div>

    @include('admin.layouts.change_password')

    @include('admin.layouts.footer')

    <script src="{{ asset('admin/script.js') }}"></script>

  </body>
</html>