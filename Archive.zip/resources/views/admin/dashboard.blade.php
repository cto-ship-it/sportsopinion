@extends('admin.layouts.master')

@section('title', 'Dashboard')

@section('content')
    <!-- Dashboard Page -->
        <div id="dashboard-page" class="page-content">
          <!-- Stats Cards -->
          <div class="row mb-4">
            <div class="col-md-6 col-lg-3 mb-3">
              <div class="card card-primary h-100">
                <div class="card-body">
                  <div class="stat-card d-flex align-items-center">
                    <div class="icon primary me-3">
                      <i class="fas fa-dollar-sign"></i>
                    </div>
                    <div>
                      <h6 class="mb-1">Total Revenue</h6>
                      <h4 class="mb-0">$24,580</h4>
                      <small class="text-success"
                        ><i class="fas fa-arrow-up"></i> 12.5% from last
                        month</small
                      >
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div class="col-md-6 col-lg-3 mb-3">
              <div class="card card-primary h-100">
                <div class="card-body">
                  <div class="stat-card d-flex align-items-center">
                    <div class="icon primary me-3">
                      <i class="fas fa-shopping-cart"></i>
                    </div>
                    <div>
                      <h6 class="mb-1">Total Orders</h6>
                      <h4 class="mb-0">1,248</h4>
                      <small class="text-success"
                        ><i class="fas fa-arrow-up"></i> 8.3% from last
                        month</small
                      >
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div class="col-md-6 col-lg-3 mb-3">
              <div class="card card-secondary h-100">
                <div class="card-body">
                  <div class="stat-card d-flex align-items-center">
                    <div class="icon secondary me-3">
                      <i class="fas fa-users"></i>
                    </div>
                    <div>
                      <h6 class="mb-1">New Customers</h6>
                      <h4 class="mb-0">184</h4>
                      <small class="text-success"
                        ><i class="fas fa-arrow-up"></i> 5.2% from last
                        month</small
                      >
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div class="col-md-6 col-lg-3 mb-3">
              <div class="card card-secondary h-100">
                <div class="card-body">
                  <div class="stat-card d-flex align-items-center">
                    <div class="icon secondary me-3">
                      <i class="fas fa-star"></i>
                    </div>
                    <div>
                      <h6 class="mb-1">Avg. Rating</h6>
                      <h4 class="mb-0">4.7</h4>
                      <small class="text-success"
                        ><i class="fas fa-arrow-up"></i> 0.3 from last
                        month</small
                      >
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {{-- <!-- Charts Row -->
          <div class="row mb-4">
            <div class="col-lg-8 mb-3">
              <div class="card h-100">
                <div class="card-body">
                  <div
                    class="d-flex justify-content-between align-items-center mb-3"
                  >
                    <h6 class="card-title m-0">Sales Overview</h6>
                    <div class="dropdown">
                      <button
                        class="btn btn-sm btn-outline-secondary dropdown-toggle"
                        type="button"
                        id="salesDropdown"
                        data-bs-toggle="dropdown"
                      >
                        This Month
                      </button>
                      <ul
                        class="dropdown-menu dropdown-menu-end"
                        aria-labelledby="salesDropdown"
                      >
                        <li><a class="dropdown-item" href="#">Today</a></li>
                        <li><a class="dropdown-item" href="#">This Week</a></li>
                        <li>
                          <a class="dropdown-item" href="#">This Month</a>
                        </li>
                        <li><a class="dropdown-item" href="#">This Year</a></li>
                      </ul>
                    </div>
                  </div>
                  <div class="chart-container">
                    <canvas id="salesChart"></canvas>
                  </div>
                </div>
              </div>
            </div>
            <div class="col-lg-4 mb-3">
              <div class="card h-100">
                <div class="card-body">
                  <h6 class="card-title mb-3">Revenue by Category</h6>
                  <div class="chart-container">
                    <canvas id="categoryChart"></canvas>
                  </div>
                </div>
              </div>
            </div>
          </div>

          <!-- Progress and Top Selling -->
          <div class="row mb-4">
            <div class="col-lg-6 mb-3">
              <div class="card h-100">
                <div class="card-body">
                  <h6 class="card-title mb-3">Sales Targets</h6>
                  <div class="mb-3">
                    <div class="d-flex justify-content-between mb-1">
                      <span>Monthly Target</span>
                      <span>$18,000 / $25,000</span>
                    </div>
                    <div class="progress">
                      <div
                        class="progress-bar"
                        role="progressbar"
                        style="width: 72%"
                      ></div>
                    </div>
                  </div>
                  <div class="mb-3">
                    <div class="d-flex justify-content-between mb-1">
                      <span>Quarterly Target</span>
                      <span>$42,500 / $75,000</span>
                    </div>
                    <div class="progress">
                      <div
                        class="progress-bar"
                        role="progressbar"
                        style="width: 56%"
                      ></div>
                    </div>
                  </div>
                  <div>
                    <div class="d-flex justify-content-between mb-1">
                      <span>Annual Target</span>
                      <span>$185,000 / $300,000</span>
                    </div>
                    <div class="progress">
                      <div
                        class="progress-bar"
                        role="progressbar"
                        style="width: 61%"
                      ></div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div class="col-lg-6 mb-3">
              <div class="card h-100">
                <div class="card-body">
                  <div
                    class="d-flex justify-content-between align-items-center mb-3"
                  >
                    <h6 class="card-title m-0">Top Selling Items</h6>
                    <button class="btn btn-sm btn-outline-primary">
                      View All
                    </button>
                  </div>
                  <div class="list-group">
                    <a
                      href="#"
                      class="list-group-item list-group-item-action border-0 top-selling-item"
                    >
                      <div class="d-flex align-items-center">
                        <img
                          src="./asset/image/d-ring.jpg"
                          alt="Product"
                          class="rounded me-3"
                          style="width: 60px; height: 60px"
                        />
                        <div class="flex-grow-1">
                          <h6 class="mb-0">Diamond Ring</h6>
                          <small class="text-muted">SKU: JR001</small>
                        </div>
                        <div class="text-end">
                          <h6 class="mb-0">$1,250</h6>
                          <small class="text-success">45 sold</small>
                        </div>
                      </div>
                    </a>
                    <a
                      href="#"
                      class="list-group-item list-group-item-action border-0 top-selling-item"
                    >
                      <div class="d-flex align-items-center">
                        <img
                          src="./asset/image/p-neckless.jpg"
                          alt="Product"
                          class="rounded me-3"
                          style="width: 60px; height: 60px"
                        />
                        <div class="flex-grow-1">
                          <h6 class="mb-0">Gold Necklace</h6>
                          <small class="text-muted">SKU: JR005</small>
                        </div>
                        <div class="text-end">
                          <h6 class="mb-0">$850</h6>
                          <small class="text-success">38 sold</small>
                        </div>
                      </div>
                    </a>
                    <a
                      href="#"
                      class="list-group-item list-group-item-action border-0 top-selling-item"
                    >
                      <div class="d-flex align-items-center">
                        <img
                          src="./asset/image/s-chain.jpg"
                          alt="Product"
                          class="rounded me-3"
                          style="width: 60px; height: 60px"
                        />
                        <div class="flex-grow-1">
                          <h6 class="mb-0">Silver Bracelet</h6>
                          <small class="text-muted">SKU: JR012</small>
                        </div>
                        <div class="text-end">
                          <h6 class="mb-0">$450</h6>
                          <small class="text-success">32 sold</small>
                        </div>
                      </div>
                    </a>
                    <a
                      href="#"
                      class="list-group-item list-group-item-action border-0 top-selling-item"
                    >
                      <div class="d-flex align-items-center">
                        <img
                          src="./asset/image/dg-earrings.jpg"
                          alt="Product"
                          class="rounded me-3"
                          style="width: 60px; height: 60px"
                        />
                        <div class="flex-grow-1">
                          <h6 class="mb-0">Pearl Earrings</h6>
                          <small class="text-muted">SKU: JR008</small>
                        </div>
                        <div class="text-end">
                          <h6 class="mb-0">$320</h6>
                          <small class="text-success">28 sold</small>
                        </div>
                      </div>
                    </a>
                  </div>
                </div>
              </div>
            </div>
          </div>

          <!-- Recent Orders -->
          <div class="row">
            <div class="col-12">
              <div class="card">
                <div class="card-body">
                  <div
                    class="d-flex justify-content-between align-items-center mb-3"
                  >
                    <h6 class="card-title m-0">Recent Orders</h6>
                    <button class="btn btn-sm btn-outline-primary">
                      View All
                    </button>
                  </div>
                  <div class="table-responsive">
                    <table class="table table-hover">
                      <thead>
                        <tr>
                          <th>Order ID</th>
                          <th>Customer</th>
                          <th>Date</th>
                          <th>Amount</th>
                          <th>Status</th>
                          <th>Action</th>
                        </tr>
                      </thead>
                      <tbody>
                        <tr>
                          <td>#ORD-2023-001</td>
                          <td>John Smith</td>
                          <td>May 12, 2023</td>
                          <td>$1,250.00</td>
                          <td>
                            <span class="badge bg-success">Completed</span>
                          </td>
                          <td>
                            <button class="btn btn-sm btn-outline-secondary">
                              View
                            </button>
                          </td>
                        </tr>
                        <tr>
                          <td>#ORD-2023-002</td>
                          <td>Sarah Johnson</td>
                          <td>May 11, 2023</td>
                          <td>$850.00</td>
                          <td>
                            <span class="badge bg-warning text-dark"
                              >Processing</span
                            >
                          </td>
                          <td>
                            <button class="btn btn-sm btn-outline-secondary">
                              View
                            </button>
                          </td>
                        </tr>
                        <tr>
                          <td>#ORD-2023-003</td>
                          <td>Michael Brown</td>
                          <td>May 10, 2023</td>
                          <td>$450.00</td>
                          <td><span class="badge bg-primary">Shipped</span></td>
                          <td>
                            <button class="btn btn-sm btn-outline-secondary">
                              View
                            </button>
                          </td>
                        </tr>
                        <tr>
                          <td>#ORD-2023-004</td>
                          <td>Emily Davis</td>
                          <td>May 9, 2023</td>
                          <td>$1,580.00</td>
                          <td>
                            <span class="badge bg-danger">Cancelled</span>
                          </td>
                          <td>
                            <button class="btn btn-sm btn-outline-secondary">
                              View
                            </button>
                          </td>
                        </tr>
                        <tr>
                          <td>#ORD-2023-005</td>
                          <td>Robert Wilson</td>
                          <td>May 8, 2023</td>
                          <td>$320.00</td>
                          <td>
                            <span class="badge bg-success">Completed</span>
                          </td>
                          <td>
                            <button class="btn btn-sm btn-outline-secondary">
                              View
                            </button>
                          </td>
                        </tr>
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
            </div>
          </div> --}}
        </div>
@endsection
