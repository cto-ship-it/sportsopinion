@extends('admin.layouts.master')

@section('title', 'Subcategories')

@section('content')

 <!-- Subcategories Page -->
        <div id="subcategories-page" class="page-content">
          <div class="page-header justify-content-between">
            <!-- Breadcrumb Navigation -->
            <nav aria-label="breadcrumb">
              <ol class="breadcrumb">
                <li class="breadcrumb-item">
                  <a href="">Categories</a>
                </li>
                <li class="breadcrumb-item active" aria-current="page">
                  {{ $category->name ?? 'Subcategories' }}
                </li>
              </ol>
            </nav>

            <h4 class="page-title">Subcategory Management</h4>

            <button
              type="button"
              class="btn bg-info text-white"
              data-bs-toggle="modal"
              data-bs-target="#addSubcategoryModal"
            >
              <i class="fas fa-plus me-2"></i> Add Subcategory
            </button>
          </div>

          <div class="card">
            <div class="card-body">
              <div class="row g-3 align-items-center">
                <!-- Search Bar -->
                <x-search :action="route('subcategories.index')" placeholder="Search subcategories..." />

                <!-- Export Button / Filter Button -->
                <div class="col-md-4">
                  <div class="d-flex justify-content-end gap-2">
                    <button class="btn btn-outline-secondary" id="resetFilters">
                      <i class="fas fa-sync-alt"></i>
                    </button>
                  </div>
                </div>
              </div>
            </div>
          </div>

          <div class="card">
            <div class="card-body">
            <div class="table-responsive">
                <table class="table table-hover" id="subcategoriesTable">
                <thead>
                    <tr>
                    <th class="text-center">Sr.No.</th>
                    <th class="text-center">Date</th>
                    <th class="text-center">Name</th>
                    <th class="text-center">Description</th>
                    <th class="text-center">Status</th>
                    <th class="text-center">Edit / Delete</th>
                    </tr>
                </thead>
                <tbody>
                    @forelse($subcategories as $key => $subcategory)
                    <tr>
                        <td class="text-center">{{ $key + 1 }}</td>
                        <td class="text-center">{{ $subcategory->created_at->format('d M Y') }}</td>
                        <td class="text-center">{{ $subcategory->name }}</td>
                        <td class="text-center">{{ $subcategory->description }}</td>
                        <td class="text-center">
                          <span class="badge bg-{{ $subcategory->status ? 'success' : 'secondary' }}">
                            {{ $subcategory->status ? 'Active' : 'Inactive' }}
                          </span>
                        </td>

                        <td class="text-center">
                        <!-- Edit Button -->
                        <button
                            type="button"
                            class="btn btn-sm btn-warning me-1 edit-subcategory-btn"
                            data-bs-toggle="modal"
                            data-bs-target="#editSubcategoryModal"
                            data-subcategory-id="{{ $subcategory->id }}"
                            data-subcategory-name="{{ $subcategory->name }}"
                            data-subcategory-description="{{ $subcategory->description }}"
                            data-subcategory-status="{{ $subcategory->status }}"
                            data-subcategory-category="{{ $subcategory->category_id }}"
                        >
                            <i class="fas fa-edit me-1"></i> Edit
                        </button>

                        <!-- Delete Button -->
                        <form action="{{ route('subcategories.destroy', $subcategory->id) }}" method="POST" class="d-inline">
                            @csrf
                            @method('DELETE')
                            <button type="submit" class="btn btn-sm btn-danger" onclick="return confirm('Are you sure you want to delete this subcategory?')">
                            <i class="fas fa-trash me-1"></i> Delete
                            </button>
                        </form>
                        </td>
                    </tr>
                    @empty
                    <tr>
                        <td colspan="6" class="text-center">No subcategories found.</td>
                    </tr>
                    @endforelse
                </tbody>
                </table>
            </div>
             <!-- PAGINATION -->
              @if(isset($subcategories) && $subcategories->hasPages())
                  @include('admin.layouts.pagination', ['paginator' => $subcategories])
              @endif
            </div>
          </div>
        </div>

       <!-- Add Subcategory Modal -->
        <div class="modal fade" id="addSubcategoryModal" tabindex="-1" aria-labelledby="addSubcategoryModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-md">
            <div class="modal-content">
            <div class="modal-header bg-primary text-white">
                <h5 class="modal-title" id="addSubcategoryModalLabel">Add Subcategory</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>

            <div class="modal-body">
                <form id="addSubcategoryForm" method="POST" action="{{ route('subcategories.store') }}">
                @csrf

                <!-- Category (if needed) -->
                <div class="mb-3">
                    <label for="categorySelect" class="form-label">Category</label>
                    <select name="category_id" class="form-select" id="categorySelect" required>
                      <option value="">Select Category</option>
                      @foreach($categories as $category)
                        <option value="{{ $category->id }}" {{ old('category_id') == $category->id ? 'selected' : '' }}>
                          {{ $category->name }}
                        </option>
                      @endforeach
                    </select>
                    @error('category_id')
                    <span class="text-danger">{{ $message }}</span>
                    @enderror
                </div>

                <!-- Name -->
                <div class="mb-3">
                    <label for="subcategoryName" class="form-label">Name</label>
                    <input
                    type="text"
                    name="name"
                    class="form-control"
                    id="subcategoryName"
                    placeholder="Enter subcategory name"
                    value="{{ old('name') }}"
                    required
                    />
                    @error('name')
                    <span class="text-danger">{{ $message }}</span>
                    @enderror
                </div>

                <!-- Description -->
                <div class="mb-3">
                    <label for="subcategoryDescription" class="form-label">Description</label>
                    <textarea
                    name="description"
                    class="form-control"
                    id="subcategoryDescription"
                    rows="3"
                    placeholder="Enter subcategory description"
                    >{{ old('description') }}</textarea>
                    @error('description')
                    <span class="text-danger">{{ $message }}</span>
                    @enderror
                </div>

                <!-- Status -->
                <div class="mb-3">
                  <label class="form-label">Status</label>
                  <div>
                    <div class="form-check form-check-inline">
                      <input class="form-check-input" type="radio" name="status" id="statusActive" value="1" checked>
                      <label class="form-check-label" for="statusActive">Active</label>
                    </div>
                    <div class="form-check form-check-inline">
                      <input class="form-check-input" type="radio" name="status" id="statusInactive" value="0">
                      <label class="form-check-label" for="statusInactive">Inactive</label>
                    </div>
                  </div>
                  @error('status')
                  <span class="text-danger">{{ $message }}</span>
                  @enderror
                </div>
                </form>
            </div>

            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">
                Cancel
                </button>
                <button type="submit" class="btn btn-primary" form="addSubcategoryForm">
                <i class="fas fa-plus me-2"></i> Add Subcategory
                </button>
            </div>
            </div>
        </div>
        </div>

     <!-- Edit Subcategory Modal -->
<div class="modal fade" id="editSubcategoryModal" tabindex="-1" aria-labelledby="editSubcategoryModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-md">
    <div class="modal-content">
      <div class="modal-header bg-warning text-white">
        <h5 class="modal-title" id="editSubcategoryModalLabel">Edit Subcategory</h5>
        <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>

      <div class="modal-body">
        <form id="editSubcategoryForm" method="POST" action="">
          @csrf
          @method('PUT')

          <!-- Category -->
          <div class="mb-3">
            <label for="editCategorySelect" class="form-label">Category</label>
            <select name="category_id" class="form-select" id="editCategorySelect" required>
              <option value="">Select Category</option>
              @foreach($categories as $category)
                <option value="{{ $category->id }}">{{ $category->name }}</option>
              @endforeach
            </select>
          </div>

          <!-- Name -->
          <div class="mb-3">
            <label for="editSubcategoryName" class="form-label">Name</label>
            <input
              type="text"
              name="name"
              class="form-control"
              id="editSubcategoryName"
              required
            />
          </div>

          <!-- Description -->
          <div class="mb-3">
            <label for="editSubcategoryDescription" class="form-label">Description</label>
            <textarea
              name="description"
              class="form-control"
              id="editSubcategoryDescription"
              rows="3"
            ></textarea>
          </div>

          <!-- Status -->
          <div class="mb-3">
            <label class="form-label">Status</label>
            <div>
              <div class="form-check form-check-inline">
                <input class="form-check-input" type="radio" name="status" id="editStatusActive" value="1">
                <label class="form-check-label" for="editStatusActive">Active</label>
              </div>
              <div class="form-check form-check-inline">
                <input class="form-check-input" type="radio" name="status" id="editStatusInactive" value="0">
                <label class="form-check-label" for="editStatusInactive">Inactive</label>
              </div>
            </div>
          </div>
        </form>
      </div>

      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
        <button type="submit" class="btn btn-warning text-white" form="editSubcategoryForm">
          <i class="fas fa-edit me-2"></i> Update Subcategory
        </button>
      </div>
    </div>
  </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function () {
    const editButtons = document.querySelectorAll('.edit-subcategory-btn');
    const editModal = document.getElementById('editSubcategoryModal');

    editButtons.forEach(button => {
        button.addEventListener('click', function () {
            const subcategoryId = this.getAttribute('data-subcategory-id');
            const subcategoryName = this.getAttribute('data-subcategory-name');
            const subcategoryDescription = this.getAttribute('data-subcategory-description');
            const subcategoryStatus = this.getAttribute('data-subcategory-status');
            const subcategoryCategory = this.getAttribute('data-subcategory-category');

            // Set values in the modal form
            editModal.querySelector('form').action = `/admin/subcategories/${subcategoryId}`;
            editModal.querySelector('#editSubcategoryName').value = subcategoryName;
            editModal.querySelector('#editSubcategoryDescription').value = subcategoryDescription;
            editModal.querySelector('#editCategorySelect').value = subcategoryCategory;
            
            // Set status radio button
            if (subcategoryStatus === '1') {
                document.getElementById('editStatusActive').checked = true;
            } else {
                document.getElementById('editStatusInactive').checked = true;
            }
        });
    });
});
</script>

@endsection