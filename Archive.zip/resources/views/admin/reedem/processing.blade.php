@extends('admin.layouts.master')

@section('title', 'Reedem')

@section('content')
<style>
  .reward-img-thumb {
    width: 50px;
    height: 50px;
    object-fit: cover;
}

</style>
<!-- Products Page -->
        <div id="products-page" class="page-content">
          <div class="page-header">
            <h4 class="page-title">Pending Management</h4>
          </div>

          <div class="card">
            <div class="card-body">
              <div class="row g-3 align-items-center">
                <!-- Search Bar -->
                <div class="col-md-8">
                  <div class="input-group me-3" style="width: 250px">
                    <input
                      type="text"
                      class="form-control form-control-sm"
                      placeholder="Search..."
                    />
                    <button
                      class="btn btn-sm btn-outline-secondary"
                      type="button"
                    >
                      <i class="fas fa-search"></i>
                    </button>
                  </div>
                </div>

                <!-- Export Button / Filter Button -->
                {{-- <div class="col-md-4">
                  <div class="d-flex justify-content-end gap-2">
                    <a
                      href="#"
                      class="btn btn-outline-secondary"
                      data-bs-toggle="modal"
                      data-bs-target="#exportFeedbackModal"
                    >
                      <i class="fas fa-file-export me-2"></i> Export
                    </a>
                    <button
                      class="btn btn-outline-primary"
                      data-bs-toggle="modal"
                      data-bs-target="#productFilterModal"
                    >
                      <i class="fas fa-filter me-2"></i> Filters
                    </button>
                    <button class="btn btn-outline-secondary" id="resetFilters">
                      <i class="fas fa-sync-alt"></i>
                    </button>
                  </div>
                </div> --}}
              </div>
            </div>
          </div>

          <div class="card">
            <div class="card-body">
              <div class="table-responsive">
                <table class="table table-hover" id="rewardsTable">
                  <thead>
                    <tr>
                      <th>Sr.No.</th>
                      <th>Date</th>
                      <th>Name</th>
                      <th>Phone No.</th>
                      <th>Reward Image</th>
                      <th>Reward Name</th>
                      <th>Points</th>
                      {{-- <th>Pending Points</th> --}}
                      <th>Status</th>
                      <th>Actions</th>
                    </tr>
                  </thead>
                  {{-- @dd($rewards) --}}
                  <tbody>
                  @forelse ($redeemRequests as $index => $request)
                      <tr>
                          <td>{{ $index + 1 }}</td>
                          <td>{{ $request->created_at->format('d M Y') }}</td>
                          <td>{{ $request->customer->name ?? 'N/A' }}</td>
                          <td>{{ $request->customer->phone ?? 'N/A' }}</td>

                          {{-- Reward Info --}}
                          <td>
                              <img
                                  src="{{ $request->reward && $request->reward->image ? asset('storage/' . $request->reward->image) : asset('images/default.png') }}"
                                  class="reward-img-thumb rounded-circle"
                                  alt="Reward"
                              />
                          </td>
                          <td>{{ $request->reward->name ?? 'N/A' }}</td>

                          {{-- Points --}}
                          <td>{{ $request->points }}</td> 

                          {{-- Pending Points (example logic — adjust as needed) --}}
                          {{-- <td>{{ $request->reward->points_required - $request->points ?? 0 }}</td> --}}

                          {{-- Status --}}
                          <td>
                              @php
                                  $status = strtolower($request->status);
                                  $statusClass = match($status) {
                                      'pending' => 'bg-warning text-dark',
                                      'processing' => 'bg-info text-dark',
                                      'completed', 'complete' => 'bg-success',
                                      'cancelled', 'canceled' => 'bg-danger',
                                      default => 'bg-secondary'
                                  };
                              @endphp
                              <span class="badge {{ $statusClass }}">{{ ucfirst($status) }}</span>
                          </td>

                          {{-- Actions --}}
                          <td class="text-center">
                              <div class="dropdown">
                                  <button class="btn btn-sm" type="button" data-bs-toggle="dropdown" aria-expanded="false">
                                      <i class="fas fa-ellipsis-v"></i>
                                  </button>
                                  <ul class="dropdown-menu dropdown-menu-end">
                                      <li><h6 class="dropdown-header">Change Status</h6></li>

                                      <li>
                                          <a class="dropdown-item text-info"
                                            href="{{ route('redeem.updateStatus', ['id' => $request->id, 'status' => 'pending']) }}">
                                              <i class="fas fa-spinner me-2"></i> Pending
                                          </a>
                                      </li>
                                      <li>
                                          <a class="dropdown-item text-success"
                                            href="{{ route('redeem.updateStatus', ['id' => $request->id, 'status' => 'complete']) }}">
                                              <i class="fas fa-check-circle me-2"></i> Complete
                                          </a>
                                      </li>
                                      <li>
                                          <a class="dropdown-item text-danger"
                                            href="{{ route('redeem.updateStatus', ['id' => $request->id, 'status' => 'cancel']) }}">
                                              <i class="fas fa-times-circle me-2"></i> Cancel
                                          </a>
                                      </li>
                                  </ul>
                              </div>
                          </td>
                      </tr>
                  @empty
                      <tr>
                          <td colspan="11" class="text-center text-muted">No redeem requests found</td>
                      </tr>
                  @endforelse
                  </tbody>
                </table>
              </div>
              <!-- PAGINATION -->
              @if(isset($redeemRequests) && $redeemRequests->hasPages())
                  @include('admin.layouts.pagination', ['paginator' => $redeemRequests])
              @endif
            </div>
          </div>
        </div>
@endsection
