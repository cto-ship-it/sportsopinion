@extends('admin.layouts.master')

@section('title','Points')

@section('content')

<div class="page-header">
          <h4 class="page-title">Points Management</h4>
        </div>

        <!-- Orders Page -->
        <div id="orders-page" class="page-content">
          <div class="card">
            <div class="card-body">
              <div class="row g-3 align-items-center">
                <!-- Search Bar -->
                <x-search :action="route('admin.points')" placeholder="Search..." />

                <!-- Export Button / Filter Button -->
                {{-- <div class="col-md-4">
                  <div class="d-flex justify-content-end gap-2">
                    <a
                      href="#"
                      class="btn btn-outline-secondary"
                      data-bs-toggle="modal"
                      data-bs-target="#exportFeedbackModal"
                    >
                      <i class="fas fa-file-export me-2"></i> Export
                    </a>
                    <button
                      class="btn btn-outline-primary"
                      data-bs-toggle="modal"
                      data-bs-target="#orderFilterModal"
                    >
                      <i class="fas fa-filter me-2"></i> Filters
                    </button>
                    <button class="btn btn-outline-secondary" id="resetFilters">
                      <i class="fas fa-sync-alt"></i>
                    </button>
                  </div>
                </div> --}}
              </div>
            </div>
          </div>

          <div class="card">
              <div class="card-body">
                  <div class="table-responsive">
                      <table class="table table-hover" id="userPointsTable">
                          <thead>
                              <tr>
                                  <th>Sr.No.</th>
                                  <th>ID</th>
                                  <th>Date</th>
                                  <th>Photo</th>
                                  <th>Username</th>
                                  <th>Phone</th>
                                  <th>Points</th>
                              </tr>
                          </thead>
                          <tbody>
                              @foreach($users as $index => $user)
                                  <tr>
                                      <td>{{ $index + 1 }}</td>
                                      <td>USR{{ str_pad($user->id, 3, '0', STR_PAD_LEFT) }}</td>
                                      <td>{{ $user->created_at->format('d M Y') }}</td>
                                      <td>
                                        <img
                                            src="{{ $user->profile_pic }}"
                                            alt="User Photo"
                                            style="width: 50px; height: 50px; border-radius: 50%; object-fit: cover;"
                                        />
                                      </td>
                                      <td>{{ $user->name }}</td>
                                      <td>{{ $user->phone }}</td>
                                      <td>{{ number_format($user->points) }}</td>
                                  </tr>
                              @endforeach
                          </tbody>
                      </table>
                  </div>
                  <!-- PAGINATION -->
              @if(isset($users) && $users->hasPages())
                  @include('admin.layouts.pagination', ['paginator' => $users])
              @endif
              </div>
          </div>
        </div>

@endsection