<?php
require __DIR__ . '/vendor/autoload.php';

$app = require_once __DIR__ . '/bootstrap/app.php';
$app->make('Illuminate\Contracts\Console\Kernel')->bootstrap();

use Illuminate\Http\Request;
use App\Http\Controllers\Api\CustomerAuthController;

// Create request
$request = Request::create('/api/customer/signup', 'POST', [
    'name' => 'Test User',
    'email' => 'priyanshs042005@gmail.com',
]);

// Create controller
$controller = app(CustomerAuthController::class);

// Call signup
try {
    $response = $controller->signup($request);
    echo "Response Status: " . $response->getStatusCode() . "\n";
    echo "Response Body: " . $response->getContent() . "\n";
} catch (Exception $e) {
    echo "Error: " . $e->getMessage() . "\n";
    echo "Trace: " . $e->getTraceAsString() . "\n";
}
