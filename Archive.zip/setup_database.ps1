$env:Path += ";C:\Program Files\MySQL\MySQL Server 8.0\bin"

Write-Host "Creating database..." -ForegroundColor Yellow
mysql -u root -e "CREATE DATABASE IF NOT EXISTS ``sport-opinion`` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;"

if ($LASTEXITCODE -eq 0) {
    Write-Host "Database created successfully!" -ForegroundColor Green
    Write-Host "Importing SQL file..." -ForegroundColor Yellow
    mysql -u root "sport-opinion" < "d:\sports_opinion_project\backend\sport-opinion (3).sql"
    
    if ($LASTEXITCODE -eq 0) {
        Write-Host "Database imported successfully!" -ForegroundColor Green
    } else {
        Write-Host "Failed to import database" -ForegroundColor Red
    }
} else {
    Write-Host "Failed to create database" -ForegroundColor Red
}

Write-Host "`nPress any key to close..." -ForegroundColor Cyan
$null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
