<?php

require __DIR__ . '/vendor/autoload.php';

$app = require_once __DIR__ . '/bootstrap/app.php';
$app->make('Illuminate\Contracts\Console\Kernel')->bootstrap();

use App\Models\User;
use Illuminate\Support\Facades\Hash;

echo "Resetting admin password...\n";

$user = User::where('email', 'admin@gmail.com')->first();

if ($user) {
    $user->password = Hash::make('admin123');
    $user->save();
    
    echo "\n✓ Password reset successfully!\n\n";
    echo "Admin Login Credentials:\n";
    echo "Email: admin@gmail.com\n";
    echo "Password: admin123\n\n";
    echo "Login URL: http://127.0.0.1:8000/login\n";
} else {
    echo "✗ Admin user not found!\n";
}
