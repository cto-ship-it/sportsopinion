<?php

use App\Http\Controllers\Api\BannerController;
use App\Http\Controllers\Api\CategoryController;
use App\Http\Controllers\Api\CustomerAuthController;
use App\Http\Controllers\Api\CustomerBankDetailController;
use App\Http\Controllers\Api\CustomerController;
use App\Http\Controllers\Api\CustomerRedeemRequestController;
use App\Http\Controllers\Api\FaqController;
use App\Http\Controllers\Api\LanguageController;
use App\Http\Controllers\Api\NotificationController;
use App\Http\Controllers\Api\QuestionController;
use App\Http\Controllers\Api\RewardController;
use App\Http\Controllers\Api\SubcategoryController;
use App\Http\Controllers\Api\SubSubCategoryController;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "api" middleware group. Make something great!
|
*/

Route::middleware('auth:sanctum')->get('/user', function (Request $request) {
    return $request->user();
});

// Language routes (public)
Route::get('/languages', [LanguageController::class, 'getSupportedLanguages']);
Route::get('/languages/current', [LanguageController::class, 'getCurrentLanguage']);

Route::prefix('customer')->group(function () {

    Route::post('/signup', [CustomerAuthController::class, 'signup']);
    Route::post('/login', [CustomerAuthController::class, 'login']);
    Route::post('/forgot-mpin',[CustomerAuthController::class,'forgotMpin']);

    Route::middleware('auth:sanctum')->group(function (){
        Route::post('/logout',[CustomerAuthController::class,'logout']);
        Route::get('/profile',[CustomerAuthController::class,'profile']);
        Route::post('/profile',[CustomerAuthController::class,'updateProfile']);
        Route::get('/categories',[CategoryController::class,'index']);
        Route::get('/subcategories/{id}',[SubcategoryController::class,'index']);
        Route::get('/subsubcategories/{id}',[SubSubCategoryController::class,'index']);
        Route::get('/faqs',[FaqController::class,'index']);
        Route::get('/banners',[BannerController::class,'index']);
        Route::get('/questions/{id}', [QuestionController::class, 'getBySubcategory']);
        Route::post('/answers', [CustomerController::class, 'store']);
        Route::get('/rewards', [RewardController::class, 'index']);
        Route::post('/fcm-token', [NotificationController::class, 'storeOrUpdate']);
        Route::get('/customer-answers', [CustomerController::class, 'index']);
        Route::get('/top-customers', [CustomerController::class, 'topCustomers']);        
        Route::get('/redeem-request/{reward}', [CustomerRedeemRequestController::class, 'store']);
        Route::get('/notifications', [NotificationController::class, 'index']);
        Route::post('/notifications/mark-read', [NotificationController::class, 'markAsRead']);
        Route::get('/notifications/unread-count', [NotificationController::class, 'unreadCount']);     
        Route::apiResource('customer-bank-details', CustomerBankDetailController::class);
    });

});

Route::get('/test-fcm', function() {
    $factory = (new \Kreait\Firebase\Factory)
        ->withServiceAccount(storage_path('app/sport-opinion-firebase-adminsdk-fbsvc-31dd488e3e.json'));

    $messaging = $factory->createMessaging();

    $token = 'eFpNBbPMRduVENlP_aVq5w:APA91bEzMTSnB6x2OuHyPyb32_peNTPd_yD_4_vDw-9Mru8_VCTY8ta-5Ix9eTV7oNUE4CcQjymSDs7V2w1iC9IEBsORHL4wiuvg9u18f5suIKx-ymTLUgI';
    
    $message = \Kreait\Firebase\Messaging\CloudMessage::withTarget('token', trim($token))
        ->withNotification(\Kreait\Firebase\Messaging\Notification::create('Test Title', 'Test Body'));

    try {
        $messaging->send($message);
        return 'Notification sent!';
    } catch (\Exception $e) {
        return $e->getMessage();
    }
});

