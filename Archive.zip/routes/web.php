<?php

use App\Http\Controllers\AuthController;
use App\Http\Controllers\BannerController;
use App\Http\Controllers\CategoryController;
use App\Http\Controllers\CustomerController;
use App\Http\Controllers\DashboardController;
use App\Http\Controllers\FAQController;
use App\Http\Controllers\PointController;
use App\Http\Controllers\QuestionController;
use App\Http\Controllers\ReedemController;
use App\Http\Controllers\RewardsController;
use App\Http\Controllers\SubCategoryController;
use App\Http\Controllers\SubSubCategoryController;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/

// Route::get('/', function () {
//     return view('welcome');
// });

Route::get('/', function () {
    return response()->file(public_path('homepage/sportsopinion/index.html'));
});


Route::get('/privacy', function () {
    return view('privacy');
})->name('website.privacy');


Route::get('/login', [AuthController::class, 'showLoginForm'])->name('login');
Route::post('/login', [AuthController::class, 'login'])->name('login.submit');

Route::middleware(['auth'])->prefix('admin')->group(function () {
    Route::post('/logout', [AuthController::class, 'logout'])->name('logout');
    Route::get('/dashboard',[DashboardController::class,'index'])->name('admin.dashboard');
    Route::get('/users',[CustomerController::class,'index'])->name('admin.users');
    Route::post('/users/{id}/toggle-status', [CustomerController::class, 'toggleStatus'])->name('admin.users.toggleStatus');
    Route::get('/users/{encryptedUserId}/point-history', [CustomerController::class, 'pointHistory'])
    ->name('admin.users.point-history');
    Route::get('/points',[PointController::class,'index'])->name('admin.points');
    Route::get('/rewards',[RewardsController::class,'index'])->name('admin.rewards');
    Route::post('/rewards/store', [RewardsController::class, 'store'])->name('rewards.store');
    Route::delete('/rewards/{reward}', [RewardsController::class, 'destroy'])->name('rewards.destroy');
    Route::put('/rewards/{reward}', [RewardsController::class, 'update'])->name('rewards.update');
    Route::get('/reedem-pending',[ReedemController::class,'pending'])->name('admin.reedem.pending');
    Route::get('/rewards/update-status/{id}/{status}', [ReedemController::class, 'updateStatus'])->name('redeem.updateStatus');
    Route::get('/reedem-processing',[ReedemController::class,'processing'])->name('admin.reedem.processing');
    Route::get('/reedem-complete',[ReedemController::class,'complete'])->name('admin.reedem.complete');
    Route::get('/reedem-cancel',[ReedemController::class,'cancel'])->name('admin.reedem.cancel');
    Route::get('/banners',[BannerController::class,'index'])->name('admin.banners');
    Route::post('/banners', [BannerController::class, 'store'])->name('banners.store');
    Route::delete('/banners/{banner}', [BannerController::class, 'destroy'])->name('banners.destroy');
    Route::put('/banners/{banner}', [BannerController::class, 'update'])->name('banners.update');
    Route::get('/faqs', [FAQController::class, 'index'])->name('admin.faqs');
    Route::post('/faqs', [FAQController::class, 'store'])->name('faqs.store');
    Route::put('/faqs/{fAQ}', [FaqController::class, 'update'])->name('faqs.update');
    Route::delete('/faqs/{fAQ}', [FAQController::class, 'destroy'])->name('faqs.destroy');
    Route::get('/all-questions',[QuestionController::class,'index'])->name('admin.question');
    Route::post('/questions/store', [QuestionController::class, 'store'])->name('questions.store');
    Route::get('/questions', [QuestionController::class, 'index'])->name('questions.index');
    Route::post('/questions/store', [QuestionController::class, 'store'])->name('questions.store');
    Route::delete('/questions/{id}', [QuestionController::class, 'destroy'])->name('questions.destroy');
    Route::get('/questions/{id}/status/{status}', [QuestionController::class, 'updateStatus'])->name('questions.updateStatus');
    Route::put('/questions/{id}', [QuestionController::class, 'update'])->name('questions.update');

    Route::resource('categories', \App\Http\Controllers\CategoryController::class);
    Route::post('categories/{category}/status', [\App\Http\Controllers\CategoryController::class, 'updateStatus'])->name('categories.status');
    
    // Subcategory CRUD
    Route::get('/subcategories', [SubcategoryController::class, 'index'])->name('subcategories.index');
    Route::post('/subcategories', [SubCategoryController::class, 'store'])->name('subcategories.store');
    Route::get('/subcategories/{subcategory}/edit', [SubCategoryController::class, 'edit'])->name('subcategories.edit');
    Route::put('/subcategories/{subcategory}', [SubCategoryController::class, 'update'])->name('subcategories.update');
    Route::delete('/subcategories/{subcategory}', [SubCategoryController::class, 'destroy'])->name('subcategories.destroy');

    // SubSubCategory CRUD
    Route::resource('subsubcategories', SubSubCategoryController::class);

    Route::get('/get-subcategories/{categoryId}', function($categoryId) {
        $subcategories = \App\Models\SubCategory::where('category_id', $categoryId)
            ->where('status', true) 
            ->get(['id', 'name']);
        
        return response()->json($subcategories);
    })->name('get.subcategories');

    Route::get('/get-subsubcategories/{subcategoryId}', function($subcategoryId) {
        $subsubcategories = \App\Models\SubSubCategory::where('subcategory_id', $subcategoryId)
            ->where('status', true)
            ->get(['id', 'name']);
        return response()->json($subsubcategories);
    })->name('get.subsubcategories');

    Route::post('/user/password/update', [AuthController::class, 'updatePassword'])->name('user.password.update');

      // Role Management
    Route::resource('roles', App\Http\Controllers\RoleController::class);

    // Permission Management
    Route::resource('permissions', App\Http\Controllers\PermissionController::class);
});
