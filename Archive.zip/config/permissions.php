<?php

return [
    'dashboard' => 'Dashboard',
    'users' => 'Users',
    'points' => 'Points',
    'categories' => 'Categories',
    'subcategories' => 'Subcategories',
    'rewards' => 'Rewards',
    'reedem.pending' => 'Reedem Pending',
    'reedem.processing' => 'Reedem Approved',
    'reedem.complete' => 'Reedem Complete',
    'reedem.cancel' => 'Reedem Cancel',
    'question' => 'Questions',
    'banners' => 'Banners',
    'faqs' => 'FAQs',
    'roles' => 'Roles',
    'permissions' => 'Permissions',
];
