<?php $__env->startSection('title', 'Banner'); ?>

<?php $__env->startSection('content'); ?>

<!-- Customers Page -->
        <div id="customers-page" class="page-content">
          <div class="page-header justify-content-between">
            <h4 class="page-title">Customer Management</h4>

            <button
              type="button"
              class="btn bg-info text-white"
              data-bs-toggle="modal"
              data-bs-target="#addBannerModal"
            >
              <i class="fas fa-star me-2"></i> Add Banner
            </button>
          </div>

          <div class="card">
            <div class="card-body">
              <div class="row g-3 align-items-center">
                <!-- Search Bar -->
                <div class="col-md-8">
                  <div class="input-group me-3" style="width: 250px">
                    <input
                      type="text"
                      class="form-control form-control-sm"
                      placeholder="Search..."
                    />
                    <button
                      class="btn btn-sm btn-outline-secondary"
                      type="button"
                    >
                      <i class="fas fa-search"></i>
                    </button>
                  </div>
                </div>

                <!-- Export Button / Filter Button -->
                <div class="col-md-4">
                  <div class="d-flex justify-content-end gap-2">
                    <!-- <a
                      href="#"
                      class="btn btn-outline-secondary"
                      data-bs-toggle="modal"
                      data-bs-target="#exportFeedbackModal"
                    >
                      <i class="fas fa-file-export me-2"></i> Export
                    </a> -->
                    <!-- Filter Trigger Button -->
                    <!-- <button
                      type="button"
                      class="btn btn-outline-primary"
                      data-bs-toggle="modal"
                      data-bs-target="#customerFilterModal"
                    >
                      <i class="fas fa-filter me-1"></i> Filter
                    </button> -->
                    <button class="btn btn-outline-secondary" id="resetFilters">
                      <i class="fas fa-sync-alt"></i>
                    </button>
                  </div>
                </div>
              </div>
            </div>
          </div>

          <div class="card">
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-hover" id="bannersTable">
                        <thead>
                            <tr>
                                <th class="text-center">Sr.No.</th>
                                <th class="text-center">Date</th>
                                <th class="text-center">Expiry Date</th>
                                <th class="text-center">Banner Location</th>
                                <th class="text-center">Banner Image</th>
                                <th class="text-center">Link</th>
                                <th class="text-center">Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__empty_1 = true; $__currentLoopData = $banners; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $banner): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr>
                                    <td class="text-center"><?php echo e($key + 1); ?></td>
                                    <td class="text-center"><?php echo e($banner->created_at->format('d M Y')); ?></td>
                                    <td class="text-center">
                                        <?php echo e($banner->expiry_date ? \Carbon\Carbon::parse($banner->expiry_date)->format('d M Y') : '-'); ?>

                                    </td>
                                    <td class="text-center"><?php echo e(ucfirst($banner->location)); ?></td>
                                    <td class="text-center">
                                        <img
                                            src="<?php echo e(asset('storage/' . $banner->image)); ?>"
                                            class="customer-img"
                                            alt="banner"
                                            style="height: 50px; width: auto;"
                                        />
                                    </td>
                                    <td class="text-center">
                                        <?php echo e($banner->link ?? '-'); ?>

                                    </td>
                                    <td class="text-center">
                                        <div class="dropdown">
                                            <button
                                                class="btn btn-sm"
                                                type="button"
                                                data-bs-toggle="dropdown"
                                                aria-expanded="false"
                                            >
                                                <i class="fas fa-ellipsis-v"></i>
                                            </button>
                                            <ul class="dropdown-menu dropdown-menu-end">
                                                <li>
                                                    <a
                                                        class="dropdown-item edit-banner-btn"
                                                        href="#"
                                                        data-bs-toggle="modal"
                                                        data-bs-target="#editBannerModal"
                                                        data-banner-id="<?php echo e($banner->id); ?>"
                                                        data-location="<?php echo e($banner->location); ?>"
                                                        data-expiry-date="<?php echo e($banner->expiry_date); ?>"
                                                        data-link="<?php echo e($banner->link); ?>"
                                                        data-status="<?php echo e($banner->status); ?>"
                                                        data-image="<?php echo e(asset('storage/' . $banner->image)); ?>"
                                                    >
                                                        <i class="fas fa-edit me-2"></i> Edit
                                                    </a>
                                                </li>
                                                <li><hr class="dropdown-divider" /></li>
                                                <li>
                                                    <form action="<?php echo e(route('banners.destroy', $banner->id)); ?>" method="POST">
                                                        <?php echo csrf_field(); ?>
                                                        <?php echo method_field('DELETE'); ?>
                                                        <button type="submit" class="dropdown-item text-danger">
                                                            <i class="fas fa-trash me-2"></i> Delete
                                                        </button>
                                                    </form>
                                                </li>
                                            </ul>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>
                                    <td class="text-center" colspan="7">No banners found.</td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
          </div>
        </div>

        <!-- Add Banner Modal -->
        <div
        class="modal fade"
        id="addBannerModal"
        tabindex="-1"
        aria-labelledby="addBannerModalLabel"
        aria-hidden="true"
        >
        <div class="modal-dialog modal-md">
            <div class="modal-content">
            <div class="modal-header bg-primary text-white">
                <h5 class="modal-title" id="addBannerModalLabel">Add Banner</h5>
                <button
                type="button"
                class="btn-close btn-close-white"
                data-bs-dismiss="modal"
                aria-label="Close"
                ></button>
            </div>

            <div class="modal-body">
                <!-- Laravel Form -->
                <form
                id="addBannerForm"
                action="<?php echo e(route('banners.store')); ?>"
                method="POST"
                enctype="multipart/form-data"
                >
                <?php echo csrf_field(); ?>

                <!-- Banner Location -->
                <div class="mb-3">
                    <label for="bannerLocation" class="form-label">Banner Location</label>
                    <select
                    class="form-select"
                    id="bannerLocation"
                    name="location"
                    required
                    >
                    <option value="" disabled selected>Select location</option>
                    <option value="home">Home</option>
                    <option value="redeem">Redeem</option>
                    </select>
                </div>

                <!-- Banner Expiry -->
                <div class="mb-3">
                    <label for="bannerExpiry" class="form-label">Banner Expiry</label>
                    <input
                    type="date"
                    class="form-control"
                    id="bannerExpiry"
                    name="expiry_date"
                    required
                    />
                </div>

                <!-- Banner Image -->
                <div class="mb-3">
                    <label for="bannerImage" class="form-label">Banner Image</label>
                    <input
                    type="file"
                    class="form-control"
                    id="bannerImage"
                    name="image"
                    accept="image/*"
                    required
                    />
                </div>

                <!-- Banner Link -->
                <div class="mb-3">
                    <label for="bannerLink" class="form-label">Banner Link (Optional)</label>
                    <input
                    type="url"
                    class="form-control"
                    id="bannerLink"
                    name="link"
                    placeholder="https://example.com"
                    />
                </div>

                <!-- Banner Status -->
                <div class="mb-3">
                    <label for="bannerStatus" class="form-label">Status</label>
                    <select
                    class="form-select"
                    id="bannerStatus"
                    name="status"
                    required
                    >
                    <option value="" disabled selected>Select status</option>
                    <option value="active">Active</option>
                    <option value="inactive">Inactive</option>
                    </select>
                </div>

                <div class="modal-footer">
                    <button
                    type="button"
                    class="btn btn-secondary"
                    data-bs-dismiss="modal"
                    >
                    Cancel
                    </button>
                    <button type="submit" class="btn btn-primary">
                    <i class="fas fa-image me-2"></i> Add Banner
                    </button>
                </div>
                </form>
            </div>
            </div>
        </div>
        </div>


      <!-- Edit Banner Modal -->
<div
    class="modal fade"
    id="editBannerModal"
    tabindex="-1"
    aria-labelledby="editBannerModalLabel"
    aria-hidden="true"
>
    <div class="modal-dialog modal-md">
        <div class="modal-content">
            <div class="modal-header bg-warning text-white">
                <h5 class="modal-title" id="editBannerModalLabel">Edit Banner</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>

            <div class="modal-body">
                <form id="editBannerForm" method="POST" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PUT'); ?>

                    <!-- Banner Location -->
                    <div class="mb-3">
                        <label for="editBannerLocation" class="form-label">Banner Location</label>
                        <select class="form-select" id="editBannerLocation" name="location" required>
                            <option value="home">Home</option>
                            <option value="redeem">Redeem</option>
                        </select>
                    </div>

                    <!-- Banner Expiry -->
                    <div class="mb-3">
                        <label for="editBannerExpiry" class="form-label">Banner Expiry</label>
                        <input type="date" class="form-control" id="editBannerExpiry" name="expiry_date" required>
                    </div>

                    <!-- Banner Image -->
                    <div class="mb-3">
                        <label for="editBannerImage" class="form-label">Banner Image</label>
                        <input type="file" class="form-control" id="editBannerImage" name="image" accept="image/*">
                        <small class="text-muted">Leave empty to keep current image</small>
                        <div class="mt-2">
                            <img id="currentBannerImage" src="" alt="banner" style="height: 50px; width:auto;">
                        </div>
                    </div>

                    <!-- Banner Link -->
                    <div class="mb-3">
                        <label for="editBannerLink" class="form-label">Banner Link (Optional)</label>
                        <input type="url" class="form-control" id="editBannerLink" name="link">
                    </div>

                    <!-- Banner Status -->
                    <div class="mb-3">
                        <label for="editBannerStatus" class="form-label">Status</label>
                        <select class="form-select" id="editBannerStatus" name="status" required>
                            <option value="active">Active</option>
                            <option value="inactive">Inactive</option>
                        </select>
                    </div>

                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                        <button type="submit" class="btn btn-warning text-white">
                            <i class="fas fa-edit me-2"></i> Update Banner
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function () {
    const editButtons = document.querySelectorAll('.edit-banner-btn');
    const form = document.getElementById('editBannerForm');

    editButtons.forEach(button => {
        button.addEventListener('click', function () {
            const bannerId = this.dataset.bannerId;
            const location = this.dataset.location;
            const expiryDate = this.dataset.expiryDate;
            const link = this.dataset.link;
            const status = this.dataset.status;
            const image = this.dataset.image;

            // Update form action
            form.action = `/admin/banners/${bannerId}`;

            // Populate fields
            document.getElementById('editBannerLocation').value = location;
            document.getElementById('editBannerExpiry').value = expiryDate;
            document.getElementById('editBannerLink').value = link ?? '';
            document.getElementById('editBannerStatus').value = status;
            document.getElementById('currentBannerImage').src = image;
        });
    });
});
</script>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/FTLOP/Downloads/dailyopenion_subsubcat_website 2/resources/views/admin/banner.blade.php ENDPATH**/ ?>