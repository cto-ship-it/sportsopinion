<?php $__env->startSection('title', 'Users'); ?>

<?php $__env->startSection('content'); ?>

<div class="page-header">
          <h4 class="page-title">User Management</h4>
          <!-- <button class="btn btn-primary">Add New Karigar</button> -->
        </div>

        <!-- Karigar Page -->
        <div id="karigar-page" class="page-content">
          <div class="card">
            <div class="card-body">
              <div class="row g-3 align-items-center">
                <!-- Search Bar -->
                <?php if (isset($component)) { $__componentOriginal465912bafb53d2799b51398725f2e117 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal465912bafb53d2799b51398725f2e117 = $attributes; } ?>
<?php $component = App\View\Components\Search::resolve(['action' => route('admin.users'),'placeholder' => 'Search customers...'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('search'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Search::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal465912bafb53d2799b51398725f2e117)): ?>
<?php $attributes = $__attributesOriginal465912bafb53d2799b51398725f2e117; ?>
<?php unset($__attributesOriginal465912bafb53d2799b51398725f2e117); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal465912bafb53d2799b51398725f2e117)): ?>
<?php $component = $__componentOriginal465912bafb53d2799b51398725f2e117; ?>
<?php unset($__componentOriginal465912bafb53d2799b51398725f2e117); ?>
<?php endif; ?>


                <!-- Export Button / Filter Button -->
                
              </div>
            </div>
          </div>

          <div class="card">
            <div class="card-body">
              <div class="table-responsive" style="overflow-x:auto; white-space:nowrap;">
                <table class="table table-hover align-middle" id="userTable">
                  <thead class="table-light">
                    <tr>
                      <th>Sr.No.</th>
                      <th>ID</th>
                      <th>Date</th>
                      <th>User Photo</th>
                      <th>Name</th>
                      <th>Email</th>
                      <th>Phone Number</th>
                      <th>State</th>
                      <th>District</th>
                      <th>City</th>
                      <th>Address</th>
                      <th>Status</th>
                      <th>Actions</th>
                    </tr>
                  </thead>
                  <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                      <tr>
                        <td><?php echo e($index + 1); ?></td>
                        <td><?php echo e('USR' . str_pad($user->id, 3, '0', STR_PAD_LEFT)); ?></td>
                        <td><?php echo e($user->created_at->format('Y-m-d')); ?></td>
                        <td><img src="<?php echo e($user->profile_pic); ?>" class="rounded-circle" style="width:50px; height:50px; object-fit:cover;"></td>
                        <td><?php echo e($user->name); ?></td>
                        <td><?php echo e($user->email ?? 'N/A'); ?></td>
                        <td><?php echo e($user->phone ?? 'N/A'); ?></td>
                        <td><?php echo e($user->address->state ?? 'N/A'); ?></td>
                        <td><?php echo e($user->address->district ?? 'N/A'); ?></td>
                        <td><?php echo e($user->address->city ?? 'N/A'); ?></td>
                        <td><?php echo e($user->address->address ?? 'N/A'); ?></td>
                        <td>
                          <?php if($user->status == 1): ?>
                            <span class="badge bg-success">Active</span>
                          <?php else: ?>
                            <span class="badge bg-danger">Deactive</span>
                          <?php endif; ?>
                        </td>
                        <td>
                          <div class="dropdown">
                            <button class="btn btn-sm" data-bs-toggle="dropdown">
                              <i class="fas fa-ellipsis-v"></i>
                            </button>
                            <ul class="dropdown-menu dropdown-menu-end">
                              <li>
                                  <a href="<?php echo e(route('admin.users.point-history', encrypt($user->id))); ?>" class="dropdown-item">
                                      <i class="fas fa-history me-2"></i> View Point History
                                  </a>
                              </li>
                              <li>
                                <a href="#" class="dropdown-item toggle-status-btn"
                                  data-user-id="<?php echo e($user->id); ?>"
                                  data-current-status="<?php echo e($user->status == 1 ? 'active' : 'deactive'); ?>">
                                  <i class="fas fa-power-off me-2"></i>
                                  <?php echo e($user->status == 1 ? 'Deactivate' : 'Activate'); ?>

                                </a>
                              </li>
                            </ul>
                          </div>
                        </td>
                      </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                      <tr><td colspan="13" class="text-center">No users found</td></tr>
                    <?php endif; ?>
                  </tbody>
                </table>
              </div>

              <?php if(isset($users) && $users->hasPages()): ?>
                <?php echo $__env->make('admin.layouts.pagination', ['paginator' => $users], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
              <?php endif; ?>
            </div>
          </div>
        </div>

<script>
document.addEventListener('click', function(e) {
    if (e.target.closest('.toggle-status-btn')) {
        e.preventDefault();
        let btn = e.target.closest('.toggle-status-btn');
        let userId = btn.dataset.userId;

        fetch(`/admin/users/${userId}/toggle-status`, {
            method: 'POST',
            headers: {
                'X-CSRF-TOKEN': '<?php echo e(csrf_token()); ?>'
            }
        })
        .then(res => res.json())
        .then(data => {
            if (data.status) location.reload();
            else alert(data.message);
        });
    }
});
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/FTLOP/Downloads/dailyopenion_subsubcat_website 2/resources/views/admin/users.blade.php ENDPATH**/ ?>