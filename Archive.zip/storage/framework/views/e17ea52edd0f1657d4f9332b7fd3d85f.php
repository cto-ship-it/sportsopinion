<?php $__env->startSection('title', 'Manage Admins'); ?>

<?php $__env->startSection('content'); ?>

<div id="roles-page" class="page-content">
  <div class="page-header justify-content-between">
    <h4 class="page-title">Manage Admins</h4>

    <button type="button" class="btn bg-info text-white" data-bs-toggle="modal" data-bs-target="#addAdminModal">
      <i class="fas fa-plus me-2"></i> Add Admin
    </button>
  </div>

  <div class="card mt-3">
    <div class="card-body">
      <div class="table-responsive">
        <table class="table table-hover">
          <thead>
            <tr class="text-center">
              <th>#</th>
              <th>Name</th>
              <th>Email</th>
              <th>Role</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
              <tr class="text-center">
                <td><?php echo e($key + 1); ?></td>
                <td><?php echo e($user->name); ?></td>
                <td><?php echo e($user->email); ?></td>
                <td><span class="badge bg-secondary"><?php echo e(ucfirst($user->role)); ?></span></td>
                <td>
                  <button class="btn btn-sm btn-warning me-1 edit-user-btn" 
                          data-bs-toggle="modal" 
                          data-bs-target="#editAdminModal"
                          data-user-id="<?php echo e($user->id); ?>"
                          data-user-name="<?php echo e($user->name); ?>"
                          data-user-email="<?php echo e($user->email); ?>">
                    <i class="fas fa-edit"></i> Edit
                  </button>

                  <form action="<?php echo e(route('roles.destroy', $user->id)); ?>" method="POST" class="d-inline">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>
                    <button type="submit" class="btn btn-sm btn-danger" 
                            onclick="return confirm('Are you sure you want to delete this admin?')">
                      <i class="fas fa-trash"></i> Delete
                    </button>
                  </form>
                </td>
              </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
              <tr>
                <td colspan="5" class="text-center">No admins found.</td>
              </tr>
            <?php endif; ?>
          </tbody>
        </table>
      </div>
      <?php echo e($users->links()); ?>

    </div>
  </div>
</div>

<!-- Add Admin Modal -->
<div class="modal fade" id="addAdminModal" tabindex="-1" aria-labelledby="addAdminModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-md">
    <div class="modal-content">
      <div class="modal-header bg-primary text-white">
        <h5 class="modal-title">Add Admin</h5>
        <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
      </div>
      <form method="POST" action="<?php echo e(route('roles.store')); ?>">
        <?php echo csrf_field(); ?>
        <div class="modal-body">
          <div class="mb-3">
            <label>Name</label>
            <input type="text" name="name" class="form-control" required>
          </div>
          <div class="mb-3">
            <label>Email</label>
            <input type="email" name="email" class="form-control" required>
          </div>
          <div class="mb-3">
            <label>Password</label>
            <input type="password" name="password" class="form-control" required>
          </div>
          <div class="mb-3">
            <label>Confirm Password</label>
            <input type="password" name="password_confirmation" class="form-control" required>
          </div>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
          <button type="submit" class="btn btn-primary">Add Admin</button>
        </div>
      </form>
    </div>
  </div>
</div>

<!-- Edit Admin Modal -->
<div class="modal fade" id="editAdminModal" tabindex="-1" aria-labelledby="editAdminModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-md">
    <div class="modal-content">
      <div class="modal-header bg-warning text-white">
        <h5 class="modal-title">Edit Admin</h5>
        <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
      </div>
      <form id="editAdminForm" method="POST">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
        <div class="modal-body">
          <div class="mb-3">
            <label>Name</label>
            <input type="text" name="name" id="editAdminName" class="form-control" required>
          </div>
          <div class="mb-3">
            <label>Email</label>
            <input type="email" name="email" id="editAdminEmail" class="form-control" required>
          </div>
          <div class="mb-3">
            <label>New Password (optional)</label>
            <input type="password" name="password" class="form-control">
          </div>
          <div class="mb-3">
            <label>Confirm Password</label>
            <input type="password" name="password_confirmation" class="form-control">
          </div>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
          <button type="submit" class="btn btn-warning text-white">Update Admin</button>
        </div>
      </form>
    </div>
  </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function () {
  const editButtons = document.querySelectorAll('.edit-user-btn');
  const editForm = document.getElementById('editAdminForm');

  editButtons.forEach(button => {
    button.addEventListener('click', function () {
      const id = this.dataset.userId;
      const name = this.dataset.userName;
      const email = this.dataset.userEmail;

      editForm.action = `/admin/roles/${id}`;
      editForm.querySelector('#editAdminName').value = name;
      editForm.querySelector('#editAdminEmail').value = email;
    });
  });
});
</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/FTLOP/Downloads/dailyopenion_subsubcat_website 2/resources/views/admin/role.blade.php ENDPATH**/ ?>