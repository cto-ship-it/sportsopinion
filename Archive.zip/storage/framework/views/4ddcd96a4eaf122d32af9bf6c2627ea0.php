<div class="col-md-8">
    <form method="GET" action="<?php echo e($action ?? url()->current()); ?>" class="input-group me-3" style="width: 250px">
        <input
            type="text"
            name="search"
            value="<?php echo e(request('search')); ?>"
            class="form-control form-control-sm"
            placeholder="<?php echo e($placeholder ?? 'Search...'); ?>"
        />
        <button class="btn btn-sm btn-outline-secondary" type="submit">
            <i class="fas fa-search"></i>
        </button>
    </form>
</div>
<?php /**PATH /Users/FTLOP/Downloads/dailyopenion_subsubcat_website 2/resources/views/components/search.blade.php ENDPATH**/ ?>