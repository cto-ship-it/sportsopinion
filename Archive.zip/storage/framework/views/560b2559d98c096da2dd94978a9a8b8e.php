<?php $__env->startSection('title', 'Subcategories'); ?>

<?php $__env->startSection('content'); ?>

 <!-- Subcategories Page -->
        <div id="subcategories-page" class="page-content">
          <div class="page-header justify-content-between">
            <!-- Breadcrumb Navigation -->
            <nav aria-label="breadcrumb">
              <ol class="breadcrumb">
                <li class="breadcrumb-item">
                  <a href="">Categories</a>
                </li>
                <li class="breadcrumb-item active" aria-current="page">
                  <?php echo e($category->name ?? 'Subcategories'); ?>

                </li>
              </ol>
            </nav>

            <h4 class="page-title">Subcategory Management</h4>

            <button
              type="button"
              class="btn bg-info text-white"
              data-bs-toggle="modal"
              data-bs-target="#addSubcategoryModal"
            >
              <i class="fas fa-plus me-2"></i> Add Subcategory
            </button>
          </div>

          <div class="card">
            <div class="card-body">
              <div class="row g-3 align-items-center">
                <!-- Search Bar -->
                <?php if (isset($component)) { $__componentOriginal465912bafb53d2799b51398725f2e117 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal465912bafb53d2799b51398725f2e117 = $attributes; } ?>
<?php $component = App\View\Components\Search::resolve(['action' => route('subcategories.index'),'placeholder' => 'Search subcategories...'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('search'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Search::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal465912bafb53d2799b51398725f2e117)): ?>
<?php $attributes = $__attributesOriginal465912bafb53d2799b51398725f2e117; ?>
<?php unset($__attributesOriginal465912bafb53d2799b51398725f2e117); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal465912bafb53d2799b51398725f2e117)): ?>
<?php $component = $__componentOriginal465912bafb53d2799b51398725f2e117; ?>
<?php unset($__componentOriginal465912bafb53d2799b51398725f2e117); ?>
<?php endif; ?>

                <!-- Export Button / Filter Button -->
                <div class="col-md-4">
                  <div class="d-flex justify-content-end gap-2">
                    <button class="btn btn-outline-secondary" id="resetFilters">
                      <i class="fas fa-sync-alt"></i>
                    </button>
                  </div>
                </div>
              </div>
            </div>
          </div>

          <div class="card">
            <div class="card-body">
            <div class="table-responsive">
                <table class="table table-hover" id="subcategoriesTable">
                <thead>
                    <tr>
                    <th class="text-center">Sr.No.</th>
                    <th class="text-center">Date</th>
                    <th class="text-center">Name</th>
                    <th class="text-center">Description</th>
                    <th class="text-center">Status</th>
                    <th class="text-center">Edit / Delete</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $subcategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $subcategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td class="text-center"><?php echo e($key + 1); ?></td>
                        <td class="text-center"><?php echo e($subcategory->created_at->format('d M Y')); ?></td>
                        <td class="text-center"><?php echo e($subcategory->name); ?></td>
                        <td class="text-center"><?php echo e($subcategory->description); ?></td>
                        <td class="text-center">
                          <span class="badge bg-<?php echo e($subcategory->status ? 'success' : 'secondary'); ?>">
                            <?php echo e($subcategory->status ? 'Active' : 'Inactive'); ?>

                          </span>
                        </td>

                        <td class="text-center">
                        <!-- Edit Button -->
                        <button
                            type="button"
                            class="btn btn-sm btn-warning me-1 edit-subcategory-btn"
                            data-bs-toggle="modal"
                            data-bs-target="#editSubcategoryModal"
                            data-subcategory-id="<?php echo e($subcategory->id); ?>"
                            data-subcategory-name="<?php echo e($subcategory->name); ?>"
                            data-subcategory-description="<?php echo e($subcategory->description); ?>"
                            data-subcategory-status="<?php echo e($subcategory->status); ?>"
                            data-subcategory-category="<?php echo e($subcategory->category_id); ?>"
                        >
                            <i class="fas fa-edit me-1"></i> Edit
                        </button>

                        <!-- Delete Button -->
                        <form action="<?php echo e(route('subcategories.destroy', $subcategory->id)); ?>" method="POST" class="d-inline">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button type="submit" class="btn btn-sm btn-danger" onclick="return confirm('Are you sure you want to delete this subcategory?')">
                            <i class="fas fa-trash me-1"></i> Delete
                            </button>
                        </form>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="6" class="text-center">No subcategories found.</td>
                    </tr>
                    <?php endif; ?>
                </tbody>
                </table>
            </div>
             <!-- PAGINATION -->
              <?php if(isset($subcategories) && $subcategories->hasPages()): ?>
                  <?php echo $__env->make('admin.layouts.pagination', ['paginator' => $subcategories], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
              <?php endif; ?>
            </div>
          </div>
        </div>

       <!-- Add Subcategory Modal -->
        <div class="modal fade" id="addSubcategoryModal" tabindex="-1" aria-labelledby="addSubcategoryModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-md">
            <div class="modal-content">
            <div class="modal-header bg-primary text-white">
                <h5 class="modal-title" id="addSubcategoryModalLabel">Add Subcategory</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>

            <div class="modal-body">
                <form id="addSubcategoryForm" method="POST" action="<?php echo e(route('subcategories.store')); ?>">
                <?php echo csrf_field(); ?>

                <!-- Category (if needed) -->
                <div class="mb-3">
                    <label for="categorySelect" class="form-label">Category</label>
                    <select name="category_id" class="form-select" id="categorySelect" required>
                      <option value="">Select Category</option>
                      <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($category->id); ?>" <?php echo e(old('category_id') == $category->id ? 'selected' : ''); ?>>
                          <?php echo e($category->name); ?>

                        </option>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <?php $__errorArgs = ['category_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="text-danger"><?php echo e($message); ?></span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <!-- Name -->
                <div class="mb-3">
                    <label for="subcategoryName" class="form-label">Name</label>
                    <input
                    type="text"
                    name="name"
                    class="form-control"
                    id="subcategoryName"
                    placeholder="Enter subcategory name"
                    value="<?php echo e(old('name')); ?>"
                    required
                    />
                    <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="text-danger"><?php echo e($message); ?></span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <!-- Description -->
                <div class="mb-3">
                    <label for="subcategoryDescription" class="form-label">Description</label>
                    <textarea
                    name="description"
                    class="form-control"
                    id="subcategoryDescription"
                    rows="3"
                    placeholder="Enter subcategory description"
                    ><?php echo e(old('description')); ?></textarea>
                    <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="text-danger"><?php echo e($message); ?></span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <!-- Status -->
                <div class="mb-3">
                  <label class="form-label">Status</label>
                  <div>
                    <div class="form-check form-check-inline">
                      <input class="form-check-input" type="radio" name="status" id="statusActive" value="1" checked>
                      <label class="form-check-label" for="statusActive">Active</label>
                    </div>
                    <div class="form-check form-check-inline">
                      <input class="form-check-input" type="radio" name="status" id="statusInactive" value="0">
                      <label class="form-check-label" for="statusInactive">Inactive</label>
                    </div>
                  </div>
                  <?php $__errorArgs = ['status'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                  <span class="text-danger"><?php echo e($message); ?></span>
                  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                </form>
            </div>

            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">
                Cancel
                </button>
                <button type="submit" class="btn btn-primary" form="addSubcategoryForm">
                <i class="fas fa-plus me-2"></i> Add Subcategory
                </button>
            </div>
            </div>
        </div>
        </div>

     <!-- Edit Subcategory Modal -->
<div class="modal fade" id="editSubcategoryModal" tabindex="-1" aria-labelledby="editSubcategoryModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-md">
    <div class="modal-content">
      <div class="modal-header bg-warning text-white">
        <h5 class="modal-title" id="editSubcategoryModalLabel">Edit Subcategory</h5>
        <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>

      <div class="modal-body">
        <form id="editSubcategoryForm" method="POST" action="">
          <?php echo csrf_field(); ?>
          <?php echo method_field('PUT'); ?>

          <!-- Category -->
          <div class="mb-3">
            <label for="editCategorySelect" class="form-label">Category</label>
            <select name="category_id" class="form-select" id="editCategorySelect" required>
              <option value="">Select Category</option>
              <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($category->id); ?>"><?php echo e($category->name); ?></option>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
          </div>

          <!-- Name -->
          <div class="mb-3">
            <label for="editSubcategoryName" class="form-label">Name</label>
            <input
              type="text"
              name="name"
              class="form-control"
              id="editSubcategoryName"
              required
            />
          </div>

          <!-- Description -->
          <div class="mb-3">
            <label for="editSubcategoryDescription" class="form-label">Description</label>
            <textarea
              name="description"
              class="form-control"
              id="editSubcategoryDescription"
              rows="3"
            ></textarea>
          </div>

          <!-- Status -->
          <div class="mb-3">
            <label class="form-label">Status</label>
            <div>
              <div class="form-check form-check-inline">
                <input class="form-check-input" type="radio" name="status" id="editStatusActive" value="1">
                <label class="form-check-label" for="editStatusActive">Active</label>
              </div>
              <div class="form-check form-check-inline">
                <input class="form-check-input" type="radio" name="status" id="editStatusInactive" value="0">
                <label class="form-check-label" for="editStatusInactive">Inactive</label>
              </div>
            </div>
          </div>
        </form>
      </div>

      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
        <button type="submit" class="btn btn-warning text-white" form="editSubcategoryForm">
          <i class="fas fa-edit me-2"></i> Update Subcategory
        </button>
      </div>
    </div>
  </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function () {
    const editButtons = document.querySelectorAll('.edit-subcategory-btn');
    const editModal = document.getElementById('editSubcategoryModal');

    editButtons.forEach(button => {
        button.addEventListener('click', function () {
            const subcategoryId = this.getAttribute('data-subcategory-id');
            const subcategoryName = this.getAttribute('data-subcategory-name');
            const subcategoryDescription = this.getAttribute('data-subcategory-description');
            const subcategoryStatus = this.getAttribute('data-subcategory-status');
            const subcategoryCategory = this.getAttribute('data-subcategory-category');

            // Set values in the modal form
            editModal.querySelector('form').action = `/admin/subcategories/${subcategoryId}`;
            editModal.querySelector('#editSubcategoryName').value = subcategoryName;
            editModal.querySelector('#editSubcategoryDescription').value = subcategoryDescription;
            editModal.querySelector('#editCategorySelect').value = subcategoryCategory;
            
            // Set status radio button
            if (subcategoryStatus === '1') {
                document.getElementById('editStatusActive').checked = true;
            } else {
                document.getElementById('editStatusInactive').checked = true;
            }
        });
    });
});
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/FTLOP/Downloads/dailyopenion_subsubcat_website 2/resources/views/admin/subcategory.blade.php ENDPATH**/ ?>