<?php $__env->startSection('title', 'Dashboard'); ?>

<?php $__env->startSection('content'); ?>
    <!-- Dashboard Page -->
        <div id="dashboard-page" class="page-content">
          <!-- Stats Cards -->
          <div class="row mb-4">
            <div class="col-md-6 col-lg-3 mb-3">
              <div class="card card-primary h-100">
                <div class="card-body">
                  <div class="stat-card d-flex align-items-center">
                    <div class="icon primary me-3">
                      <i class="fas fa-dollar-sign"></i>
                    </div>
                    <div>
                      <h6 class="mb-1">Total Revenue</h6>
                      <h4 class="mb-0">$24,580</h4>
                      <small class="text-success"
                        ><i class="fas fa-arrow-up"></i> 12.5% from last
                        month</small
                      >
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div class="col-md-6 col-lg-3 mb-3">
              <div class="card card-primary h-100">
                <div class="card-body">
                  <div class="stat-card d-flex align-items-center">
                    <div class="icon primary me-3">
                      <i class="fas fa-shopping-cart"></i>
                    </div>
                    <div>
                      <h6 class="mb-1">Total Orders</h6>
                      <h4 class="mb-0">1,248</h4>
                      <small class="text-success"
                        ><i class="fas fa-arrow-up"></i> 8.3% from last
                        month</small
                      >
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div class="col-md-6 col-lg-3 mb-3">
              <div class="card card-secondary h-100">
                <div class="card-body">
                  <div class="stat-card d-flex align-items-center">
                    <div class="icon secondary me-3">
                      <i class="fas fa-users"></i>
                    </div>
                    <div>
                      <h6 class="mb-1">New Customers</h6>
                      <h4 class="mb-0">184</h4>
                      <small class="text-success"
                        ><i class="fas fa-arrow-up"></i> 5.2% from last
                        month</small
                      >
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div class="col-md-6 col-lg-3 mb-3">
              <div class="card card-secondary h-100">
                <div class="card-body">
                  <div class="stat-card d-flex align-items-center">
                    <div class="icon secondary me-3">
                      <i class="fas fa-star"></i>
                    </div>
                    <div>
                      <h6 class="mb-1">Avg. Rating</h6>
                      <h4 class="mb-0">4.7</h4>
                      <small class="text-success"
                        ><i class="fas fa-arrow-up"></i> 0.3 from last
                        month</small
                      >
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>

          
        </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/FTLOP/Downloads/dailyopenion_subsubcat_website 2/resources/views/admin/dashboard.blade.php ENDPATH**/ ?>