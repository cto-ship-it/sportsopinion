<?php $__env->startSection('title', 'Permissions Management'); ?>

<?php $__env->startSection('content'); ?>

<div class="page-content">
  <div class="page-header justify-content-between">
    <h4 class="page-title">Manage Admin Permissions</h4>
  </div>

  <div class="card mt-3">
    <div class="card-body">
      <div class="table-responsive">
        <table class="table table-hover align-middle">
          <thead>
            <tr class="text-center">
              <th>#</th>
              <th>Name</th>
              <th>Email</th>
              <th>Current Permissions</th>
              <th>Action</th>
            </tr>
          </thead>
          <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $admins; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $admin): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
              <tr class="text-center">
                <td><?php echo e($index + 1); ?></td>
                <td><?php echo e($admin->name); ?></td>
                <td><?php echo e($admin->email); ?></td>
                <td>
                  <?php if(!empty($admin->permissions)): ?>
                    <?php $__currentLoopData = $admin->permissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <span class="badge bg-success"><?php echo e(config('permissions')[$key] ?? $key); ?></span>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  <?php else: ?>
                    <span class="text-muted">No Permissions</span>
                  <?php endif; ?>
                </td>
                <td>
                  <button class="btn btn-sm btn-warning edit-permissions-btn" 
                          data-bs-toggle="modal"
                          data-bs-target="#editPermissionsModal"
                          data-id="<?php echo e($admin->id); ?>"
                          data-name="<?php echo e($admin->name); ?>">
                    <i class="fas fa-edit"></i> Edit
                  </button>
                </td>
              </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
              <tr><td colspan="5" class="text-center">No admins found.</td></tr>
            <?php endif; ?>
          </tbody>
        </table>
      </div>
      <?php echo e($admins->links()); ?>

    </div>
  </div>
</div>

<!-- Edit Permissions Modal -->
<div class="modal fade" id="editPermissionsModal" tabindex="-1" aria-labelledby="editPermissionsModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-lg">
    <div class="modal-content">
      <div class="modal-header bg-warning text-white">
        <h5 class="modal-title" id="editPermissionsModalLabel">Edit Permissions</h5>
        <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
      </div>
      <form id="permissionsForm" method="POST">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
        <div class="modal-body">
          <div class="mb-3">
            <label class="form-label">Admin Name</label>
            <input type="text" id="adminName" class="form-control" readonly>
          </div>

          <div class="row">
            <?php $__currentLoopData = $allPermissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <div class="col-md-4 mb-2">
                <div class="form-check">
                  <input type="checkbox" name="permissions[<?php echo e($key); ?>]" value="1" id="perm_<?php echo e($key); ?>" class="form-check-input">
                  <label for="perm_<?php echo e($key); ?>" class="form-check-label"><?php echo e($label); ?></label>
                </div>
              </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </div>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
          <button type="submit" class="btn btn-warning text-white">Save Changes</button>
        </div>
      </form>
    </div>
  </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', () => {
  const buttons = document.querySelectorAll('.edit-permissions-btn');
  const form = document.getElementById('permissionsForm');
  const adminName = document.getElementById('adminName');

  buttons.forEach(btn => {
    btn.addEventListener('click', async () => {
      const id = btn.dataset.id;
      const name = btn.dataset.name;
      adminName.value = name;

      const response = await fetch(`/admin/permissions/${id}/edit`);
      const data = await response.json();

      form.action = `/admin/permissions/${id}`;
      document.querySelectorAll('[name^="permissions"]').forEach(cb => cb.checked = false);

      if (data.permissions) {
        Object.keys(data.permissions).forEach(key => {
          const checkbox = document.getElementById(`perm_${key}`);
          if (checkbox) checkbox.checked = true;
        });
      }
    });
  });
});
</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/FTLOP/Downloads/dailyopenion_subsubcat_website 2/resources/views/admin/permission.blade.php ENDPATH**/ ?>