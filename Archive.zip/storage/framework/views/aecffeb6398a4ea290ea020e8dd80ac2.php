<!-- Navbar -->
        <nav class="navbar navbar-expand-lg rounded-3 mb-4">
          <div class="container-fluid">
            <div class="d-flex align-items-center">
              <button class="btn btn-sm me-3 d-lg-none">
                <i class="fas fa-bars"></i>
              </button>
              <h5 class="m-0" id="pageTitle">Dashboard Overview</h5>
            </div>
            
          </div>
        </nav><?php /**PATH /Users/FTLOP/Downloads/dailyopenion_subsubcat_website 2/resources/views/admin/layouts/header.blade.php ENDPATH**/ ?>