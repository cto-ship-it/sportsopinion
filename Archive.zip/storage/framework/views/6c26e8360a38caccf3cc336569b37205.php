<div class="modal fade" id="changePasswordModal" tabindex="-1" aria-labelledby="changePasswordModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-md">
    <div class="modal-content">
      <div class="modal-header gradient-bg text-white">
        <h5 class="modal-title text-black" id="changePasswordModalLabel">Change Password</h5>
        <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        <form id="changePasswordForm" action="<?php echo e(route('user.password.update')); ?>" method="POST">
          <?php echo csrf_field(); ?>

          <!-- Old Password -->
          <div class="mb-3 position-relative">
            <label for="oldPassword" class="form-label">Old Password</label>
            <input type="password" class="form-control" id="oldPassword" name="old_password" placeholder="Enter your current password" required>
            <span class="position-absolute top-50 end-0 translate-middle-y me-3" style="cursor:pointer;" onclick="togglePassword('oldPassword', this)">
              <i class="fas fa-eye"></i>
            </span>
          </div>

          <!-- New Password -->
          <div class="mb-3 position-relative">
            <label for="newPassword" class="form-label">New Password</label>
            <input type="password" class="form-control" id="newPassword" name="new_password" placeholder="Enter new password" required>
            <span class="position-absolute top-50 end-0 translate-middle-y me-3" style="cursor:pointer;" onclick="togglePassword('newPassword', this)">
              <i class="fas fa-eye"></i>
            </span>
          </div>

          <!-- Confirm New Password -->
          <div class="mb-3 position-relative">
            <label for="confirmPassword" class="form-label">Confirm New Password</label>
            <input type="password" class="form-control" id="confirmPassword" name="new_password_confirmation" placeholder="Re-enter new password" required>
            <span class="position-absolute top-50 end-0 translate-middle-y me-3" style="cursor:pointer;" onclick="togglePassword('confirmPassword', this)">
              <i class="fas fa-eye"></i>
            </span>
          </div>

        </form>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
        <button type="submit" class="btn btn-primary" form="changePasswordForm">
          <i class="fas fa-key me-2"></i> Update Password
        </button>
      </div>
    </div>
  </div>
</div>

<script>
function togglePassword(fieldId, iconEl) {
  const input = document.getElementById(fieldId);
  const icon = iconEl.querySelector('i');
  if(input.type === 'password') {
    input.type = 'text';
    icon.classList.remove('fa-eye');
    icon.classList.add('fa-eye-slash');
  } else {
    input.type = 'password';
    icon.classList.remove('fa-eye-slash');
    icon.classList.add('fa-eye');
  }
}
</script>
<?php /**PATH /Users/FTLOP/Downloads/dailyopenion_subsubcat_website 2/resources/views/admin/layouts/change_password.blade.php ENDPATH**/ ?>