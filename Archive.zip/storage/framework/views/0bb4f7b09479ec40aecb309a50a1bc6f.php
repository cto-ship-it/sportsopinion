<?php $__env->startSection('title', 'Dashboard'); ?>

<?php $__env->startSection('content'); ?>

<!-- Customers Page -->
        <div id="customers-page" class="page-content">
          <div class="page-header justify-content-between">
            <h4 class="page-title">Question Management</h4>

            <button
              type="button"
              class="btn bg-info text-white"
              data-bs-toggle="modal"
              data-bs-target="#addQuestionModal"
            >
              <i class="fas fa-star me-2"></i> Add Questions
            </button>
          </div>

          <div class="card">
            <div class="card-body">
              <div class="row g-3 align-items-center">
                <!-- Search Bar -->
                <div class="col-md-8">
                  <div class="input-group me-3" style="width: 250px">
                    <input
                      type="text"
                      class="form-control form-control-sm"
                      placeholder="Search..."
                    />
                    <button
                      class="btn btn-sm btn-outline-secondary"
                      type="button"
                    >
                      <i class="fas fa-search"></i>
                    </button>
                  </div>
                </div>

                <!-- Export Button / Filter Button -->
                
              </div>
            </div>
          </div>

          <div class="card">
            <div class="card-body">
              <div class="table-responsive">
                <table class="table table-hover" id="questionsTable">
                  <thead>
                      <tr>
                          <th class="text-center">Sr.No.</th>
                          <th class="text-center">Created Date</th>
                          <th class="text-center">Publish Date & Time</th>
                          <th class="text-center">Expiry Date & Time</th>
                          <th class="text-center">Banner</th>
                          <th class="text-center">Links</th>
                          <th class="text-center">Question</th>
                          <th class="text-center">Options</th> 
                          <th class="text-center">Points</th>
                          <th class="text-center">Attempt Points</th>
                          <th class="text-center">Answer</th>
                          <th class="text-center">Edit / Delete</th>
                          <th class="text-center">Actions</th>
                      </tr>
                  </thead>

                  <tbody>
                      <?php $__empty_1 = true; $__currentLoopData = $questions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $question): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                          <tr>
                              <td class="text-center"><?php echo e($index + 1); ?></td>
                              <td class="text-center"><?php echo e($question->created_at->format('d M Y')); ?></td>
                              <td class="text-center"><?php echo e($question->publish_at ? $question->publish_at->format('d M Y H:i') : 'Immediate'); ?></td>
                              <td class="text-center"><?php echo e($question->expiry_date ?? 'N/A'); ?></td>

                              <td class="text-center">
                                  <?php if($question->banner_image): ?>
                                      <img src="<?php echo e(asset('storage/' . $question->banner_image)); ?>" class="customer-img" alt="banner" width="60">
                                  <?php else: ?>
                                      <span class="text-muted">No Image</span>
                                  <?php endif; ?>
                              </td>

                              <td class="text-center"><?php echo e($question->banner_link ?? '—'); ?></td>
                              <td class="text-center"><?php echo e($question->question); ?></td>

                              
                              <td class="text-center">
                                  <?php if(!empty($question->options)): ?>
                                      <?php
                                          $options = is_array($question->options) ? $question->options : json_decode($question->options, true);
                                      ?>
                                      <div class="text-start" style="display: inline-block;">
                                          <div><strong>A:</strong> <?php echo e($options[0] ?? '—'); ?></div>
                                          <div><strong>B:</strong> <?php echo e($options[1] ?? '—'); ?></div>
                                      </div>
                                  <?php else: ?>
                                      <span class="text-muted">No Options</span>
                                  <?php endif; ?>
                              </td>

                              <td class="text-center"><?php echo e($question->points); ?></td>
                              <td class="text-center"><?php echo e($question->attempt_point); ?></td>

                              
                              <td class="text-center">
                                  <?php if($question->answer_status === 'pending'): ?>
                                      <span class="badge bg-warning text-dark">Pending</span>
                                  <?php elseif($question->answer_status === 'declared'): ?>
                                      <span class="badge bg-success">Declared (<?php echo e($question->answer ?? '—'); ?>)</span>
                                  <?php else: ?>
                                      <span class="badge bg-secondary">Unknown</span>
                                  <?php endif; ?>
                              </td>

                              
                              <td class="text-center">
                                  <button type="button"
                                      class="btn btn-sm btn-warning me-1 edit-question-btn"
                                      data-bs-toggle="modal"
                                      data-bs-target="#editQuestionModal"
                                      data-id="<?php echo e($question->id); ?>"
                                      data-category-id="<?php echo e($question->category_id); ?>"
                                      data-subcategory-id="<?php echo e($question->subcategory_id); ?>"
                                      data-sub-sub-category-id="<?php echo e($question->sub_sub_category_id); ?>"
                                      data-question="<?php echo e($question->question); ?>"
                                      data-points="<?php echo e($question->points); ?>"
                                      data-attempt-point="<?php echo e($question->attempt_point); ?>"
                                      data-banner-link="<?php echo e($question->banner_link); ?>"
                                      data-banner-image="<?php echo e($question->banner_image ? asset('storage/' . $question->banner_image) : ''); ?>"
                                      data-expiry-datetime="<?php echo e($question->expiry_date); ?>"
                                      data-publish-datetime="<?php echo e($question->publish_at); ?>"
                                      data-options='<?php echo json_encode($question->options, 15, 512) ?>'>
                                      <i class="fas fa-edit me-1"></i> Edit
                                  </button>


                                  <form action="<?php echo e(route('questions.destroy', $question->id)); ?>" method="POST" class="d-inline">
                                      <?php echo csrf_field(); ?>
                                      <?php echo method_field('DELETE'); ?>
                                      <button type="submit" class="btn btn-sm btn-danger" onclick="return confirm('Delete this question?')">
                                          <i class="fas fa-trash me-1"></i> Delete
                                      </button>
                                  </form>
                              </td>

                              
                              <td class="text-center">
                                  <div class="dropdown">
                                      <button class="btn btn-sm" type="button" data-bs-toggle="dropdown" aria-expanded="false">
                                          <i class="fas fa-ellipsis-v"></i>
                                      </button>
                                     <ul class="dropdown-menu dropdown-menu-end">
                                          <?php
                                              // Ensure $question->options is always an array
                                              $options = is_array($question->options)
                                                  ? $question->options
                                                  : json_decode($question->options, true);
                                          ?>

                                          <?php if(!empty($options)): ?>
                                              <li>
                                                  <a class="dropdown-item text-success d-flex align-items-center"
                                                    href="<?php echo e(route('questions.updateStatus', ['id' => $question->id, 'status' => 'A'])); ?>">
                                                      <i class="fas fa-check me-2"></i>
                                                      Mark A as Correct — <span class="fw-semibold"><?php echo e($options[0] ?? 'N/A'); ?></span>
                                                  </a>
                                              </li>

                                              <li>
                                                  <a class="dropdown-item text-danger d-flex align-items-center"
                                                    href="<?php echo e(route('questions.updateStatus', ['id' => $question->id, 'status' => 'B'])); ?>">
                                                      <i class="fas fa-times me-2"></i>
                                                      Mark B as Correct — <span class="fw-semibold"><?php echo e($options[1] ?? 'N/A'); ?></span>
                                                  </a>
                                              </li>
                                          <?php else: ?>
                                              <li>
                                                  <span class="dropdown-item text-muted">No options available</span>
                                              </li>
                                          <?php endif; ?>
                                      </ul>
                                  </div>
                              </td>
                          </tr>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                          <tr>
                              <td colspan="12" class="text-center text-muted">No questions found.</td>
                          </tr>
                      <?php endif; ?>
                  </tbody>
              </table>

              </div>
              <!-- Pagination -->
              <?php if($questions->hasPages()): ?>
                  <?php echo $__env->make('admin.layouts.pagination', ['paginator' => $questions], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
              <?php endif; ?>
            </div>
          </div>
        </div>

        <!-- Filter Questions Modal -->
      <div
        class="modal fade"
        id="questionFilterModal"
        tabindex="-1"
        aria-labelledby="questionFilterModalLabel"
        aria-hidden="true"
      >
        <div class="modal-dialog modal-md">
          <div class="modal-content">
            <div class="modal-header">
              <h5 class="modal-title" id="questionFilterModalLabel">
                Filter Questions
              </h5>
              <button
                type="button"
                class="btn-close"
                data-bs-dismiss="modal"
                aria-label="Close"
              ></button>
            </div>

            <div class="modal-body">
              <form id="questionFilterForm">
                <!-- Question Date -->
                <div class="mb-4">
                  <label for="questionDate" class="form-label"
                    >Question Date</label
                  >
                  <input type="date" class="form-control" id="questionDate" />
                </div>

                <!-- Category Filter -->
                <div class="mb-4">
                  <label for="questionCategoryFilter" class="form-label"
                    >Category</label
                  >
                  <select class="form-select" id="questionCategoryFilter">
                    <option value="" selected>All Categories</option>
                    <option value="CRIC">CRIC</option>
                    <option value="POL">POL</option>
                    <option value="Business">Business</option>
                    <option value="Entertainment">Entertainment</option>
                  </select>
                </div>

                <!-- Status Filter -->
                <div class="mb-4">
                  <label class="form-label d-block">Status</label>
                  <div class="btn-group w-100" role="group">
                    <input
                      type="radio"
                      class="btn-check"
                      name="questionStatus"
                      id="statusAll"
                      autocomplete="off"
                      checked
                    />
                    <label class="btn btn-outline-secondary" for="statusAll"
                      >All</label
                    >

                    <input
                      type="radio"
                      class="btn-check"
                      name="questionStatus"
                      id="statusYes"
                      autocomplete="off"
                      value="yes"
                    />
                    <label class="btn btn-outline-success" for="statusYes"
                      >Yes</label
                    >

                    <input
                      type="radio"
                      class="btn-check"
                      name="questionStatus"
                      id="statusNo"
                      autocomplete="off"
                      value="no"
                    />
                    <label class="btn btn-outline-danger" for="statusNo"
                      >No</label
                    >

                    <input
                      type="radio"
                      class="btn-check"
                      name="questionStatus"
                      id="statusPending"
                      autocomplete="off"
                      value="pending"
                    />
                    <label class="btn btn-outline-warning" for="statusPending"
                      >Pending</label
                    >
                  </div>
                </div>
              </form>
            </div>

            <div class="modal-footer">
              <button
                type="button"
                class="btn btn-outline-secondary"
                id="resetQuestionFiltersBtn"
              >
                <i class="fas fa-undo me-1"></i> Reset
              </button>
              <button
                type="button"
                class="btn btn-primary"
                id="applyQuestionFiltersBtn"
              >
                <i class="fas fa-check me-1"></i> Apply Filters
              </button>
            </div>
          </div>
        </div>
      </div>

<!-- Add Question Modal -->
<div class="modal fade" id="addQuestionModal" tabindex="-1" aria-labelledby="addQuestionModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-md">
        <div class="modal-content">
            <div class="modal-header bg-primary text-white">
                <h5 class="modal-title" id="addQuestionModalLabel">Add Question</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>

            <div class="modal-body">
                <!-- FORM -->
                <form id="addQuestionForm" action="<?php echo e(route('questions.store')); ?>" method="POST" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>

                    <!-- Category Type -->
                    <div class="mb-3">
                        <label for="questionCategory" class="form-label">Category Type</label>
                        <select class="form-select" id="questionCategory" name="category_id" required>
                            <option value="" disabled selected>Select category</option>
                            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($category->id); ?>"><?php echo e($category->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>

                    <!-- Subcategory -->
                    <div class="mb-3">
                        <label for="questionSubcategory" class="form-label">Subcategory</label>
                        <select class="form-select" id="questionSubcategory" name="subcategory_id">
                            <option value="" selected>Select subcategory</option>
                        </select>
                        <div class="form-text">Select a category first to see available subcategories</div>
                    </div>

                    <!-- SubSubCategory -->
                    <div class="mb-3">
                        <label for="questionSubSubCategory" class="form-label">SubSubCategory</label>
                        <select class="form-select" id="questionSubSubCategory" name="sub_sub_category_id">
                            <option value="" selected>Select sub-subcategory</option>
                        </select>
                        <div class="form-text">Select a subcategory first to see available sub-subcategories</div>
                    </div>

                    <!-- Banner Image -->
                    <div class="mb-3">
                        <label for="questionBanner" class="form-label">Banner Image (Optional)</label>
                        <input type="file" class="form-control" id="questionBanner" name="banner_image" accept="image/*" />
                    </div>

                    <!-- Banner Link -->
                    <div class="mb-3">
                        <label for="bannerLink" class="form-label">Banner Link (Optional)</label>
                        <input type="url" class="form-control" id="bannerLink" name="banner_link" placeholder="https://example.com" />
                    </div>

                    <!-- Question -->
                    <div class="mb-3">
                        <label for="questionText" class="form-label">Question</label>
                        <textarea class="form-control" id="questionText" name="question" rows="3" placeholder="Enter the question here" required></textarea>
                    </div>

                    <!-- Options (Only 2) -->
                    <div class="mb-3">
                        <label class="form-label fw-semibold text-dark">Options</label>

                        <div class="input-group mb-2">
                            <span class="input-group-text">A</span>
                            <input type="text" class="form-control" name="options[]" placeholder="Enter option A" required>
                        </div>

                        <div class="input-group mb-2">
                            <span class="input-group-text">B</span>
                            <input type="text" class="form-control" name="options[]" placeholder="Enter option B" required>
                        </div>
                        <div class="form-text text-muted">Only two options are allowed (A and B).</div>
                    </div>


                    <!-- Publish Date & Time -->
                    <div class="mb-4">
                        <label for="publishDateTime" class="form-label fw-semibold text-dark mb-2">
                            <i class="far fa-clock me-2 text-success"></i>Publish Date & Time (Optional)
                        </label>
                        <div class="input-group border rounded-3 overflow-hidden">
                            <span class="input-group-text bg-light border-0">
                                <i class="far fa-calendar-alt text-muted"></i>
                            </span>
                            <input 
                                type="datetime-local" 
                                class="form-control border-0 shadow-none" 
                                id="publishDateTime" 
                                name="publish_at" 
                            >
                        </div>
                        <div class="form-text text-muted mt-2">
                            <i class="fas fa-info-circle me-1"></i>Leave empty to publish immediately
                        </div>
                    </div>

                    <!-- Expiry Date & Time -->
                    <div class="mb-4">
                        <label for="expiryDateTime" class="form-label fw-semibold text-dark mb-2">
                            <i class="far fa-clock me-2 text-primary"></i>Expiry Date & Time
                        </label>
                        <div class="input-group border rounded-3 overflow-hidden">
                            <span class="input-group-text bg-light border-0">
                                <i class="far fa-calendar-alt text-muted"></i>
                            </span>
                            <input 
                                type="datetime-local" 
                                class="form-control border-0 shadow-none" 
                                id="expiryDateTime" 
                                name="expiry_date" 
                                required
                            >
                        </div>
                        <div class="form-text text-muted mt-2">
                            <i class="fas fa-info-circle me-1"></i>Set when this question should automatically expire
                        </div>
                    </div>

                    <!-- Points -->
                    <div class="mb-3">
                        <label for="questionPoints" class="form-label">Points</label>
                        <input type="number" class="form-control" id="questionPoints" name="points" placeholder="Enter points" min="0" required />
                    </div>

                    <!-- Attempt Points -->
                    <div class="mb-3">
                        <label for="attemptPoint" class="form-label">Attempt Points</label>
                        <input 
                            type="number" 
                            class="form-control" 
                            id="attemptPoint" 
                            name="attempt_point" 
                            placeholder="Enter attempt points" 
                            min="0"
                            required
                        />
                    </div>
                </form>
            </div>

            <!-- Footer -->
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                <button type="submit" class="btn btn-primary" form="addQuestionForm">
                    <i class="fas fa-question-circle me-2"></i> Add Question
                </button>
            </div>
        </div>
    </div>
</div>

      <!-- User History Log Modal -->
      <div
        class="modal fade"
        id="userHistoryModal"
        tabindex="-1"
        aria-labelledby="userHistoryModalLabel"
        aria-hidden="true"
      >
        <div class="modal-dialog modal-xl">
          <!-- Made it larger -->
          <div class="modal-content">
            <div class="modal-header bg-primary text-white">
              <h5 class="modal-title" id="userHistoryModalLabel">
                User History Log
              </h5>
              <button
                type="button"
                class="btn-close btn-close-white"
                data-bs-dismiss="modal"
                aria-label="Close"
              ></button>
            </div>

            <div class="modal-body">
              <!-- Question Info -->
              <div class="mb-3">
                <label class="form-label fw-bold">Question:</label>
                <p id="historyQuestionText" class="mb-2 text-muted">
                  <!-- Dynamic Question Text -->
                  Which team will win today's match?
                </p>
              </div>

              <!-- Summary Counts -->
              <div class="row text-center mb-4">
                <div class="col-md-6">
                  <div class="border rounded py-3 bg-light">
                    <h6 class="text-success mb-1">
                      <i class="fas fa-check-circle me-1"></i> Yes
                    </h6>
                    <h4 id="yesCount">128</h4>
                  </div>
                </div>
                <div class="col-md-6">
                  <div class="border rounded py-3 bg-light">
                    <h6 class="text-danger mb-1">
                      <i class="fas fa-times-circle me-1"></i> No
                    </h6>
                    <h4 id="noCount">54</h4>
                  </div>
                </div>
              </div>

              <!-- Dual Table Layout -->
              <div class="row">
                <!-- YES Users Table -->
                <div class="col-md-6">
                  <div class="card border-success shadow-sm">
                    <div
                      class="card-header bg-success text-white text-center fw-bold"
                    >
                      Users Who Said YES
                    </div>
                    <div class="card-body p-0">
                      <div class="table-responsive">
                        <table
                          class="table table-striped table-bordered align-middle mb-0"
                        >
                          <thead class="table-success">
                            <tr>
                              <th class="text-center">#</th>
                              <th>User Name</th>
                              <th class="text-center">Date</th>
                            </tr>
                          </thead>
                          <tbody>
                            <tr>
                              <td class="text-center">1</td>
                              <td>Rohit Sharma</td>
                              <td class="text-center">2025-10-11</td>
                            </tr>
                            <tr>
                              <td class="text-center">2</td>
                              <td>Hardik Pandya</td>
                              <td class="text-center">2025-10-11</td>
                            </tr>
                            <tr>
                              <td class="text-center">3</td>
                              <td>MS Dhoni</td>
                              <td class="text-center">2025-10-10</td>
                            </tr>
                          </tbody>
                        </table>
                      </div>
                    </div>
                  </div>
                </div>

                <!-- NO Users Table -->
                <div class="col-md-6 mt-4 mt-md-0">
                  <div class="card border-danger shadow-sm">
                    <div
                      class="card-header bg-danger text-white text-center fw-bold"
                    >
                      Users Who Said NO
                    </div>
                    <div class="card-body p-0">
                      <div class="table-responsive">
                        <table
                          class="table table-striped table-bordered align-middle mb-0"
                        >
                          <thead class="table-danger">
                            <tr>
                              <th class="text-center">#</th>
                              <th>User Name</th>
                              <th class="text-center">Date</th>
                            </tr>
                          </thead>
                          <tbody>
                            <tr>
                              <td class="text-center">1</td>
                              <td>Virat Kohli</td>
                              <td class="text-center">2025-10-11</td>
                            </tr>
                            <tr>
                              <td class="text-center">2</td>
                              <td>KL Rahul</td>
                              <td class="text-center">2025-10-10</td>
                            </tr>
                            <tr>
                              <td class="text-center">3</td>
                              <td>Ravindra Jadeja</td>
                              <td class="text-center">2025-10-09</td>
                            </tr>
                          </tbody>
                        </table>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            <!-- Footer -->
            <div class="modal-footer">
              <button
                type="button"
                class="btn btn-secondary"
                data-bs-dismiss="modal"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      </div>

<!-- Edit Question Modal -->
<div class="modal fade" id="editQuestionModal" tabindex="-1" aria-labelledby="editQuestionModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-md">
        <div class="modal-content">
            <div class="modal-header bg-warning text-white">
                <h5 class="modal-title" id="editQuestionModalLabel">Edit Question</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>

            <div class="modal-body">
                <form id="editQuestionForm" method="POST" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PUT'); ?>

                    <!-- Category -->
                    <div class="mb-3">
                        <label for="editQuestionCategory" class="form-label">Category Type</label>
                        <select class="form-select" id="editQuestionCategory" name="category_id" required>
                            <option value="" disabled>Select category</option>
                            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($category->id); ?>"><?php echo e($category->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>

                    <!-- Subcategory -->
                    <div class="mb-3">
                        <label for="editQuestionSubcategory" class="form-label">Subcategory</label>
                        <select class="form-select" id="editQuestionSubcategory" name="subcategory_id">
                            <option value="" selected>Select subcategory (Optional)</option>
                            <!-- Subcategories will be loaded dynamically -->
                        </select>
                        <div class="form-text">Select a category first to see available subcategories</div>
                    </div>

                    <!-- SubSubCategory -->
                    <div class="mb-3">
                        <label for="editQuestionSubSubCategory" class="form-label">SubSubCategory</label>
                        <select class="form-select" id="editQuestionSubSubCategory" name="sub_sub_category_id">
                            <option value="" selected>Select sub-subcategory (Optional)</option>
                        </select>
                    </div>

                    <!-- Banner Image -->
                    <div class="mb-3">
                        <label for="editQuestionBanner" class="form-label">Banner Image (Optional)</label>
                        <input type="file" class="form-control" id="editQuestionBanner" name="banner_image" accept="image/*">
                        <img id="editBannerPreview" src="" alt="Banner Preview" class="mt-2" width="80" style="display:none;">
                        <div class="form-text">Leave empty to keep current image</div>
                    </div>

                    <!-- Banner Link -->
                    <div class="mb-3">
                        <label for="editBannerLink" class="form-label">Banner Link (Optional)</label>
                        <input type="url" class="form-control" id="editBannerLink" name="banner_link" placeholder="https://example.com">
                    </div>

                    <!-- Question -->
                    <div class="mb-3">
                        <label for="editQuestionText" class="form-label">Question</label>
                        <textarea class="form-control" id="editQuestionText" name="question" rows="3" placeholder="Edit the question here" required></textarea>
                    </div>

                    <!-- Options (Only 2) -->
                    <div class="mb-3">
                        <label class="form-label fw-semibold text-dark">Options</label>

                        <div class="input-group mb-2">
                            <span class="input-group-text">A</span>
                            <input type="text" class="form-control" id="editOptionA" name="options[]" placeholder="Enter option A" required>
                        </div>

                        <div class="input-group mb-2">
                            <span class="input-group-text">B</span>
                            <input type="text" class="form-control" id="editOptionB" name="options[]" placeholder="Enter option B" required>
                        </div>
                    </div>


                    <!-- Publish Date and Time -->
                    <div class="mb-3">
                        <label for="editPublishDatetime" class="form-label fw-semibold">
                            <i class="far fa-clock me-1 text-success"></i> Publish Date & Time
                        </label>
                        <div class="input-group">
                            <span class="input-group-text bg-light">
                                <i class="far fa-calendar-alt"></i>
                            </span>
                            <input 
                                type="datetime-local" 
                                class="form-control" 
                                id="editPublishDatetime" 
                                name="publish_at" 
                            >
                        </div>
                    </div>

                    <!-- Expiry Date and Time -->
                    <div class="mb-3">
                        <label for="editExpiryDatetime" class="form-label fw-semibold">
                            <i class="far fa-clock me-1 text-warning"></i> Expiry Date & Time
                        </label>
                        <div class="input-group">
                            <span class="input-group-text bg-light">
                                <i class="far fa-calendar-alt"></i>
                            </span>
                            <input 
                                type="datetime-local" 
                                class="form-control" 
                                id="editExpiryDatetime" 
                                name="expiry_date" 
                                required
                            >
                        </div>
                        <div class="form-text text-muted">
                            Choose when this question should expire.
                        </div>
                    </div>

                    <!-- Points -->
                    <div class="mb-3">
                        <label for="editQuestionPoints" class="form-label">Points</label>
                        <input type="number" class="form-control" id="editQuestionPoints" name="points" placeholder="Enter points" min="0" required>
                    </div>

                    <!-- Attempt Points -->
                    <div class="mb-3">
                        <label for="editAttemptPoint" class="form-label">Attempt Point</label>
                        <input 
                            type="number" 
                            class="form-control" 
                            id="editAttemptPoint" 
                            name="attempt_point" 
                            placeholder="Enter attempt points" 
                            min="0"
                        >
                    </div>

                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                        <button type="submit" class="btn btn-warning text-white" form="editQuestionForm">
                            <i class="fas fa-edit me-2"></i> Update Question
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>


<script>
document.addEventListener('DOMContentLoaded', function() {
    const editButtons = document.querySelectorAll('.edit-question-btn');
    const modalForm = document.getElementById('editQuestionForm');
    const categorySelect = document.getElementById('editQuestionCategory');
    const subcategorySelect = document.getElementById('editQuestionSubcategory');
    const questionTextarea = document.getElementById('editQuestionText');
    const pointsInput = document.getElementById('editQuestionPoints');
    const attemptPointInput = document.getElementById('editAttemptPoint');
    const bannerLinkInput = document.getElementById('editBannerLink');
    const bannerPreview = document.getElementById('editBannerPreview');
    const bannerFileInput = document.getElementById('editQuestionBanner');
    const expiryInput = document.getElementById('editExpiryDatetime');
    const publishInput = document.getElementById('editPublishDatetime');

    // ✅ New fields for options
    const optionAInput = document.getElementById('editOptionA');
    const optionBInput = document.getElementById('editOptionB');

    // ✅ SubSubCategory
    const subSubCategorySelect = document.getElementById('editQuestionSubSubCategory');

    function loadSubSubCategoriesForEdit(subcategoryId, selectedSubSubCategoryId = null) {
        subSubCategorySelect.innerHTML = '<option value="" selected>Select sub-subcategory (Optional)</option>';
        if (!subcategoryId) return;

        fetch(`/admin/get-subsubcategories/${subcategoryId}`)
            .then(res => res.json())
            .then(data => {
                subSubCategorySelect.innerHTML = '<option value="" selected>Select sub-subcategory (Optional)</option>';
                data.forEach(subSubCategory => {
                    const option = document.createElement('option');
                    option.value = subSubCategory.id;
                    option.textContent = subSubCategory.name;
                    if (selectedSubSubCategoryId && subSubCategory.id == selectedSubSubCategoryId) {
                        option.selected = true;
                    }
                    subSubCategorySelect.appendChild(option);
                });
            })
            .catch(() => {
                subSubCategorySelect.innerHTML = '<option value="">Error loading sub-subcategories</option>';
            });
    }

    // Event listener for subcategory change in Edit Modal
    subcategorySelect.addEventListener('change', function() {
        const subcategoryId = this.value;
        loadSubSubCategoriesForEdit(subcategoryId);
    });

    function loadSubcategoriesForEdit(categoryId, selectedSubcategoryId = null, selectedSubSubCategoryId = null) {
        subcategorySelect.innerHTML = '<option value="" selected>Select subcategory </option>';
        if (!categoryId) return;

        fetch(`/admin/get-subcategories/${categoryId}`)
            .then(res => res.json())
            .then(data => {
                subcategorySelect.innerHTML = '<option value="" selected>Select subcategory </option>';
                data.forEach(subcategory => {
                    const option = document.createElement('option');
                    option.value = subcategory.id;
                    option.textContent = subcategory.name;
                    if (selectedSubcategoryId && subcategory.id == selectedSubcategoryId) {
                        option.selected = true;
                    }
                    subcategorySelect.appendChild(option);
                });
            })
            .catch(() => {
                subcategorySelect.innerHTML = '<option value="">Error loading subcategories</option>';
            });
    }

    editButtons.forEach(button => {
        button.addEventListener('click', function() {
            const id = this.dataset.id;
            const categoryId = this.dataset.categoryId;
            const subcategoryId = this.dataset.subcategoryId || null;
            const question = this.dataset.question;
            const points = this.dataset.points;
            const attemptPoint = this.dataset.attemptPoint || '';
            const bannerLink = this.dataset.bannerLink;
            const bannerImage = this.dataset.bannerImage;
            const expiryDatetime = this.dataset.expiryDatetime;
            const publishDatetime = this.dataset.publishDatetime;
            const options = this.dataset.options ? JSON.parse(this.dataset.options) : [];

            // SubSubCategory
            const subSubCategoryId = this.dataset.subSubCategoryId || null;

            // Set form action
            modalForm.action = `/admin/questions/${id}`;

            // Prefill fields
            categorySelect.value = categoryId;
            questionTextarea.value = question;
            pointsInput.value = points;
            attemptPointInput.value = attemptPoint;
            attemptPointInput.value = attemptPoint;
            bannerLinkInput.value = bannerLink || '';
            expiryInput.value = expiryDatetime ? expiryDatetime.replace(' ', 'T') : '';
            publishInput.value = publishDatetime ? publishDatetime.replace(' ', 'T') : '';

            // ✅ Prefill options
            optionAInput.value = options[0] || '';
            optionBInput.value = options[1] || '';

            // Load subcategories
            if (categoryId) loadSubcategoriesForEdit(categoryId, subcategoryId, subSubCategoryId);

            // Load subsubcategories (if subcategory is already selected)
            if (subcategoryId) loadSubSubCategoriesForEdit(subcategoryId, subSubCategoryId);

            // Banner preview
            if (bannerImage) {
                bannerPreview.src = bannerImage;
                bannerPreview.style.display = 'block';
            } else {
                bannerPreview.style.display = 'none';
            }

            bannerFileInput.value = '';
        });
    });

    // Reset modal when closed
    document.getElementById('editQuestionModal').addEventListener('hidden.bs.modal', function() {
        subcategorySelect.innerHTML = '<option value="" selected>Select subcategory </option>';
        subSubCategorySelect.innerHTML = '<option value="" selected>Select sub-subcategory (Optional)</option>';
        expiryInput.value = '';
        publishInput.value = '';
        attemptPointInput.value = '';
        optionAInput.value = '';
        optionBInput.value = '';
    });
});
</script>



<!-- JavaScript for Dynamic Subcategory Loading -->
<script>
document.addEventListener('DOMContentLoaded', function() {
    const categorySelect = document.getElementById('questionCategory');
    const subcategorySelect = document.getElementById('questionSubcategory');
    const subSubCategorySelect = document.getElementById('questionSubSubCategory');
    
    // Function to load subcategories
    function loadSubcategories(categoryId) {
        // Clear existing options except the first one
        subcategorySelect.innerHTML = '<option value="" selected>Select subcategory </option>';
        
        if (!categoryId) {
            return;
        }
        
        // Show loading state
        const loadingOption = document.createElement('option');
        loadingOption.value = '';
        loadingOption.textContent = 'Loading subcategories...';
        loadingOption.disabled = true;
        subcategorySelect.appendChild(loadingOption);
        
        // Fetch subcategories via AJAX
        fetch(`/admin/get-subcategories/${categoryId}`)
            .then(response => {
                if (!response.ok) {
                    throw new Error('Network response was not ok');
                }
                return response.json();
            })
            .then(data => {
                // Remove loading option
                subcategorySelect.innerHTML = '<option value="" selected>Select subcategory </option>';
                
                if (data.length > 0) {
                    data.forEach(subcategory => {
                        const option = document.createElement('option');
                        option.value = subcategory.id;
                        option.textContent = subcategory.name;
                        subcategorySelect.appendChild(option);
                    });
                } else {
                    const option = document.createElement('option');
                    option.value = '';
                    option.textContent = 'No subcategories found';
                    option.disabled = true;
                    subcategorySelect.appendChild(option);
                }
            })
            .catch(error => {
                console.error('Error loading subcategories:', error);
                subcategorySelect.innerHTML = '<option value="" selected>Select subcategory (Optional)</option>';
                const errorOption = document.createElement('option');
                errorOption.value = '';
                errorOption.textContent = 'Error loading subcategories';
                errorOption.disabled = true;
                subcategorySelect.appendChild(errorOption);
            });
    }

    // Function to load sub-subcategories
    function loadSubSubCategories(subcategoryId) {
        subSubCategorySelect.innerHTML = '<option value="" selected>Select sub-subcategory</option>';

        if (!subcategoryId) {
            return;
        }

        const loadingOption = document.createElement('option');
        loadingOption.value = '';
        loadingOption.textContent = 'Loading...';
        loadingOption.disabled = true;
        subSubCategorySelect.appendChild(loadingOption);

        fetch(`/admin/get-subsubcategories/${subcategoryId}`)
            .then(response => response.json())
            .then(data => {
                subSubCategorySelect.innerHTML = '<option value="" selected>Select sub-subcategory</option>';
                data.forEach(subSubCategory => {
                    const option = document.createElement('option');
                    option.value = subSubCategory.id;
                    option.textContent = subSubCategory.name;
                    subSubCategorySelect.appendChild(option);
                });
            })
            .catch(error => {
                console.error('Error loading sub-subcategories:', error);
                subSubCategorySelect.innerHTML = '<option value="">Error loading sub-subcategories</option>';
            });
    }
    
    // Event listener for category change
    categorySelect.addEventListener('change', function() {
        const categoryId = this.value;
        loadSubcategories(categoryId);
        subSubCategorySelect.innerHTML = '<option value="" selected>Select sub-subcategory</option>'; // Clear subsub
    });

    // Event listener for subcategory change
    subcategorySelect.addEventListener('change', function() {
        const subcategoryId = this.value;
        loadSubSubCategories(subcategoryId);
    });
    
    // Clear subcategories when modal is hidden
    const addQuestionModal = document.getElementById('addQuestionModal');
    addQuestionModal.addEventListener('hidden.bs.modal', function() {
        subcategorySelect.innerHTML = '<option value="" selected>Select subcategory (Optional)</option>';
        subSubCategorySelect.innerHTML = '<option value="" selected>Select sub-subcategory</option>';
    });
});
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/FTLOP/Downloads/dailyopenion_subsubcat_website 2/resources/views/admin/questions.blade.php ENDPATH**/ ?>