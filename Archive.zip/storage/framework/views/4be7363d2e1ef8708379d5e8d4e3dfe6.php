<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Sport Opinion</title>
    <link
      href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css"
      rel="stylesheet"
    />
    <link
      href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css"
      rel="stylesheet"
      integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC"
      crossorigin="anonymous"
    />
    <link rel="stylesheet" href="<?php echo e(asset('website/style.css')); ?>" />
  </head>

  <body>
    <nav class="navbar navbar-expand-lg navbar-dark fixed-top">
      <div class="container overflow-x-hidden">
        <a class="navbar-brand" href="#">
          <img src="<?php echo e(asset('images/logo.png')); ?>" alt="Sport Opinion Logo" />
        </a>
        <button
          class="navbar-toggler"
          type="button"
          data-bs-toggle="collapse"
          data-bs-target="#navbarNav"
          aria-controls="navbarNav"
          aria-expanded="false"
          aria-label="Toggle navigation"
        >
          <span class="navbar-toggler-icon"></span>
        </button>
        <div
          class="collapse navbar-collapse justify-content-end"
          id="navbarNav"
        >
          <ul class="navbar-nav">
            <li class="nav-item">
              <a class="nav-link" href="#about">About Us</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="#features">Features</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="#how-it-works">How It Works</a>
            </li>

            <li class="nav-item">
              <a class="nav-link" href="#testimonials">Testimonials</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="#download">Download</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="#contact">Contact</a>
            </li>
          </ul>
        </div>
      </div>
    </nav>

    <section class="hero-section text-center text-md-start">
      <div class="container overflow-x-hidden">
        <div class="row align-items-center g-5">
          <div class="col-md-6">
            <h1 class="display-4 fw-bold mb-4">
              Express Your Game Opinions Daily
            </h1>
            <p class="lead mb-4">
              Download the Sports Opinion App today and make your voice heard —
              effortlessly.
            </p>
            <a
              href="https://play.google.com/store/apps/details?id=YOUR_APP_ID"
              target="_blank"
            >
              <img
                alt="Get it on Google Play"
                src="https://play.google.com/intl/en_us/badges/static/images/badges/en_badge_web_generic.png"
                style="height: 80px"
              />
            </a>
          </div>
          <div class="col-md-6 text-center">
            <img
              src="asset/DAILY OPINOIN mobile mockup 2.png"
              class="img-fluid banner-img"
              alt="CreativeCops Mobile App"
            />
          </div>
        </div>
      </div>
    </section>

    <section id="about" class="py-5 pb-md-5 pb-0">
      <div class="container overflow-x-hidden">
        <h2 class="section-title">About Us – Sports Opinion</h2>
        <div class="row justify-content-center">
          <div class="col-lg-10">
            <p class="lead">
              At <strong>Sports Opinion</strong>, fans come together to share
              their passion for the game. Our simple, engaging, and
              technology-powered platform lets you express opinions, spark
              debates, and join the ultimate sports community.
            </p>

            <p>
              Our mission at <strong>Sports Opinion</strong> is to empower fans
              with <strong>smart opinion-sharing features</strong>, transparent
              results, and a rewarding point system that makes every prediction
              and opinion fun and meaningful. Each day, users can respond to
              exciting sports questions, match predictions, or debates — and
              earn points for their <strong>“winning takes”</strong>, turning
              every game into an opportunity to win rewards.
            </p>

            <p>
              When your sports opinion <strong>wins</strong> or aligns with the
              most popular fan sentiment, you earn
              <strong>bonus points and exclusive rewards</strong>. This unique
              system encourages friendly competition, fair play, and keeps our
              sports community active, motivated, and engaged after every match.
            </p>

            <p>
              Over time, <strong>Sports Opinion</strong> has built a vibrant
              community of passionate fans who share thousands of opinions daily
              — from cricket and football to every trending sporting event. Our
              platform inspires open discussions and genuine fan insights that
              reflect the voice of real sports lovers everywhere.
            </p>

            <p>
              We take immense pride in our
              <strong>secure system, reliable performance</strong>, and fair
              rewarding process that ensures transparency and trust for every
              user. Our commitment to authenticity and engagement has earned us
              the confidence of countless fans, making
              <strong>Sports Opinion</strong> one of the most dependable
              platforms for sharing sports opinions online.
            </p>

            <p>
              At <strong>Sports Opinion</strong>, we believe in combining
              innovation, simplicity, and credibility to make expressing your
              sports passion effortless and rewarding. With every opinion you
              share, you’re not just participating — you’re shaping the fan
              conversation and earning real rewards along the way.
            </p>
          </div>
        </div>
      </div>
    </section>

    <!-- custom section -->
    <section id="vendor" class="py-5 pb-md-5 pb-0">
      <div class="container pt-0 pb-0 overflow-x-hidden">
        <div class="text-center">
          <h2 class="section-title mb-4">for Brands</h2>
          <div class="row justify-content-center">
            <div class="col-lg-10">
              <p class="mb-3">
                Engage a passionate sports audience with targeted campaigns and
                exciting giveaways through <strong>Sports Opinion</strong>.
              </p>

              <img
                class="img-fluid"
                src="asset/daily-openion-dashboard.webp"
                alt=""
              />
              <a href="mailto:info.startup2025@gmail.com" class="btn-cont">
                Contact With Us
              </a>
            </div>
          </div>
        </div>
      </div>
    </section>

    <section id="features" class="bg-light py-5">
      <div class="container overflow-x-hidden">
        <h2 class="section-title">Why Choose Sports Opinion?</h2>
        <div class="row g-4">
          <div class="col-md-6 col-lg-3">
            <div class="card h-100 p-4 text-center">
              <div class="card-body">
                <div class="feature-icon mb-3">
                  <i class="fa-solid fa-lightbulb"></i>
                </div>
                <h5 class="card-title fw-bold">Daily Sports Questions</h5>
                <p class="card-text text-muted">
                  Share your take on exciting daily sports questions and match
                  predictions — stay connected with every game that matters.
                </p>
              </div>
            </div>
          </div>

          <div class="col-md-6 col-lg-3">
            <div class="card h-100 p-4 text-center">
              <div class="card-body">
                <div class="feature-icon mb-3">
                  <i class="fa-solid fa-coins"></i>
                </div>
                <h5 class="card-title fw-bold">Earn Points & Rewards</h5>
                <p class="card-text text-muted">
                  Score points for your winning opinions and earn exclusive
                  rewards when your predictions or takes match the popular fan
                  vote.
                </p>
              </div>
            </div>
          </div>

          <div class="col-md-6 col-lg-3">
            <div class="card h-100 p-4 text-center">
              <div class="card-body">
                <div class="feature-icon mb-3">
                  <i class="fa-solid fa-users"></i>
                </div>
                <h5 class="card-title fw-bold">Fan Community</h5>
                <p class="card-text text-muted">
                  Be part of a passionate fan community — discuss matches, share
                  opinions, and celebrate every win together.
                </p>
              </div>
            </div>
          </div>

          <div class="col-md-6 col-lg-3">
            <div class="card h-100 p-4 text-center">
              <div class="card-body">
                <div class="feature-icon mb-3">
                  <i class="fa-solid fa-mobile-screen-button"></i>
                </div>
                <h5 class="card-title fw-bold">Easy & Fun Experience</h5>
                <p class="card-text text-muted">
                  Enjoy a smooth, engaging, and rewarding experience through our
                  easy-to-use app — perfect for every sports fan.
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>

    <section id="how-it-works" class="py-5">
      <div class="container overflow-x-hidden">
        <h2 class="section-title">How Sports Opinion Works</h2>
        <div class="row g-5 align-items-center">
          <div class="col-lg-6 text-center">
            <img
              src="asset/mobile mockup 3.png"
              class="img-fluid animate-fade-in-up"
              alt="Sports Opinion App in Action"
              style="max-height: 500px"
            />
          </div>

          <div class="col-lg-6">
            <div
              class="d-flex align-items-start mb-4 animate-fade-in-up delay-100"
            >
              <div class="step-number flex-shrink-0 me-4">1</div>
              <div>
                <h5 class="fw-bold">Download the App</h5>
                <p class="text-muted">
                  Available on Android and iOS — get the
                  <strong>Sports Opinion</strong> app and join the ultimate
                  community for fans who love to share their game-day takes.
                </p>
              </div>
            </div>

            <div
              class="d-flex align-items-start mb-4 animate-fade-in-up delay-200"
            >
              <div class="step-number flex-shrink-0 me-4">2</div>
              <div>
                <h5 class="fw-bold">Sign Up and Start Sharing</h5>
                <p class="text-muted">
                  Create your account in minutes and start sharing your opinions
                  on live matches, trending topics, and sports predictions every
                  day.
                </p>
              </div>
            </div>

            <div
              class="d-flex align-items-start mb-4 animate-fade-in-up delay-300"
            >
              <div class="step-number flex-shrink-0 me-4">3</div>
              <div>
                <h5 class="fw-bold">Earn Points for Winning Takes</h5>
                <p class="text-muted">
                  Score points when your opinions or predictions match the
                  majority fan response — turning your sports knowledge into
                  real rewards.
                </p>
              </div>
            </div>

            <div class="d-flex align-items-start animate-fade-in-up delay-400">
              <div class="step-number flex-shrink-0 me-4">4</div>
              <div>
                <h5 class="fw-bold">Redeem Exclusive Rewards</h5>
                <p class="text-muted">
                  Use your earned points to unlock exciting prizes and enjoy a
                  rewarding fan experience after every game.
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>

    <section id="testimonials" class="py-5">
      <div class="container overflow-x-hidden mb-5">
        <h2 class="section-title">Trusted by Fans, Loved for Rewards</h2>
        <div class="row g-4 justify-content-center">
          <div class="col-lg-4">
            <div class="card h-100 p-4 testimonial-card">
              <div class="card-body">
                <p class="card-text fst-italic text-muted">
                  Sports Opinion makes it exciting to share my views after every
                  match! I love expressing my opinions and earning rewards for
                  my game predictions.
                </p>
                <p class="fw-bold mt-3 text-end">
                  — Rahul Mehta, Cricket Enthusiast
                </p>
              </div>
            </div>
          </div>

          <div class="col-lg-4">
            <div class="card h-100 p-4 testimonial-card">
              <div class="card-body">
                <p class="card-text fst-italic text-muted">
                  I really enjoy how Sports Opinion rewards accurate takes and
                  fan predictions. It keeps me coming back after every big
                  match!
                </p>
                <p class="fw-bold mt-3 text-end">
                  — Priya Sharma, Football Fan
                </p>
              </div>
            </div>
          </div>

          <div class="col-lg-4">
            <div class="card h-100 p-4 testimonial-card">
              <div class="card-body">
                <p class="card-text fst-italic text-muted">
                  The app is super fun and easy to use! Tracking my points and
                  unlocking rewards for my winning opinions makes every match
                  more thrilling.
                </p>
                <p class="fw-bold mt-3 text-end">
                  — Arjun Verma, Sports Community Member
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>

    <section id="download" class="download-section text-center text-md-start">
      <div class="container overflow-hidden-section">
        <div class="row align-items-center g-5">
          <div class="col-md-6 text-center text-md-start">
            <h2 class="fw-bold mb-4 animate-fade-in-up">
              Ready to Share Your Sports Opinions and Earn Rewards?
            </h2>
            <p class="lead mb-4 animate-fade-in-up delay-100">
              Join thousands of passionate fans sharing their views on every
              match, earning points, and unlocking exciting rewards with
              <strong>Sports Opinion</strong>.
            </p>
            <div class="animate-fade-in-up delay-200">
              <a
                href="https://play.google.com/store/apps/details?id=YOUR_APP_ID"
                target="_blank"
              >
                <img
                  alt="Get it on Google Play"
                  src="https://play.google.com/intl/en_us/badges/static/images/badges/en_badge_web_generic.png"
                  style="height: 60px"
                />
              </a>
            </div>
          </div>

          <div
            class="col-md-6 text-center animate-fade-in-up delay-300 d-none d-md-block"
          >
            <img
              src="asset/mobile mockup 3.png"
              alt="Sports Opinion App Mockup"
              class="img-fluid download-image"
            />
          </div>
        </div>
      </div>
    </section>

    <footer id="contact" class="footer py-5">
      <div class="container overflow-x-hidden">
        <div class="row g-4">
          <div class="col-md-6 col-lg-3">
            <h5 class="fw-bold text-white mb-3">Sports Opinion</h5>
            <p class="footer-nav">
              A dynamic platform where every fan’s voice matters. Share your
              sports opinions, predict match outcomes, earn points for winning
              takes, and redeem exciting rewards — all in one fun and engaging
              app.
            </p>

            <div class="social-links mt-3">
              <a
                href="https://www.facebook.com/profile.php?id=61582237433267"
                target="_blank"
                aria-label="Facebook"
                ><i class="fab fa-facebook-f"></i
              ></a>
              <a href="#" aria-label="Instagram"
                ><i class="fab fa-instagram"></i
              ></a>
            </div>
          </div>

          <div class="col-md-6 col-lg-9">
            <div class="row g-2">
              <!-- smaller gap only for these three columns -->
              <div class="col-md-3">
                <h5 class="fw-bold text-white mb-3">Quick Links</h5>
                <ul class="list-unstyled">
                  <li>
                    <a href="#about" class="text-decoration-none footer-nav"
                      >About Us</a
                    >
                  </li>
                  <li>
                    <a href="#features" class="text-decoration-none footer-nav"
                      >Features</a
                    >
                  </li>
                  <li>
                    <a
                      href="#how-it-works"
                      class="text-decoration-none footer-nav"
                      >How It Works</a
                    >
                  </li>
                  <li>
                    <a
                      href="#testimonials"
                      class="text-decoration-none footer-nav"
                      >Testimonials</a
                    >
                  </li>
                </ul>
              </div>

              <div class="col-md-4">
                <h5 class="fw-bold text-white mb-3">Legal</h5>
                <ul class="list-unstyled">
                  <li>
                    <a href="terms.html" class="text-decoration-none footer-nav"
                      >Terms and Conditions</a
                    >
                  </li>
                  <li>
                    <a
                      href="<?php echo e(route('website.privacy')); ?>"
                      class="text-decoration-none footer-nav"
                      >Privacy Policy</a
                    >
                  </li>
                </ul>
              </div>

              <div class="col-md-5">
                <h5 class="fw-bold text-white mb-3">Contact Us</h5>
                <ul class="list-unstyled">
                  <li>
                    <i class="fa-solid fa-envelope me-2"></i>
                    <a
                      href="mailto:info.startup2025@gmail.com"
                      class="footer-nav text-decoration-none"
                      >Email: info.startup2025@gmail.com
                    </a>
                  </li>
                  <li>
                    <i class="fa-solid fa-phone me-2"></i>
                    <a
                      href="tel:+918708680041"
                      class="footer-nav text-decoration-none"
                    >
                      Phone: +91 870 868 0041
                    </a>
                  </li>
                  <li>
                    <i class="fa-solid fa-map-pin me-2"></i>
                    <span class="footer-nav text-decoration-none">
                      Address: Hisar, Haryana, India
                    </span>
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </div>

        <hr class="mt-5" />
        <div class="text-center pt-3">
          <p class="text-white mb-0">
            &copy; 2025 Harbhala Enterprises. All rights reserved | Created by
            <a
              href="https://bmdu.net/"
              target="_blank"
              style="text-decoration: none; color: inherit"
              >BMDU</a
            >.
          </p>
        </div>
      </div>
    </footer>

    <script
      src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"
      integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM"
      crossorigin="anonymous"
    ></script>
    <script src="<?php echo e(asset('website/script.js')); ?>"></script>
  </body>
</html>
<?php /**PATH /Users/FTLOP/Downloads/dailyopenion_subsubcat_website 2/resources/views/welcome.blade.php ENDPATH**/ ?>