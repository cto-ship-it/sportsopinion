<?php $__env->startSection('title', 'Sub Subcategories'); ?>

<?php $__env->startSection('content'); ?>

 <!-- Sub Subcategories Page -->
        <div id="subsubcategories-page" class="page-content">
          <div class="page-header justify-content-between">
            <!-- Breadcrumb Navigation -->
            <nav aria-label="breadcrumb">
              <ol class="breadcrumb">
                <li class="breadcrumb-item">
                  <a href="<?php echo e(route('subcategories.index')); ?>">Subcategories</a>
                </li>
                <li class="breadcrumb-item active" aria-current="page">
                  Sub Subcategories
                </li>
              </ol>
            </nav>

            <h4 class="page-title">Sub Subcategory Management</h4>

            <button
              type="button"
              class="btn bg-info text-white"
              data-bs-toggle="modal"
              data-bs-target="#addSubSubcategoryModal"
            >
              <i class="fas fa-plus me-2"></i> Add Sub Subcategory
            </button>
          </div>

          <div class="card">
            <div class="card-body">
              <div class="row g-3 align-items-center">
                <!-- Search Bar -->
                <?php if (isset($component)) { $__componentOriginal465912bafb53d2799b51398725f2e117 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal465912bafb53d2799b51398725f2e117 = $attributes; } ?>
<?php $component = App\View\Components\Search::resolve(['action' => route('subsubcategories.index'),'placeholder' => 'Search sub subcategories...'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('search'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Search::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal465912bafb53d2799b51398725f2e117)): ?>
<?php $attributes = $__attributesOriginal465912bafb53d2799b51398725f2e117; ?>
<?php unset($__attributesOriginal465912bafb53d2799b51398725f2e117); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal465912bafb53d2799b51398725f2e117)): ?>
<?php $component = $__componentOriginal465912bafb53d2799b51398725f2e117; ?>
<?php unset($__componentOriginal465912bafb53d2799b51398725f2e117); ?>
<?php endif; ?>

                <!-- Export Button / Filter Button -->
                <div class="col-md-4">
                  <div class="d-flex justify-content-end gap-2">
                    <button class="btn btn-outline-secondary" id="resetFilters">
                      <i class="fas fa-sync-alt"></i>
                    </button>
                  </div>
                </div>
              </div>
            </div>
          </div>

          <div class="card">
            <div class="card-body">
            <div class="table-responsive">
                <table class="table table-hover" id="subsubcategoriesTable">
                <thead>
                    <tr>
                    <th class="text-center">Sr.No.</th>
                    <th class="text-center">Date</th>
                    <th class="text-center">Sub Category</th>
                    <th class="text-center">Name</th>
                    <th class="text-center">Description</th>
                    <th class="text-center">Status</th>
                    <th class="text-center">Edit / Delete</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $subsubcategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $subsubcategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td class="text-center"><?php echo e($key + 1); ?></td>
                        <td class="text-center"><?php echo e($subsubcategory->created_at ? $subsubcategory->created_at->format('d M Y') : '-'); ?></td>
                        <td class="text-center"><?php echo e($subsubcategory->subcategory->name ?? '-'); ?></td>
                        <td class="text-center"><?php echo e($subsubcategory->name); ?></td>
                        <td class="text-center"><?php echo e($subsubcategory->description); ?></td>
                        <td class="text-center">
                          <span class="badge bg-<?php echo e($subsubcategory->status ? 'success' : 'secondary'); ?>">
                            <?php echo e($subsubcategory->status ? 'Active' : 'Inactive'); ?>

                          </span>
                        </td>

                        <td class="text-center">
                        <!-- Edit Button -->
                        <button
                            type="button"
                            class="btn btn-sm btn-warning me-1 edit-subsubcategory-btn"
                            data-bs-toggle="modal"
                            data-bs-target="#editSubSubcategoryModal"
                            data-id="<?php echo e($subsubcategory->id); ?>"
                            data-name="<?php echo e($subsubcategory->name); ?>"
                            data-description="<?php echo e($subsubcategory->description); ?>"
                            data-status="<?php echo e($subsubcategory->status); ?>"
                            data-subcategory="<?php echo e($subsubcategory->subcategory_id); ?>"
                        >
                            <i class="fas fa-edit me-1"></i> Edit
                        </button>

                        <!-- Delete Button -->
                        <form action="<?php echo e(route('subsubcategories.destroy', $subsubcategory->id)); ?>" method="POST" class="d-inline">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button type="submit" class="btn btn-sm btn-danger" onclick="return confirm('Are you sure you want to delete this sub subcategory?')">
                            <i class="fas fa-trash me-1"></i> Delete
                            </button>
                        </form>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="7" class="text-center">No sub subcategories found.</td>
                    </tr>
                    <?php endif; ?>
                </tbody>
                </table>
            </div>
             <!-- PAGINATION -->
              <?php if(isset($subsubcategories) && $subsubcategories->hasPages()): ?>
                  <?php echo $__env->make('admin.layouts.pagination', ['paginator' => $subsubcategories], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
              <?php endif; ?>
            </div>
          </div>
        </div>

       <!-- Add Sub Subcategory Modal -->
        <div class="modal fade" id="addSubSubcategoryModal" tabindex="-1" aria-labelledby="addSubSubcategoryModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-md">
            <div class="modal-content">
            <div class="modal-header bg-primary text-white">
                <h5 class="modal-title" id="addSubSubcategoryModalLabel">Add Sub Subcategory</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>

            <div class="modal-body">
                <form id="addSubSubcategoryForm" method="POST" action="<?php echo e(route('subsubcategories.store')); ?>">
                <?php echo csrf_field(); ?>

                <!-- SubCategory -->
                <div class="mb-3">
                    <label for="subcategorySelect" class="form-label">Sub Category</label>
                    <select name="subcategory_id" class="form-select" id="subcategorySelect" required>
                      <option value="">Select Sub Category</option>
                      <?php $__currentLoopData = $subcategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subcategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($subcategory->id); ?>" <?php echo e(old('subcategory_id') == $subcategory->id ? 'selected' : ''); ?>>
                          <?php echo e($subcategory->name); ?> (<?php echo e($subcategory->category->name ?? 'No Cat'); ?>)
                        </option>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <?php $__errorArgs = ['subcategory_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="text-danger"><?php echo e($message); ?></span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <!-- Name -->
                <div class="mb-3">
                    <label for="subsubcategoryName" class="form-label">Name</label>
                    <input
                    type="text"
                    name="name"
                    class="form-control"
                    id="subsubcategoryName"
                    placeholder="Enter name"
                    value="<?php echo e(old('name')); ?>"
                    required
                    />
                    <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="text-danger"><?php echo e($message); ?></span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <!-- Description -->
                <div class="mb-3">
                    <label for="subsubcategoryDescription" class="form-label">Description</label>
                    <textarea
                    name="description"
                    class="form-control"
                    id="subsubcategoryDescription"
                    rows="3"
                    placeholder="Enter description"
                    ><?php echo e(old('description')); ?></textarea>
                    <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="text-danger"><?php echo e($message); ?></span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <!-- Status -->
                <div class="mb-3">
                  <label class="form-label">Status</label>
                  <div>
                    <div class="form-check form-check-inline">
                      <input class="form-check-input" type="radio" name="status" id="statusActive" value="1" checked>
                      <label class="form-check-label" for="statusActive">Active</label>
                    </div>
                    <div class="form-check form-check-inline">
                      <input class="form-check-input" type="radio" name="status" id="statusInactive" value="0">
                      <label class="form-check-label" for="statusInactive">Inactive</label>
                    </div>
                  </div>
                  <?php $__errorArgs = ['status'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                  <span class="text-danger"><?php echo e($message); ?></span>
                  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                </form>
            </div>

            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">
                Cancel
                </button>
                <button type="submit" class="btn btn-primary" form="addSubSubcategoryForm">
                <i class="fas fa-plus me-2"></i> Add
                </button>
            </div>
            </div>
        </div>
        </div>

     <!-- Edit Sub Subcategory Modal -->
<div class="modal fade" id="editSubSubcategoryModal" tabindex="-1" aria-labelledby="editSubSubcategoryModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-md">
    <div class="modal-content">
      <div class="modal-header bg-warning text-white">
        <h5 class="modal-title" id="editSubSubcategoryModalLabel">Edit Sub Subcategory</h5>
        <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>

      <div class="modal-body">
        <form id="editSubSubcategoryForm" method="POST" action="">
          <?php echo csrf_field(); ?>
          <?php echo method_field('PUT'); ?>

          <!-- SubCategory -->
          <div class="mb-3">
            <label for="editSubcategorySelect" class="form-label">Sub Category</label>
            <select name="subcategory_id" class="form-select" id="editSubcategorySelect" required>
              <option value="">Select Sub Category</option>
              <?php $__currentLoopData = $subcategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subcategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($subcategory->id); ?>">
                  <?php echo e($subcategory->name); ?> (<?php echo e($subcategory->category->name ?? 'No Cat'); ?>)
                </option>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
          </div>

          <!-- Name -->
          <div class="mb-3">
            <label for="editName" class="form-label">Name</label>
            <input
              type="text"
              name="name"
              class="form-control"
              id="editName"
              required
            />
          </div>

          <!-- Description -->
          <div class="mb-3">
            <label for="editDescription" class="form-label">Description</label>
            <textarea
              name="description"
              class="form-control"
              id="editDescription"
              rows="3"
            ></textarea>
          </div>

          <!-- Status -->
          <div class="mb-3">
            <label class="form-label">Status</label>
            <div>
              <div class="form-check form-check-inline">
                <input class="form-check-input" type="radio" name="status" id="editStatusActive" value="1">
                <label class="form-check-label" for="editStatusActive">Active</label>
              </div>
              <div class="form-check form-check-inline">
                <input class="form-check-input" type="radio" name="status" id="editStatusInactive" value="0">
                <label class="form-check-label" for="editStatusInactive">Inactive</label>
              </div>
            </div>
          </div>
        </form>
      </div>

      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
        <button type="submit" class="btn btn-warning text-white" form="editSubSubcategoryForm">
          <i class="fas fa-edit me-2"></i> Update
        </button>
      </div>
    </div>
  </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function () {
    const editButtons = document.querySelectorAll('.edit-subsubcategory-btn');
    const editModal = document.getElementById('editSubSubcategoryModal');

    editButtons.forEach(button => {
        button.addEventListener('click', function () {
            const id = this.getAttribute('data-id');
            const name = this.getAttribute('data-name');
            const description = this.getAttribute('data-description');
            const status = this.getAttribute('data-status');
            const subcategory = this.getAttribute('data-subcategory');

            // Set values in the modal form
            editModal.querySelector('form').action = `/admin/subsubcategories/${id}`;
            editModal.querySelector('#editName').value = name;
            editModal.querySelector('#editDescription').value = description;
            editModal.querySelector('#editSubcategorySelect').value = subcategory;
            
            // Set status radio button
            if (status === '1') {
                document.getElementById('editStatusActive').checked = true;
            } else {
                document.getElementById('editStatusInactive').checked = true;
            }
        });
    });
});
</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/FTLOP/Downloads/dailyopenion_subsubcat_website 2/resources/views/admin/subsubcategory.blade.php ENDPATH**/ ?>