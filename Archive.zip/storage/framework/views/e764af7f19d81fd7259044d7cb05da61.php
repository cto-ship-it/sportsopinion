<!-- Sidebar -->
<?php
    $userPermissions = auth()->user()->permissions ?? [];
?>

<style>
    .sidebar {
        width: 250px;
        background-color: #0B1E3F; /* Dark navy blue */
        color: white;
        min-height: 100vh;
    }

    /* === Logo Section (white background only) === */
    .sidebar .logo-section {
        background-color: #ffffff; /* White background */
        padding: 20px 0;
        border-bottom: 3px solid #FFD700; /* Yellow accent divider */
        display: flex;
        justify-content: center;
        align-items: center;
    }

    .sidebar .logo-section img {
        width: 100px;
    }

    .sidebar hr {
        border-color: rgba(255, 255, 255, 0.2);
    }

    .sidebar .nav-link {
        color: #ffffff;
        padding: 10px 15px;
        border-radius: 4px;
        display: flex;
        align-items: center;
        gap: 10px;
        transition: all 0.3s ease;
        font-weight: 500;
    }

    .sidebar .nav-link i {
        width: 20px;
        text-align: center;
    }

    .sidebar .nav-link:hover {
        background-color: #FFD700; /* Yellow hover */
        color: #0B1E3F;
    }

    .sidebar .nav-link.active {
        background-color: #FFD700; /* Active yellow */
        color: #0B1E3F;
        font-weight: 600;
    }

    .sidebar .collapsible-menu {
        list-style: none;
        padding-left: 15px;
        margin-top: 5px;
    }

    .sidebar .collapsible-menu .menu-item {
        display: block;
        padding: 8px 15px;
        color: #ffffff;
        border-radius: 4px;
        transition: all 0.3s ease;
    }

    .sidebar .collapsible-menu .menu-item:hover,
    .sidebar .collapsible-menu .menu-item.active {
        background-color: #FFD700;
        color: #0B1E3F;
    }

    .sidebar .nav-item + .nav-item {
        margin-top: 5px;
    }
</style>

<div class="sidebar p-0">
    <!-- White Logo Section -->
    <div class="logo-section">
        <img src="<?php echo e(asset('images/logo.png')); ?>" alt="logo" style="width: 200px" />
    </div>

    <div class="p-3">
        <ul class="nav flex-column">

            <?php if(isset($userPermissions['dashboard'])): ?>
            <li class="nav-item">
                <a class="nav-link <?php echo e(request()->routeIs('admin.dashboard') ? 'active' : ''); ?>" 
                   href="<?php echo e(route('admin.dashboard')); ?>">
                    <i class="fas fa-home"></i> Dashboard
                </a>
            </li>
            <?php endif; ?>

            <?php if(isset($userPermissions['users'])): ?>
            <li class="nav-item">
                <a class="nav-link <?php echo e(request()->routeIs('admin.users') ? 'active' : ''); ?>" 
                   href="<?php echo e(route('admin.users')); ?>">
                    <i class="fas fa-users"></i> Users
                </a>
            </li>
            <?php endif; ?>

            <?php if(isset($userPermissions['points'])): ?>
            <li class="nav-item">
                <a class="nav-link <?php echo e(request()->routeIs('admin.points') ? 'active' : ''); ?>" 
                   href="<?php echo e(route('admin.points')); ?>">
                    <i class="fas fa-shopping-cart"></i> Points
                </a>
            </li>
            <?php endif; ?>

            <?php if(isset($userPermissions['categories'])): ?>
            <li class="nav-item">
                <a class="nav-link <?php echo e(request()->routeIs('categories.*') ? 'active' : ''); ?>" 
                   href="<?php echo e(route('categories.index')); ?>">
                    <i class="fa-solid fa-folder"></i> Categories
                </a>
            </li>
            <?php endif; ?>

            <?php if(isset($userPermissions['subcategories'])): ?>
            <li class="nav-item">
                <a class="nav-link <?php echo e(request()->routeIs('subcategories.index') ? 'active' : ''); ?>" 
                   href="<?php echo e(route('subcategories.index')); ?>">
                    <i class="fa-solid fa-diagram-project"></i> Subcategories
                </a>
            </li>
            <?php endif; ?>

            <?php if(isset($userPermissions['subcategories'])): ?>
            <li class="nav-item">
                <a class="nav-link <?php echo e(request()->routeIs('subsubcategories.index') ? 'active' : ''); ?>" 
                   href="<?php echo e(route('subsubcategories.index')); ?>">
                    <i class="fa-solid fa-sitemap"></i> Sub Subcategories
                </a>
            </li>
            <?php endif; ?>

            <?php if(isset($userPermissions['rewards'])): ?>
            <li class="nav-item">
                <a class="nav-link <?php echo e(request()->routeIs('admin.rewards') ? 'active' : ''); ?>" 
                   href="<?php echo e(route('admin.rewards')); ?>">
                    <i class="fas fa-gift"></i> Rewards
                </a>
            </li>
            <?php endif; ?>

            <?php if(
                isset($userPermissions['reedem.pending']) || 
                isset($userPermissions['reedem.processing']) ||
                isset($userPermissions['reedem.complete']) ||
                isset($userPermissions['reedem.cancel'])
            ): ?>
            <li class="nav-item">
                <a class="nav-link <?php echo e(request()->routeIs('admin.reedem.*') ? 'active' : ''); ?>" 
                   data-bs-toggle="collapse" 
                   href="#reedemCollapse" 
                   role="button" 
                   aria-expanded="<?php echo e(request()->routeIs('admin.reedem.*') ? 'true' : 'false'); ?>">
                    <i class="fas fa-box-open"></i> Redeem
                    <i class="fas fa-chevron-down float-end mt-1" style="font-size: 12px"></i>
                </a>
                <div class="collapse <?php echo e(request()->routeIs('admin.reedem.*') ? 'show' : ''); ?>" id="reedemCollapse">
                    <ul class="collapsible-menu">
                        <?php if(isset($userPermissions['reedem.pending'])): ?>
                        <li><a class="menu-item <?php echo e(request()->routeIs('admin.reedem.pending') ? 'active' : ''); ?>" 
                               href="<?php echo e(route('admin.reedem.pending')); ?>"><i class="fa-solid fa-clock"></i> Pending</a></li>
                        <?php endif; ?>
                        <?php if(isset($userPermissions['reedem.processing'])): ?>
                        <li><a class="menu-item <?php echo e(request()->routeIs('admin.reedem.processing') ? 'active' : ''); ?>" 
                               href="<?php echo e(route('admin.reedem.processing')); ?>"><i class="fas fa-tools"></i> Approved</a></li>
                        <?php endif; ?>
                        <?php if(isset($userPermissions['reedem.complete'])): ?>
                        <li><a class="menu-item <?php echo e(request()->routeIs('admin.reedem.complete') ? 'active' : ''); ?>" 
                               href="<?php echo e(route('admin.reedem.complete')); ?>"><i class="fas fa-check-circle"></i> Complete</a></li>
                        <?php endif; ?>
                        <?php if(isset($userPermissions['reedem.cancel'])): ?>
                        <li><a class="menu-item <?php echo e(request()->routeIs('admin.reedem.cancel') ? 'active' : ''); ?>" 
                               href="<?php echo e(route('admin.reedem.cancel')); ?>"><i class="fas fa-times-circle"></i> Cancel</a></li>
                        <?php endif; ?>
                    </ul>
                </div>
            </li>
            <?php endif; ?>

            <?php if(auth()->user()->role === 'super_admin'): ?>
            <li class="nav-item">
                <a class="nav-link" href="#" data-bs-toggle="modal" data-bs-target="#changePasswordModal">
                    <i class="fas fa-key"></i> Password
                </a>
            </li>
            <?php endif; ?>

            <?php if(isset($userPermissions['question'])): ?>
            <li class="nav-item">
                <a class="nav-link <?php echo e(request()->routeIs('admin.question') ? 'active' : ''); ?>" 
                   href="<?php echo e(route('admin.question')); ?>">
                    <i class="fa-solid fa-circle-question"></i> Questions
                </a>
            </li>
            <?php endif; ?>

            <?php if(isset($userPermissions['banners'])): ?>
            <li class="nav-item">
                <a class="nav-link <?php echo e(request()->routeIs('admin.banners') ? 'active' : ''); ?>" 
                   href="<?php echo e(route('admin.banners')); ?>">
                    <i class="fa-solid fa-image"></i> Banners
                </a>
            </li>
            <?php endif; ?>

            <?php if(isset($userPermissions['faqs'])): ?>
            <li class="nav-item">
                <a class="nav-link <?php echo e(request()->routeIs('admin.faqs') ? 'active' : ''); ?>" 
                   href="<?php echo e(route('admin.faqs')); ?>">
                    <i class="fa-solid fa-circle-question"></i> FAQs
                </a>
            </li>
            <?php endif; ?>

            <?php if(isset($userPermissions['roles'])): ?>
            <li class="nav-item">
                <a class="nav-link <?php echo e(request()->routeIs('roles.index') ? 'active' : ''); ?>" 
                   href="<?php echo e(route('roles.index')); ?>">
                    <i class="fa-solid fa-user-shield"></i> Roles
                </a>
            </li>
            <?php endif; ?>

            <?php if(isset($userPermissions['permissions'])): ?>
            <li class="nav-item">
                <a class="nav-link <?php echo e(request()->routeIs('permissions.index') ? 'active' : ''); ?>" 
                   href="<?php echo e(route('permissions.index')); ?>">
                    <i class="fa-solid fa-lock"></i> Permissions
                </a>
            </li>
            <?php endif; ?>

            <li class="nav-item mt-3">
                <a class="nav-link" href="<?php echo e(route('logout')); ?>" 
                   onclick="event.preventDefault(); document.getElementById('logout-form').submit();">
                    <i class="fa-solid fa-right-from-bracket"></i> Logout
                </a>
                <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                    <?php echo csrf_field(); ?>
                </form>
            </li>
        </ul>
    </div>
</div>
<?php /**PATH /Users/FTLOP/Downloads/dailyopenion_subsubcat_website 2/resources/views/admin/layouts/sidebar.blade.php ENDPATH**/ ?>