<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Rewards extends Model
{
    use HasFactory;

    protected $table = 'rewards';

    protected $fillable = [
        'image',
        'name',
        'description',
        'points',
        'expiry_date',
        'status',
    ];

    protected $appends = ['image_url'];

   
    public function getImageUrlAttribute(): ?string
    {
        if (!$this->image) {
            return null;
        }

        if (filter_var($this->image, FILTER_VALIDATE_URL)) {
            return $this->image;
        }

        return asset('storage/' . $this->image);
    }

    public function redeemRequests()
    {
        return $this->hasMany(CustomerRedeemRequest::class);
    }
}
