<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Question extends Model
{
    use HasFactory;

     protected $fillable = [
        'category_id',
        'subcategory_id',
        'sub_sub_category_id',
        'question',
        'options',
        'answer',
        'answer_status',
        'banner_image',
        'banner_link',
        'publish_at',
        'expiry_date',
        'points',
        'attempt_point',
    ];

    protected $casts = [
        'options' => 'array',       
        'expiry_date' => 'datetime',
        'publish_at' => 'datetime',
    ];

    public function category()
    {
        return $this->belongsTo(Category::class);
    }

    public function answers()
{
    return $this->hasMany(CustomerAnswer::class);
}

    public function subcategory()
    {
        return $this->belongsTo(Subcategory::class);
    }

    public function subSubCategory()
    {
        return $this->belongsTo(SubSubCategory::class, 'sub_sub_category_id');
    }

    public function scopePublished($query)
    {
        return $query->where(function ($q) {
            $q->whereNull('publish_at')
              ->orWhere('publish_at', '<=', now());
        });
    }

}
