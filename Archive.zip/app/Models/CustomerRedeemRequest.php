<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class CustomerRedeemRequest extends Model
{
    use HasFactory;

    protected $fillable = [
        'customer_id',
        'reward_id',
        'points',
        'status',
        'remarks',
        'approved_at',
    ];

    public function reward()
{
    return $this->belongsTo(Rewards::class);
}

public function customer()
{
    return $this->belongsTo(Customer::class, 'customer_id');
}

}
