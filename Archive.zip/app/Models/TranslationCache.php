<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class TranslationCache extends Model
{
    use HasFactory;

    protected $table = 'translations_cache';

    protected $fillable = [
        'translatable_type',
        'translatable_id',
        'field_name',
        'source_language',
        'target_language',
        'original_content',
        'translated_content',
        'translated_at',
    ];

    protected $casts = [
        'translated_at' => 'datetime',
    ];

    /**
     * Get the owning translatable model.
     */
    public function translatable()
    {
        return $this->morphTo();
    }

    /**
     * Get cached translation or return null if not exists
     */
    public static function getCachedTranslation(
        string $type,
        int $id,
        string $field,
        string $targetLanguage
    ): ?string {
        $cache = self::where('translatable_type', $type)
            ->where('translatable_id', $id)
            ->where('field_name', $field)
            ->where('target_language', $targetLanguage)
            ->first();

        return $cache ? $cache->translated_content : null;
    }

    /**
     * Store translation in cache
     */
    public static function storeTranslation(
        string $type,
        int $id,
        string $field,
        string $originalContent,
        string $translatedContent,
        string $targetLanguage,
        string $sourceLanguage = 'en'
    ): self {
        return self::updateOrCreate(
            [
                'translatable_type' => $type,
                'translatable_id' => $id,
                'field_name' => $field,
                'target_language' => $targetLanguage,
            ],
            [
                'source_language' => $sourceLanguage,
                'original_content' => $originalContent,
                'translated_content' => $translatedContent,
                'translated_at' => now(),
            ]
        );
    }

    /**
     * Clear cache for a specific translatable item
     */
    public static function clearCache(string $type, int $id): bool
    {
        return self::where('translatable_type', $type)
            ->where('translatable_id', $id)
            ->delete() > 0;
    }
}
