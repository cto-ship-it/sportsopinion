<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Foundation\Auth\User as Authenticatable; // Important for authentication
use Illuminate\Notifications\Notifiable;
use Laravel\Sanctum\HasApiTokens; // If you plan to use API authentication
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Str;

class Customer extends Authenticatable
{
    use HasApiTokens, HasFactory, Notifiable;

    /**
     * The attributes that are mass assignable.
     */
    protected $fillable = [
        'name',
        'phone',
        'dob',
        'email',
        'referral_code',
        'referred_by',
        'mpin',
        'points',
        'profile_pic',
    ];

    /**
     * The attributes that should be hidden for serialization.
     */
    protected $hidden = [
        'mpin',
    ];

    protected $casts = [
        'dob' => 'date:Y-m-d',
    ];

    protected $attributes = [
        'points' => 500,
        'status' => 1,
    ];

    public static function generateReferralCode()
    {
        $letters = strtoupper(Str::random(4)); 
        $numbers = rand(1000, 9999);          
        return $letters . $numbers;
    }

    protected static function boot()
    {
        parent::boot();

        static::creating(function ($customer) {
            // Ensure unique code
            do {
                $code = self::generateReferralCode();
            } while (self::where('referral_code', $code)->exists());

            $customer->referral_code = $code;
        });
    }
    /**
     * Automatically hash the MPIN when setting it.
     */
    public function setMpinAttribute($value)
    {
        if (!empty($value)) {
            $this->attributes['mpin'] = Hash::make($value);
        }
    }

    /**
     * Optionally, define a profile picture accessor to return full URL.
     */
    public function getProfilePicAttribute($value)
    {
        if ($value) {
            return asset('storage/' . $value);
        }

        // Default placeholder
        return asset('images/default-profile.png');
    }

    public function address()
    {
        return $this->hasOne(CustomerAddress::class);
    }

    public function customerAnswers()
{
    return $this->hasMany(CustomerAnswer::class, 'customer_id');
}

    public function fcmToken()
    {
        return $this->hasOne(CustomerFcmToken::class, 'customer_id');
    }

    public function redeemRequests()
    {
        return $this->hasMany(CustomerRedeemRequest::class);
    }

    public function notifications()
{
    return $this->hasMany(AppNotification::class, 'customer_id');
}

public function bankDetails()
{
    return $this->hasMany(CustomerBankDetail::class);
}

}
