<?php

namespace App\Services;

use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Str;

class OtpService
{
    protected string $apiUrl = 'http://nimbusit.net/api/pushsms';
    protected string $user;
    protected string $authkey;
    protected string $sender;
    protected string $entityId;
    protected string $templateId;

    public function __construct()
    {
        $this->user       = config('services.nimbus.user');
        $this->authkey    = config('services.nimbus.authkey');
        $this->sender     = config('services.nimbus.sender');
        $this->entityId   = config('services.nimbus.entity_id');
        $this->templateId = config('services.nimbus.template_id');
    }

    /**
     * Generate and send OTP via SMS.
     *
     * @param string $phone
     * @param int $length
     * @param int $ttl Minutes
     * @return string Generated OTP
     * @throws \Exception
     */
    public function sendOtp(string $phone, int $length = 4, int $ttl = 5): string
    {
        // 1. Generate OTP
        $otp = Str::padLeft(random_int(0, pow(10, $length) - 1), $length, '0');

        // 2. Cache OTP
        Cache::put("otp_{$phone}", $otp, now()->addMinutes($ttl));

        // 3. Prepare SMS text
        $message = "Your OTP for verification is {$otp}. Please enter this code to verify your phone number. For more information, visit: https://dailyopinion.in/";

        // 4. Send SMS request
        try {
            $response = Http::timeout(10)->get($this->apiUrl, [
                'user'        => $this->user,
                'authkey'     => $this->authkey,
                'sender'      => $this->sender,
                'mobile'      => $phone,
                'text'        => $message,
                'entityid'    => $this->entityId,
                'templateid'  => $this->templateId,
                'rpt'         => 1,
            ]);

            if ($response->failed()) {
                Log::error("OTP sending failed for {$phone}. Response: " . $response->body());
                throw new \Exception("Failed to send OTP to {$phone}");
            }

            Log::info("OTP sent successfully to {$phone}");
        } catch (\Throwable $e) {
            Log::error("Error sending OTP to {$phone}: {$e->getMessage()}");
            throw new \Exception("Error sending OTP. Please try again later.");
        }

        return $otp;
    }

    /**
     * Verify OTP and delete it if valid.
     */
    public function verifyOtp(string $phone, string $otp): bool
    {
        $cachedOtp = Cache::get("otp_{$phone}");

        if ($cachedOtp && $cachedOtp === $otp) {
            Cache::forget("otp_{$phone}");
            return true;
        }

        return false;
    }
}
