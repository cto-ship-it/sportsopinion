<?php

namespace App\Services;

use App\Models\TranslationCache;
use Stichoza\GoogleTranslate\GoogleTranslate;
use Illuminate\Support\Facades\Log;

class TranslationService
{
    protected $translator;
    protected $cacheEnabled;
    protected $cacheTTL;
    protected $supportedLanguages;

    public function __construct()
    {
        // Create translator with HTTP options to disable SSL verification (Windows fix)
        $httpOptions = [
            'verify' => false, // Disable SSL verification
            'timeout' => 10,
        ];
        
        $this->translator = new GoogleTranslate('en', null, $httpOptions);
        
        $this->cacheEnabled = env('TRANSLATION_CACHE_ENABLED', true);
        $this->cacheTTL = env('TRANSLATION_CACHE_TTL', 2592000); // 30 days
        $this->supportedLanguages = explode(',', env('SUPPORTED_LANGUAGES', 'en,en_GB,de,fr,ru'));
    }

    /**
     * Translate text to target language with caching
     *
     * @param string $text Text to translate
     * @param string $targetLanguage Target language code
     * @param string $sourceLanguage Source language code (default: 'en')
     * @param string|null $translatableType Model type for caching
     * @param int|null $translatableId Model ID for caching
     * @param string|null $fieldName Field name for caching
     * @return string Translated text
     */
    public function translate(
        string $text,
        string $targetLanguage,
        string $sourceLanguage = 'en',
        ?string $translatableType = null,
        ?int $translatableId = null,
        ?string $fieldName = null
    ): string {
        // If target language is same as source, return original text
        if ($this->normalizeLanguageCode($targetLanguage) === $this->normalizeLanguageCode($sourceLanguage)) {
            return $text;
        }

        // Validate target language
        if (!$this->isLanguageSupported($targetLanguage)) {
            Log::warning("Unsupported language requested: {$targetLanguage}. Falling back to original text.");
            return $text;
        }

        // Check cache if caching parameters provided
        if ($this->cacheEnabled && $translatableType && $translatableId && $fieldName) {
            $cached = TranslationCache::getCachedTranslation(
                $translatableType,
                $translatableId,
                $fieldName,
                $targetLanguage
            );

            if ($cached !== null) {
                return $cached;
            }
        }

        try {
            // Perform translation
            $normalizedTarget = $this->normalizeLanguageCode($targetLanguage);
            $this->translator->setSource($sourceLanguage);
            $this->translator->setTarget($normalizedTarget);
            
            $translatedText = $this->translator->translate($text);

            // Cache the translation if parameters provided
            if ($this->cacheEnabled && $translatableType && $translatableId && $fieldName) {
                TranslationCache::storeTranslation(
                    $translatableType,
                    $translatableId,
                    $fieldName,
                    $text,
                    $translatedText,
                    $targetLanguage,
                    $sourceLanguage
                );
            }

            return $translatedText;
        } catch (\Exception $e) {
            Log::error("Translation error: " . $e->getMessage(), [
                'text' => substr($text, 0, 100),
                'target_language' => $targetLanguage,
                'source_language' => $sourceLanguage,
            ]);
            
            // Return original text on error
            return $text;
        }
    }

    /**
     * Translate multiple texts in batch
     *
     * @param array $texts Array of texts to translate
     * @param string $targetLanguage Target language code
     * @param string $sourceLanguage Source language code
     * @return array Translated texts
     */
    public function translateBatch(array $texts, string $targetLanguage, string $sourceLanguage = 'en'): array
    {
        $translatedTexts = [];
        
        foreach ($texts as $key => $text) {
            $translatedTexts[$key] = $this->translate($text, $targetLanguage, $sourceLanguage);
        }

        return $translatedTexts;
    }

    /**
     * Clear translation cache for a specific model
     *
     * @param string $type Model type
     * @param int $id Model ID
     * @return bool
     */
    public function clearCache(string $type, int $id): bool
    {
        return TranslationCache::clearCache($type, $id);
    }

    /**
     * Check if language is supported
     *
     * @param string $languageCode Language code
     * @return bool
     */
    public function isLanguageSupported(string $languageCode): bool
    {
        return in_array($languageCode, $this->supportedLanguages);
    }

    /**
     * Get list of supported languages
     *
     * @return array
     */
    public function getSupportedLanguages(): array
    {
        return $this->supportedLanguages;
    }

    /**
     * Normalize language code for Google Translate
     * en_GB -> en, en_US -> en
     *
     * @param string $languageCode
     * @return string
     */
    private function normalizeLanguageCode(string $languageCode): string
    {
        // For Google Translate API, we use base language codes
        // en_GB and en_US both use 'en'
        $mapping = [
            'en_GB' => 'en',
            'en_US' => 'en',
            'en' => 'en',
            'de' => 'de',
            'fr' => 'fr',
            'ru' => 'ru',
        ];

        return $mapping[$languageCode] ?? $languageCode;
    }

    /**
     * Get language display name
     *
     * @param string $languageCode
     * @return string
     */
    public function getLanguageDisplayName(string $languageCode): string
    {
        $names = [
            'en' => 'English (US)',
            'en_US' => 'English (US)',
            'en_GB' => 'English (UK)',
            'de' => 'Deutsch',
            'fr' => 'Français',
            'ru' => 'Русский',
        ];

        return $names[$languageCode] ?? $languageCode;
    }
}
