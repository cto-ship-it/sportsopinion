<?php

namespace App\Services;

use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\Log;

class EmailOtpService
{
    public function sendOtp(string $email, int $length = 4, int $ttl = 5): string
    {
        // Generate OTP
        $otp = Str::padLeft(random_int(0, pow(10, $length) - 1), $length, '0');

        // Cache OTP
        Cache::put("email_otp_{$email}", $otp, now()->addMinutes($ttl));

        // Send OTP via email
        try {
            Mail::raw("Your OTP for verification is {$otp}. Please enter this code to verify your email address.", function ($message) use ($email) {
                $message->to($email)
                        ->subject('Email Verification OTP');
            });

            Log::info("OTP sent successfully to email: {$email}");
        } catch (\Throwable $e) {
            Log::error("Error sending OTP to {$email}: " . $e->getMessage());
            throw new \Exception("Failed to send OTP to email. Please try again.");
        }

        return $otp;
    }

    public function verifyOtp(string $email, string $otp): bool
    {
        $cachedOtp = Cache::get("email_otp_{$email}");

        if ($cachedOtp && $cachedOtp === $otp) {
            Cache::forget("email_otp_{$email}");
            return true;
        }

        return false;
    }
}
