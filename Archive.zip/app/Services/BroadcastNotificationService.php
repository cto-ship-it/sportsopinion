<?php

namespace App\Services;

use App\Models\AppNotification;
use App\Models\Customer;
use Illuminate\Support\Facades\DB;
use Kreait\Firebase\Factory;
use Kreait\Firebase\Messaging\CloudMessage;
use Kreait\Firebase\Messaging\Notification;
use Illuminate\Support\Facades\Log;

class BroadcastNotificationService
{
    protected $messaging;
    protected $fcmEnabled = false;

    public function __construct()
    {
        try {
            $serviceAccountPath = storage_path('app/sport-opinion-firebase-adminsdk-fbsvc-31dd488e3e.json');
            
            if (file_exists($serviceAccountPath) && is_readable($serviceAccountPath)) {
                $factory = (new Factory)->withServiceAccount($serviceAccountPath);
                $this->messaging = $factory->createMessaging();
                $this->fcmEnabled = true;
            } else {
                Log::warning('Firebase service account file not found or not readable. Push notifications will be disabled.');
            }
        } catch (\Throwable $e) {
            Log::error('Failed to initialize Firebase messaging: ' . $e->getMessage());
            $this->fcmEnabled = false;
        }
    }

    /**
     * Broadcast a notification to all customers.
     *
     * @param array $payload ['title' => '', 'message' => '', 'type' => '', 'data' => []]
     * @return array
     */
    public function send(array $payload)
    {
        // ✅ Step 1: Validate payload
        if (empty($payload['title']) || empty($payload['message'])) {
            return ['status' => false, 'message' => 'Title and message are required'];
        }

        // ✅ Step 2: Fetch all tokens
        $tokens = DB::table('customerfcmtokens')->pluck('token')->toArray();

        if (empty($tokens)) {
            return ['status' => false, 'message' => 'No device tokens found'];
        }

        // ✅ Step 3: Save notification for each customer
        $customers = Customer::pluck('id');
        $insertData = [];
        foreach ($customers as $id) {
            $insertData[] = [
                'customer_id' => $id,
                'title' => $payload['title'],
                'message' => $payload['message'],
                'type' => $payload['type'] ?? null,
                'data' => json_encode($payload['data'] ?? []),
                'created_at' => now(),
                'updated_at' => now(),
            ];
        }
        AppNotification::insert($insertData);

        // ✅ Step 4: Send notifications in batches (FCM limit = 500 tokens per call)
        if ($this->fcmEnabled && $this->messaging) {
            $chunks = array_chunk($tokens, 500);
            $notification = Notification::create($payload['title'], $payload['message']);

            foreach ($chunks as $chunk) {
                $message = CloudMessage::new()
                    ->withNotification($notification)
                    ->withData($payload['data'] ?? []);

                try {
                    $this->messaging->sendMulticast($message, $chunk);
                } catch (\Throwable $e) {
                    Log::error('FCM Broadcast Error: ' . $e->getMessage());
                }
            }
        }

        return ['status' => true, 'message' => 'Broadcast sent successfully' . ($this->fcmEnabled ? '' : ' (Push notifications disabled)')];
    }

    public function sendToSpecificCustomers(array $customerIds, array $payload)
{
    if (empty($payload['title']) || empty($payload['message'])) {
        return ['status' => false, 'message' => 'Title and message are required'];
    }

    if (empty($customerIds)) {
        return ['status' => false, 'message' => 'No customers to notify'];
    }

    // ✅ Fetch tokens only for specific customers
    $tokens = DB::table('customerfcmtokens')
        ->whereIn('customer_id', $customerIds)
        ->pluck('token')
        ->toArray();

    if (empty($tokens)) {
        return ['status' => false, 'message' => 'No tokens found for selected customers'];
    }

    // ✅ Save notification in DB for those customers
    $insertData = [];
    foreach ($customerIds as $id) {
        $insertData[] = [
            'customer_id' => $id,
            'title' => $payload['title'],
            'message' => $payload['message'],
            'type' => $payload['type'] ?? null,
            'data' => json_encode($payload['data'] ?? []),
            'created_at' => now(),
            'updated_at' => now(),
        ];
    }
    AppNotification::insert($insertData);

    // ✅ Send Firebase notifications in batches of 500
    if ($this->fcmEnabled && $this->messaging) {
        $chunks = array_chunk($tokens, 500);
        $notification = Notification::create($payload['title'], $payload['message']);

        foreach ($chunks as $chunk) {
            $message = CloudMessage::new()
                ->withNotification($notification)
                ->withData($payload['data'] ?? []);

            try {
                $this->messaging->sendMulticast($message, $chunk);
            } catch (\Throwable $e) {
                Log::error('FCM Targeted Send Error: ' . $e->getMessage());
            }
        }
    }

    return ['status' => true, 'message' => 'Notifications sent to selected customers' . ($this->fcmEnabled ? '' : ' (Push notifications disabled)')];
}
}
