<?php

namespace App\View\Components;

use Illuminate\View\Component;

class Search extends Component
{
    public $action;
    public $placeholder;

    public function __construct($action = null, $placeholder = 'Search...')
    {
        $this->action = $action;
        $this->placeholder = $placeholder;
    }

    public function render()
    {
        return view('components.search');
    }
}
