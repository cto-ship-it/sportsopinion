<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;
use Illuminate\Support\Facades\App;

class SetLocale
{
    /**
     * Handle an incoming request.
     *
     * @param  \Closure(\Illuminate\Http\Request): (\Symfony\Component\HttpFoundation\Response)  $next
     */
    public function handle(Request $request, Closure $next): Response
    {
        // Priority order for language detection:
        // 1. 'lang' query parameter
        // 2. 'X-Language' header
        // 3. 'Accept-Language' header
        // 4. Default language from config

        $language = $request->query('lang')
            ?? $request->header('X-Language')
            ?? $request->header('Accept-Language')
            ?? config('app.locale', 'en');

        // Clean up language code (take only the first part if it's like 'en-US,en;q=0.9')
        if (strpos($language, ',') !== false) {
            $language = explode(',', $language)[0];
        }
        if (strpos($language, ';') !== false) {
            $language = explode(';', $language)[0];
        }

        // Normalize language code
        $language = str_replace('-', '_', trim($language));

        // Validate against supported languages
        $supportedLanguages = explode(',', env('SUPPORTED_LANGUAGES', 'en,en_GB,de,fr,ru'));
        
        if (!in_array($language, $supportedLanguages)) {
            $language = config('app.locale', 'en');
        }

        // Set application locale
        App::setLocale($language);

        // Store language in request for controllers to access
        $request->attributes->set('language', $language);

        return $next($request);
    }
}
