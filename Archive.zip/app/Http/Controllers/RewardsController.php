<?php

namespace App\Http\Controllers;

use App\Models\Rewards;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;

class RewardsController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index(Request $request)
{
    $query = Rewards::query()->orderBy('id', 'desc');

    if ($request->filled('search')) {
        $search = $request->search;
        $query->where('name', 'like', "%{$search}%");
    }

    $rewards = $query->paginate(20);

    return view('admin.rewards', compact('rewards'));
}

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        $validated = $request->validate([
            'image' => 'required|image|mimes:jpg,jpeg,png',
            'name' => 'required|string|max:255',
            'description' => 'required|string',
            'points' => 'required|integer|min:0',
            'date' => 'required|date',
            'status' => 'required|in:active,inactive',
        ]);

        // Store image
        $path = $request->file('image')->store('rewards', 'public');

        // Create reward
        Rewards::create([
            'image' => $path,
            'name' => $validated['name'],
            'description' => $validated['description'],
            'points' => $validated['points'],
            'expiry_date' => $validated['date'],
            'status' => $validated['status'],
        ]);

        return redirect()->back()->with('success', 'Reward added successfully!');
    }


    /**
     * Display the specified resource.
     */
    public function show(Rewards $rewards)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(Rewards $rewards)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, Rewards $reward)
    {
        // dd($request->all());
        $validated = $request->validate([
            'image' => 'nullable|image|mimes:jpg,jpeg,png',
            'name' => 'required|string|max:255',
            'description' => 'required|string',
            'points' => 'required|integer|min:0',
            'date' => 'required|date',
            'status' => 'required|in:active,inactive',
        ]);

        if ($request->hasFile('image')) {
            if ($reward->image && Storage::disk('public')->exists($reward->image)) {
                Storage::disk('public')->delete($reward->image);
            }
            $validated['image'] = $request->file('image')->store('rewards', 'public');
        }

        $reward->update($validated);

        return redirect()->back()->with('success', 'Reward updated successfully!');
    }


    /**
     * Remove the specified resource from storage.
     */
    public function destroy(Rewards $reward)
    {
        if ($reward->image && Storage::disk('public')->exists($reward->image)) {
            Storage::disk('public')->delete($reward->image);
        }

        $reward->delete();

        return redirect()->back()->with('success', 'Reward deleted successfully!');
    }

}
