<?php

namespace App\Http\Controllers;

use App\Models\Customer;
use App\Models\Point;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Schema;

class PointController extends Controller
{
    /**
     * Display a listing of the resource.
     */
public function index(Request $request)
{
    $query = Customer::select('id', 'name', 'phone', 'profile_pic', 'created_at', 'points');

    if ($request->filled('search')) {
        $search = $request->search;

        // Columns you want to search across
        $searchableColumns = ['name', 'phone', 'email', 'referral_code'];

        $query->where(function ($q) use ($searchableColumns, $search) {
            foreach ($searchableColumns as $column) {
                $q->orWhere($column, 'like', "%{$search}%");
            }
        });
    }

    $users = $query->latest()->paginate(20);

    return view('admin.points', compact('users'));
}


    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     */
    public function show(Point $point)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(Point $point)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, Point $point)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(Point $point)
    {
        //
    }
}
