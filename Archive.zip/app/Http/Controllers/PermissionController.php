<?php

namespace App\Http\Controllers;

use App\Models\User;
use Illuminate\Http\Request;

class PermissionController extends Controller
{
    public function index()
    {
        $admins = User::where('role', 'admin')->paginate(10);
        $allPermissions = config('permissions');

        return view('admin.permission', compact('admins', 'allPermissions'));
    }

    public function edit($id)
    {
        $user = User::findOrFail($id);
        $allPermissions = config('permissions');

        return response()->json([
            'user' => $user,
            'permissions' => $user->permissions ?? [],
            'allPermissions' => $allPermissions
        ]);
    }

    public function update(Request $request, $id)
    {
        $user = User::findOrFail($id);

        $user->update([
            'permissions' => $request->permissions ?? []
        ]);

        return back()->with('success', 'Permissions updated successfully.');
    }
}
