<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Category;
use App\Models\Question;
use App\Services\TranslationService;
use Illuminate\Http\Request;

class QuestionController extends Controller
{
    protected $translationService;

    public function __construct(TranslationService $translationService)
    {
        $this->translationService = $translationService;
    }

    public function getBySubcategory(Request $request, $id)
{
    $customer = $request->user();
    $language = $request->attributes->get('language', 'en');

    // Debug logging
    \Log::info('QuestionController - Language detected', [
        'language' => $language,
        'X-Language header' => $request->header('X-Language'),
        'Accept-Language header' => $request->header('Accept-Language'),
        'App locale' => app()->getLocale(),
    ]);

    $answeredQuestionIds = \App\Models\CustomerAnswer::where('customer_id', $customer->id)
        ->pluck('question_id')
        ->toArray();

    $questions = \App\Models\Question::where('subcategory_id', $id)
        ->whereNotIn('id', $answeredQuestionIds)
        ->where(function ($query) {
            $query->whereNull('expiry_date') 
                  ->orWhere('expiry_date', '>', now());
        })
        ->where(function ($query) {
            $query->whereNull('publish_at')
                  ->orWhere('publish_at', '<=', now());
        })
        ->select('id', 'category_id', 'subcategory_id', 'question', 'options', 'points', 'banner_link', 'banner_image', 'answer_status', 'created_at', 'expiry_date', 'attempt_point')
        ->orderBy('created_at', 'desc')
        ->get();

    $questions->transform(function ($q) use ($language) {
        try {
            // Translate question text
            if ($q->question && $language !== 'en') {
                $q->question = $this->translationService->translate(
                    $q->question,
                    $language,
                    'en',
                    'App\Models\Question',
                    $q->id,
                    'question'
                );
            }

            // Translate options if they exist
            if ($q->options && $language !== 'en') {
                // Check if options is already an array or needs decoding
                $options = is_array($q->options) ? $q->options : json_decode($q->options, true);
                if (is_array($options)) {
                    foreach ($options as $key => $option) {
                        $options[$key] = $this->translationService->translate(
                            $option,
                            $language,
                            'en',
                            'App\Models\Question',
                            $q->id,
                            "option_{$key}"
                        );
                    }
                    // Keep it as array since Laravel will handle JSON conversion
                    $q->options = $options;
                }
            }
        } catch (\Exception $e) {
            \Log::error("Question translation error: " . $e->getMessage());
            // Keep original text if translation fails
        }

        // Handle banner image
        if ($q->banner_image) {
            $q->banner_image = asset('storage/' . $q->banner_image);
        }

        return $q;
    });

    return response()->json([
        'status' => true,
        'data' => $questions,
        'language' => $language,
    ]);
}

}
