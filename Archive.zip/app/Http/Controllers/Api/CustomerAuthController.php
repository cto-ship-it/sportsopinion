<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Customer;
use Illuminate\Support\Facades\Validator;
use App\Services\OtpService;
use App\Services\EmailOtpService;
use Illuminate\Support\Facades\Cache;

class CustomerAuthController extends Controller
{
    
protected $otpService;
protected $emailOtpService;

public function __construct(EmailOtpService $emailOtpService)
{
    $this->emailOtpService = $emailOtpService;
    // SMS service is optional - only create if config exists
    if (config('services.nimbus.user')) {
        $this->otpService = app(OtpService::class);
    }
}
    /**
     * Handle customer signup (registration).
     */
    public function signup(Request $request)
    {
        $request->validate([
            'phone' => 'nullable|string|unique:customers,phone',
            'email' => 'nullable|email|unique:customers,email',
            'name'  => 'required|string|max:255',
            'otp'   => 'nullable|string',
            'mpin'  => 'nullable|string|min:4|max:4',
            'referral_code' => 'nullable|string|exists:customers,referral_code',
        ]);

        // Ensure either phone or email is provided
        if (!$request->phone && !$request->email) {
            return response()->json([
                'status' => false,
                'message' => 'Either phone or email is required for signup.'
            ], 422);
        }

        $contact = $request->phone ?? $request->email;
        $isPhone = isset($request->phone);
        $name = $request->name;

        /**
         * Step 1: Send OTP
         */
        if (!$request->otp && !$request->mpin) {
            if ($isPhone) {
                if (!$this->otpService) {
                    return response()->json([
                        'status' => false,
                        'message' => 'SMS service is not configured. Please use email signup.'
                    ], 503);
                }
                $otp = $this->otpService->sendOtp($request->phone);
            } else {
                $otp = $this->emailOtpService->sendOtp($request->email);
            }

            Cache::put('signup_' . $contact, [
                'name' => $name,
                'referral_code' => $request->referral_code ?? null,
            ], now()->addMinutes(5));

            return response()->json([
                'status' => true,
                'message' => 'OTP sent successfully. Please verify to continue.',
            ], 200);
        }

        /**
         * Step 2: Verify OTP
         */
        if ($request->otp && !$request->mpin) {
            $verified = $isPhone
                ? $this->otpService->verifyOtp($request->phone, $request->otp)
                : $this->emailOtpService->verifyOtp($request->email, $request->otp);

            if (!$verified) {
                return response()->json([
                    'status' => false,
                    'message' => 'Invalid OTP. Please try again.'
                ], 422);
            }

            Cache::put('otp_verified_' . $contact, true, now()->addMinutes(10));

            return response()->json([
                'status' => true,
                'message' => 'OTP verified. Now set your MPIN to complete signup.'
            ], 200);
        }

        /**
         * Step 3: Complete Signup
         */
        if ($request->mpin) {
            $verified = Cache::get('otp_verified_' . $contact);

            if (!$verified) {
                return response()->json([
                    'status' => false,
                    'message' => 'OTP not verified. Please verify OTP first.'
                ], 403);
            }

            $cachedUser = Cache::get('signup_' . $contact);

            if (!$cachedUser) {
                return response()->json([
                    'status' => false,
                    'message' => 'Session expired. Please restart signup.'
                ], 410);
            }

            $customer = Customer::create([
                'name'  => $cachedUser['name'],
                'phone' => $request->phone,
                'email' => $request->email,
                'mpin'  => $request->mpin,
                'referred_by' => $cachedUser['referral_code'] ?? null,
            ]);

            // Referral points
            if (!empty($cachedUser['referral_code'])) {
                $referrer = Customer::where('referral_code', $cachedUser['referral_code'])->first();
                if ($referrer) {
                    $referrer->increment('points', 50);
                }
            }

            // Cleanup cache
            Cache::forget('otp_verified_' . $contact);
            Cache::forget('signup_' . $contact);

            // Create token
            $token = $customer->createToken('CustomerAuthToken')->plainTextToken;

            return response()->json([
                'status'  => true,
                'message' => 'Signup complete',
                'data'    => [
                    'customer' => $customer,
                    'token'    => $token
                ]
            ], 201);
        }

        return response()->json([
            'status'  => false,
            'message' => 'Invalid request sequence.'
        ], 400);
    }



        /**
     * Handle customer login.
     */
    public function login(Request $request)
{
    // Step 1: Validate input dynamically
    $validator = Validator::make($request->all(), [
        'phone' => 'nullable|string|exists:customers,phone',
        'email' => 'nullable|email|exists:customers,email',
        'mpin'  => 'required|string|min:4|max:6',
    ]);

    if ($validator->fails()) {
        return response()->json([
            'status'  => false,
            'message' => 'Validation errors',
            'errors'  => $validator->errors(),
        ], 422);
    }

    // Step 2: Ensure at least one identifier is present
    if (!$request->phone && !$request->email) {
        return response()->json([
            'status' => false,
            'message' => 'Either phone or email is required for login.',
        ], 422);
    }

    // Step 3: Retrieve customer
    $customer = $request->phone
        ? Customer::where('phone', $request->phone)->first()
        : Customer::where('email', $request->email)->first();

    // Step 4: Check MPIN
    if (!$customer || !\Illuminate\Support\Facades\Hash::check($request->mpin, $customer->mpin)) {
        return response()->json([
            'status'  => false,
            'message' => 'Invalid credentials.',
        ], 401);
    }

    // Step 5: Generate new Sanctum token
    $token = $customer->createToken('CustomerAuthToken')->plainTextToken;

    // Step 6: Return success response
    return response()->json([
        'status'  => true,
        'message' => 'Login successful.',
        'data'    => [
            'customer' => $customer,
            'token'    => $token,
        ],
    ], 200);
}


    /**
 * Handle customer logout.
 */
public function logout(Request $request)
{
    // Get the authenticated customer
    $customer = $request->user();

    if (!$customer) {
        return response()->json([
            'status'  => false,
            'message' => 'Not authenticated',
        ], 401);
    }

    // Revoke the current access token
    $customer->currentAccessToken()->delete();

    return response()->json([
        'status'  => true,
        'message' => 'Logout successful',
    ]);
}

/**
 * Get authenticated customer profile.
 */
public function profile(Request $request)
{
    // Get the authenticated customer and load addresses
    $customer = $request->user()->load('address');

    if (!$customer) {
        return response()->json([
            'status'  => false,
            'message' => 'Not authenticated',
        ], 401);
    }

    return response()->json([
        'status'  => true,
        'message' => 'Customer profile fetched successfully',
        'data'    => $customer,
    ]);
}

public function updateProfile(Request $request)
{
    $customer = $request->user();

    if (!$customer) {
        return response()->json([
            'status' => false,
            'message' => 'Not authenticated',
        ], 401);
    }

    // dd($request->all());
    // Validate input
    $request->validate([
        'name'        => 'sometimes|required|string|max:255',
        'email'       => 'sometimes|nullable|email|unique:customers,email,' . $customer->id,
        'profile_pic' => 'sometimes|nullable|image|mimes:jpeg,png,jpg,gif',
        'dob'         => 'sometimes|nullable|date|before:today',
        'state'       => 'sometimes|required|string',
        'district'    => 'sometimes|required|string',
        'city'        => 'sometimes|required|string',
        'pincode'     => 'sometimes|required|string',
        'address'     => 'sometimes|required|string',
    ]);

    if ($request->has('name')) $customer->name = $request->name;
    if ($request->has('email')) $customer->email = $request->email;
    if ($request->has('dob')) $customer->dob = $request->dob;

    // Profile picture
    if ($request->hasFile('profile_pic')) {
        $file = $request->file('profile_pic');
        $filename = time() . '_' . $file->getClientOriginalName();
        $file->storeAs('public/customers', $filename);
        $customer->profile_pic = 'customers/' . $filename;
    }

    $customer->save();

    $addressData = $request->only(['state', 'district', 'city', 'pincode', 'address']);

    if (!empty(array_filter($addressData))) { 
        $address = $customer->address;
        if ($address) {
            $address->update($addressData);
        } else {
            $customer->address()->create($addressData);
        }
    }

    $customer->load('address');

    return response()->json([
        'status'  => true,
        'message' => 'Profile updated successfully',
        'data'    => $customer,
    ]);
}


public function forgotMpin(Request $request)
{
    $request->validate([
        'phone' => 'required|string|exists:customers,phone',
        'otp'   => 'nullable|string',
        'mpin'  => 'nullable|string|min:4|max:4',
    ]);

    $phone = $request->phone;

    /**
     * STEP 1: Send OTP
     */
    if (!$request->otp && !$request->mpin) {
        $otp = $this->otpService->sendOtp($phone);

        return response()->json([
            'status'  => true,
            'step'    => 'otp_sent',
            'message' => 'OTP sent to your phone. Please verify to reset MPIN.',
            'otp'     => $otp, // for local testing only; remove in production
        ]);
    }

    /**
     * STEP 2: Verify OTP
     */
    if ($request->otp && !$request->mpin) {
        if (!$this->otpService->verifyOtp($phone, $request->otp)) {
            return response()->json([
                'status'  => false,
                'step'    => 'otp_verification_failed',
                'message' => 'Invalid or expired OTP.',
            ], 422);
        }

        // Store a verified flag for 10 minutes
        Cache::put('otp_verified_'.$phone, true, now()->addMinutes(10));

        return response()->json([
            'status'  => true,
            'step'    => 'otp_verified',
            'message' => 'OTP verified successfully. Now send your new MPIN to reset it.',
        ]);
    }

    /**
     * STEP 3: Update MPIN
     */
    if ($request->mpin && !$request->otp) {
        $verified = Cache::get('otp_verified_'.$phone);

        if (!$verified) {
            return response()->json([
                'status'  => false,
                'step'    => 'unauthorized',
                'message' => 'OTP verification required before resetting MPIN.',
            ], 403);
        }

        $customer = Customer::where('phone', $phone)->first();

        if (!$customer) {
            return response()->json([
                'status'  => false,
                'message' => 'Customer not found.',
            ], 404);
        }

        $customer->mpin = $request->mpin; // auto-hashed via model mutator
        $customer->save();

        // Remove the verification flag after success
        Cache::forget('otp_verified_'.$phone);

        return response()->json([
            'status'  => true,
            'step'    => 'mpin_updated',
            'message' => 'MPIN has been reset successfully.',
        ]);
    }

    return response()->json([
        'status'  => false,
        'message' => 'Invalid request. Please follow the correct steps.',
    ], 400);
}


}
