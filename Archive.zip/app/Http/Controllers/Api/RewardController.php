<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Reward;
use App\Models\Rewards;
use Carbon\Carbon;
use Illuminate\Http\Request;

class RewardController extends Controller
{
    public function index()
    {
        $today = Carbon::today();

        // Fetch active and non-expired rewards
        $rewards = Rewards::where('status', 'active')
            ->where(function ($query) use ($today) {
                $query->whereNull('expiry_date')
                      ->orWhere('expiry_date', '>=', $today);
            })
            ->orderBy('expiry_date', 'asc')
            ->get();

        return response()->json([
            'status' => true,
            'data' => $rewards,
        ]);
    }
}
