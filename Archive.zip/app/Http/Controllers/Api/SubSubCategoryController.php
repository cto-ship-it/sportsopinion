<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\SubSubCategory;
use App\Services\TranslationService;
use Illuminate\Http\Request;

class SubSubCategoryController extends Controller
{
    protected $translationService;

    public function __construct(TranslationService $translationService)
    {
        $this->translationService = $translationService;
    }

    public function index(Request $request, $id)
    {
        try {
            $language = $request->attributes->get('language', 'en');
            $subsubcategories = SubSubCategory::where('subcategory_id', $id)
                ->where('status', 1)
                ->get();

            // Translate subsubcategory names if not English
            if ($language !== 'en') {
                $subsubcategories->transform(function ($subsubcategory) use ($language) {
                    try {
                        $subsubcategory->name = $this->translationService->translate(
                            $subsubcategory->name,
                            $language,
                            'en',
                            'App\Models\SubSubCategory',
                            $subsubcategory->id,
                            'name'
                        );
                        
                        if ($subsubcategory->description) {
                            $subsubcategory->description = $this->translationService->translate(
                                $subsubcategory->description,
                                $language,
                                'en',
                                'App\Models\SubSubCategory',
                                $subsubcategory->id,
                                'description'
                            );
                        }
                    } catch (\Exception $e) {
                        // Keep original text if translation fails
                         \Log::error("SubSubCategory translation error: " . $e->getMessage());
                    }
                    
                    return $subsubcategory;
                });
            }

            return response([
                'success' => true,
                'data' => $subsubcategories,
                'language' => $language
            ], 200);
        } catch (\Exception $e) {
            \Log::error("SubSubCategory index error: " . $e->getMessage());
            return response([
                'success' => false,
                'message' => 'Failed to load sub subcategories',
                'error' => $e->getMessage()
            ], 500);
        }
    }
}
