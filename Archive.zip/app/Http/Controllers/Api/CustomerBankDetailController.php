<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\CustomerBankDetail;
use Illuminate\Http\Request;

class CustomerBankDetailController extends Controller
{
    /**
     * Display a list of authenticated customer's bank details.
     */
    public function index(Request $request)
    {
        $customer = $request->user();

        $bankDetails = CustomerBankDetail::where('customer_id', $customer->id)->get();

        return response()->json([
            'status'  => true,
            'message' => 'Bank details fetched successfully',
            'data'    => $bankDetails,
        ]);
    }

    /**
     * Store a new bank detail for authenticated customer.
     */
    public function store(Request $request)
    {
        $validated = $request->validate([
            'account_holder_name' => 'required|string|max:255',
            'ifsc'                => 'required|string|max:20',
            'account_no'          => 'required|string|max:30',
        ]);

        $bankDetail = CustomerBankDetail::create([
            'customer_id'         => $request->user()->id,
            'account_holder_name' => $validated['account_holder_name'],
            'ifsc'                => $validated['ifsc'],
            'account_no'          => $validated['account_no'],
        ]);

        return response()->json([
            'status'  => true,
            'message' => 'Bank detail added successfully',
            'data'    => $bankDetail,
        ], 201);
    }

    /**
     * Show a single bank detail (only if belongs to authenticated user).
     */
    public function show(Request $request, $id)
    {
        $bankDetail = CustomerBankDetail::where('customer_id', $request->user()->id)
            ->where('id', $id)
            ->first();

        if (!$bankDetail) {
            return response()->json([
                'status'  => false,
                'message' => 'Bank detail not found',
            ], 404);
        }

        return response()->json([
            'status'  => true,
            'message' => 'Bank detail fetched successfully',
            'data'    => $bankDetail,
        ]);
    }

    /**
     * Update customer's bank detail.
     */
    public function update(Request $request, $id)
    {
        $bankDetail = CustomerBankDetail::where('customer_id', $request->user()->id)
            ->where('id', $id)
            ->first();

        if (!$bankDetail) {
            return response()->json([
                'status'  => false,
                'message' => 'Bank detail not found',
            ], 404);
        }

        $validated = $request->validate([
            'account_holder_name' => 'sometimes|required|string|max:255',
            'ifsc'                => 'sometimes|required|string|max:20',
            'account_no'          => 'sometimes|required|string|max:30',
        ]);

        $bankDetail->update($validated);

        return response()->json([
            'status'  => true,
            'message' => 'Bank detail updated successfully',
            'data'    => $bankDetail,
        ]);
    }

    /**
     * Delete customer's bank detail.
     */
    public function destroy(Request $request, $id)
    {
        $bankDetail = CustomerBankDetail::where('customer_id', $request->user()->id)
            ->where('id', $id)
            ->first();

        if (!$bankDetail) {
            return response()->json([
                'status'  => false,
                'message' => 'Bank detail not found',
            ], 404);
        }

        $bankDetail->delete();

        return response()->json([
            'status'  => true,
            'message' => 'Bank detail deleted successfully',
        ]);
    }
}
