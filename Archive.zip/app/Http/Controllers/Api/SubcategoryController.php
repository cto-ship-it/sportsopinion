<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\SubCategory;
use App\Services\TranslationService;
use Illuminate\Http\Request;

class SubcategoryController extends Controller
{
    protected $translationService;

    public function __construct(TranslationService $translationService)
    {
        $this->translationService = $translationService;
    }

    public function index(Request $request, $id)
    {
        try {
            $language = $request->attributes->get('language', 'en');
            $subcategories = SubCategory::where('category_id', $id)
                ->where('status', 1)
                ->get();

            // Translate subcategory names if not English
            if ($language !== 'en') {
                $subcategories->transform(function ($subcategory) use ($language) {
                    try {
                        $subcategory->name = $this->translationService->translate(
                            $subcategory->name,
                            $language,
                            'en',
                            'App\Models\SubCategory',
                            $subcategory->id,
                            'name'
                        );
                        
                        if ($subcategory->description) {
                            $subcategory->description = $this->translationService->translate(
                                $subcategory->description,
                                $language,
                                'en',
                                'App\Models\SubCategory',
                                $subcategory->id,
                                'description'
                            );
                        }
                    } catch (\Exception $e) {
                        \Log::error("Subcategory translation error: " . $e->getMessage());
                        // Keep original text if translation fails
                    }
                    
                    return $subcategory;
                });
            }

            return response([
                'success' => true,
                'data' => $subcategories,
                'language' => $language
            ], 200);
        } catch (\Exception $e) {
            \Log::error("Subcategory index error: " . $e->getMessage());
            return response([
                'success' => false,
                'message' => 'Failed to load subcategories',
                'error' => $e->getMessage()
            ], 500);
        }
    }
}
