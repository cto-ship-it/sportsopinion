<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Banner;
use Illuminate\Http\Request;
use Carbon\Carbon;

class BannerController extends Controller
{
    
public function index()
{
    $today = Carbon::today();

    $banners = Banner::where('status', 'active')
                     ->where(function($query) use ($today) {
                         $query->whereNull('expiry_date')
                               ->orWhere('expiry_date', '>=', $today);
                     })
                     ->orderBy('created_at', 'desc')
                     ->get()
                     ->map(function($banner) {
                         return [
                             'id' => $banner->id,
                             'location' => $banner->location,
                             'link' => $banner->link,
                             'expiry_date' => $banner->expiry_date,
                             'image' => asset('storage/' . $banner->image), // full URL
                             'created_at' => $banner->created_at->toDateString(),
                         ];
                     });

    return response()->json($banners);
}

}
