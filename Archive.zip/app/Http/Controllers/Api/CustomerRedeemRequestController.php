<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Customer;
use App\Models\CustomerRedeemRequest;
use App\Models\Rewards;
use Illuminate\Http\Request;

class CustomerRedeemRequestController extends Controller
{
    public function store(Request $request, Rewards $reward)
    {
        $customer = $request->user();

        $pointsRequired = $reward->points;
        // dd($pointsRequired);
        if ($customer->points < $pointsRequired) {
            return response()->json([
                'success' => false,
                'message' => 'Insufficient points to redeem this reward.'
            ], 400);
        }

        $redeemRequest = CustomerRedeemRequest::create([
            'customer_id' => $customer->id,
            'reward_id' => $reward->id,
            'points' => $pointsRequired,
            'status' => 'pending',
        ]);

        $customer->decrement('points', $pointsRequired);

        return response()->json([
            'success' => true,
            'message' => 'Redeem request submitted successfully.',
            'data' => $redeemRequest
        ]);
    }
}
