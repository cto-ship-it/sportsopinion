<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Services\TranslationService;
use Illuminate\Http\Request;

class LanguageController extends Controller
{
    protected $translationService;

    public function __construct(TranslationService $translationService)
    {
        $this->translationService = $translationService;
    }

    /**
     * Get list of supported languages
     */
    public function getSupportedLanguages()
    {
        $languages = [
            [
                'code' => 'en',
                'name' => 'English (US)',
                'native_name' => 'English (US)',
                'flag' => '🇺🇸',
            ],
            [
                'code' => 'en_GB',
                'name' => 'English (UK)',
                'native_name' => 'English (UK)',
                'flag' => '🇬🇧',
            ],
            [
                'code' => 'de',
                'name' => 'German',
                'native_name' => 'Deutsch',
                'flag' => '🇩🇪',
            ],
            [
                'code' => 'fr',
                'name' => 'French',
                'native_name' => 'Français',
                'flag' => '🇫🇷',
            ],
            [
                'code' => 'ru',
                'name' => 'Russian',
                'native_name' => 'Русский',
                'flag' => '🇷🇺',
            ],
        ];

        return response()->json([
            'status' => true,
            'data' => $languages,
            'default' => 'en',
        ]);
    }

    /**
     * Get current language
     */
    public function getCurrentLanguage(Request $request)
    {
        $language = $request->attributes->get('language', 'en');

        return response()->json([
            'status' => true,
            'data' => [
                'current_language' => $language,
                'display_name' => $this->translationService->getLanguageDisplayName($language),
            ],
        ]);
    }
}
