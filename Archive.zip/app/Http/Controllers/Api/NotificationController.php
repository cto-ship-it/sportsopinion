<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\AppNotification;
use App\Models\Customerfcmtoken;
use Illuminate\Http\Request;

class NotificationController extends Controller
{
    public function storeOrUpdate(Request $request)
{
    $customer = $request->user(); 
    if (!$customer) {
        return response()->json([
            'status' => 'error',
            'message' => 'Not authenticated'
        ], 401);
    }

    $validated = $request->validate([
        'token' => 'required|string|max:255',
    ]);

    Customerfcmtoken::updateOrCreate(
        ['customer_id' => $customer->id], // Match condition
        ['token' => $validated['token']]  // Values to set
    );

    return response()->json([
        'status' => 'success',
        'message' => 'FCM token saved successfully',
    ]);
}

    public function index(Request $request)
    {
        $customer = $request->user();

        $notifications = AppNotification::where('customer_id', $customer->id)
            ->orderBy('created_at', 'desc')
            ->paginate(20); // adjust page size as needed

        return response()->json([
            'status' => true,
            'data' => $notifications
        ]);
    }

    public function markAsRead(Request $request)
{
    $customer = $request->user();

    $validated = $request->validate([
        'ids' => 'required|array',
        'ids.*' => 'integer|exists:app_notifications,id'
    ]);

    $updatedCount = AppNotification::where('customer_id', $customer->id)
        ->whereIn('id', $validated['ids'])
        ->update([
            'is_read' => true,
            'read_at' => now()
        ]);

    return response()->json([
        'status' => true,
        'message' => $updatedCount > 1 
            ? "$updatedCount notifications marked as read"
            : "Notification marked as read",
        'updated_count' => $updatedCount
    ]);
}

public function unreadCount(Request $request)
{
    $customer = $request->user();

    if (!$customer) {
        return response()->json([
            'status' => false,
            'message' => 'Not authenticated',
        ], 401);
    }

    $count = AppNotification::where('customer_id', $customer->id)
        ->where('is_read', false)
        ->count();

    return response()->json([
        'status' => true,
        'unread_count' => $count,
    ]);
}

}
