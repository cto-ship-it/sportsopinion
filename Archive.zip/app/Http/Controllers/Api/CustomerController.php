<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Customer;
use App\Models\CustomerAnswer;
use App\Models\CustomerRedeemRequest;
use App\Models\Question;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class CustomerController extends Controller
{

public function index(Request $request)
{
    $customerId = $request->user()->id;
    $perPage = $request->input('per_page', 10);

    // ---- 1️⃣ Fetch Customer Answers ----
    $answersQuery = CustomerAnswer::with(['question.category', 'question.subcategory'])
        ->where('customer_id', $customerId)
        ->orderByDesc('created_at');

    $answers = $answersQuery->get()->map(function ($answer) {
        $question = $answer->question;

        return [
            'question'         => optional($question)->question,
            'category_name'    => optional($question->category)->name,
            'subcategory_name' => optional($question->subcategory)->name,
            'selected_option'  => $answer->selected_option,
            'points_awarded'   => $answer->points_awarded ?? 0,
            'is_correct'       => $answer->is_correct,
            'created_at'       => $answer->created_at,
        ];
    });

    // ---- 2️⃣ Fetch Redeem Request History ----
    $redeemRequests = CustomerRedeemRequest::with('reward')
        ->where('customer_id', $customerId)
        ->orderByDesc('created_at')
        ->get()
        ->map(function ($redeem) {
            return [
                'reward_name'  => optional($redeem->reward)->name,
                'points'       => $redeem->points,
                'status'       => $redeem->status,
                'remarks'      => $redeem->remarks,
                'approved_at'  => $redeem->approved_at,
                'created_at'   => $redeem->created_at,
            ];
        });

    // ---- 3️⃣ Return both in one payload ----
    return response()->json([
        'status' => true,
        'data' => [
            'answers' => $answers,
            'redeem_requests' => $redeemRequests,
        ],
    ]);
}

    public function store(Request $request)
{
    $customer = $request->user();

    if (!$customer) {
        return response()->json([
            'status' => 'error',
            'message' => 'Not authenticated'
        ], 401);
    }

    // Validate input
    $validated = $request->validate([
        'question_id' => 'required|exists:questions,id',
        'answer' => 'required|string|max:1000',
    ]);

    // Check if already answered
    $existing = CustomerAnswer::where('customer_id', $customer->id)
        ->where('question_id', $validated['question_id'])
        ->first();

    if ($existing) {
        return response()->json([
            'status' => 'error',
            'message' => 'You have already submitted an answer for this question.'
        ], 400);
    }

    // Fetch the question and its attempt point
    $question = Question::find($validated['question_id']);
    $attemptPoint = $question->attempt_point ?? 0; // default 0 if null

    // Check if the customer has enough points
    if ($attemptPoint > 0 && $customer->points < $attemptPoint) {
        return response()->json([
            'status' => 'error',
            'message' => 'Insufficient points to attempt this question.'
        ], 400);
    }

    // Use DB transaction to keep data consistent
    DB::beginTransaction();
    try {
        // Deduct attempt points if applicable
        if ($attemptPoint > 0) {
            $customer->points -= $attemptPoint;
            $customer->save();
        }

        // Store customer’s answer
        $customerAnswer = CustomerAnswer::create([
            'customer_id' => $customer->id,
            'question_id' => $question->id,
            'selected_option' => $validated['answer'],
            'points_awarded' => 0, // default until reviewed
            'is_correct' => null, // will be set when admin declares answer
        ]);

        DB::commit();

        return response()->json([
            'status' => 'success',
            'message' => 'Answer submitted successfully!',
            'data' => [
                'answer' => $customerAnswer,
                'attempt_point_deducted' => $attemptPoint,
                'remaining_points' => $customer->points,
            ]
        ]);
    } catch (\Exception $e) {
        DB::rollBack();

        return response()->json([
            'status' => 'error',
            'message' => 'Failed to submit answer. Please try again.',
            'error' => $e->getMessage()
        ], 500);
    }
}


    public function topCustomers(Request $request)
{
    $topCustomers = Customer::orderByDesc('points')
                            ->take(10)
                            ->get(['id', 'name', 'email', 'points', 'profile_pic']);

    return response()->json([
        'success' => true,
        'data' => $topCustomers,
    ]);
}

}
