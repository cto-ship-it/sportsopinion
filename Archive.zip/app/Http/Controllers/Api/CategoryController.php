<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Category;
use App\Services\TranslationService;
use Illuminate\Http\Request;

class CategoryController extends Controller
{
    protected $translationService;

    public function __construct(TranslationService $translationService)
    {
        $this->translationService = $translationService;
    }

    public function index(Request $request)
    {
        try {
            $language = $request->attributes->get('language', 'en');
            $categories = Category::all();

            // Translate category names if not English
            if ($language !== 'en') {
                $categories->transform(function ($category) use ($language) {
                    try {
                        $category->name = $this->translationService->translate(
                            $category->name,
                            $language,
                            'en',
                            'App\Models\Category',
                            $category->id,
                            'name'
                        );
                        
                        if ($category->description) {
                            $category->description = $this->translationService->translate(
                                $category->description,
                                $language,
                                'en',
                                'App\Models\Category',
                                $category->id,
                                'description'
                            );
                        }
                    } catch (\Exception $e) {
                        \Log::error("Category translation error: " . $e->getMessage());
                        // Keep original text if translation fails
                    }
                    
                    return $category;
                });
            }

            return response([
                'success' => true,
                'data' => $categories,
                'language' => $language
            ], 200);
        } catch (\Exception $e) {
            \Log::error("Category index error: " . $e->getMessage());
            return response([
                'success' => false,
                'message' => 'Failed to load categories',
                'error' => $e->getMessage()
            ], 500);
        }
    }
}
