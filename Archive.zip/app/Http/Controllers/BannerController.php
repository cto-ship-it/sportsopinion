<?php

namespace App\Http\Controllers;

use App\Models\Banner;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;

class BannerController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        $banners = Banner::orderBy('created_at', 'desc')->get();
        return view('admin.banner',compact('banners'));
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        // dd($request->all());
        $validated = $request->validate([
            'location' => 'required|string',
            'image' => 'required|image|mimes:jpeg,png,jpg,webp|max:2048',
            'link' => 'nullable|url',
            'expiry_date' => 'nullable|date',
            'status' => 'required|in:active,inactive',
        ]);

        // Store image
        $imagePath = $request->file('image')->store('banners', 'public');

        // Save to DB
        Banner::create([
            'location' => $validated['location'],
            'image' => $imagePath,
            'link' => $validated['link'] ?? null,
            'expiry_date' => $validated['expiry_date'] ?? null,
            'status' => $validated['status'],
        ]);

        return redirect()->back()->with('success', 'Banner added successfully.');
    }

    /**
     * Display the specified resource.
     */
    public function show(Banner $banner)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(Banner $banner)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, Banner $banner)
{
    $validated = $request->validate([
        'location' => 'required|string|max:255',
        'expiry_date' => 'required|date',
        'image' => 'nullable|image|mimes:jpeg,png,jpg,webp|max:2048',
        'link' => 'nullable|url',
        'status' => 'required|in:active,inactive',
    ]);

    if ($request->hasFile('image')) {
        if ($banner->image && Storage::disk('public')->exists($banner->image)) {
            Storage::disk('public')->delete($banner->image);
        }
        $validated['image'] = $request->file('image')->store('banners', 'public');
    } else {
        $validated['image'] = $banner->image;
    }

    $banner->update($validated);

    return redirect()->back()->with('success', 'Banner updated successfully!');
}

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(Banner $banner)
{
    // Delete image from storage
    if ($banner->image && Storage::disk('public')->exists($banner->image)) {
        Storage::disk('public')->delete($banner->image);
    }

    $banner->delete();

    return redirect()->back()->with('success', 'Banner deleted successfully!');
}

}
