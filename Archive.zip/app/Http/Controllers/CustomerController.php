<?php

namespace App\Http\Controllers;

use App\Models\Customer;
use App\Models\CustomerAnswer;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Crypt;
use Illuminate\Support\Facades\Schema;

class CustomerController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index(Request $request)
    {
        $query = Customer::query();

        if ($request->filled('search')) {
            $search = $request->search;

            // Get all column names of the "customers" table
            $columns = Schema::getColumnListing('customers');

            $query->where(function ($q) use ($columns, $search) {
                foreach ($columns as $column) {
                    $q->orWhere($column, 'like', "%{$search}%");
                }
            });
        }

        $users = $query->latest()->paginate(20);

        return view('admin.users', compact('users'));
    }

    public function toggleStatus($id)
    {
        $user = \App\Models\Customer::find($id);

        if (!$user) {
            return response()->json([
                'status' => false,
                'message' => 'User not found',
            ], 404);
        }

        $user->status = $user->status ? 0 : 1;
        $user->save();

        return response()->json([
            'status' => true,
            'message' => 'Status updated successfully',
            'new_status' => $user->status,
        ]);
    }

    public function pointHistory($encryptedUserId)
{
    try {
        $userId = Crypt::decrypt($encryptedUserId);
        $user = Customer::findOrFail($userId);
        
        // Fetch customer answers with questions
        $customerAnswers = CustomerAnswer::with('question')
            ->where('customer_id', $userId)
            ->orderBy('created_at', 'desc')
            ->paginate(20);
        
        // Calculate statistics
        $totalPoints = CustomerAnswer::where('customer_id', $userId)->sum('points');
        $totalAnswers = CustomerAnswer::where('customer_id', $userId)->count();
        $correctAnswers = CustomerAnswer::where('customer_id', $userId)->where('points', '>', 0)->count();
        $averagePoints = $totalAnswers > 0 ? round($totalPoints / $totalAnswers, 2) : 0;
        
        return view('admin.user-point-history', [
            'user' => $user,
            'customerAnswers' => $customerAnswers,
            'totalPoints' => $totalPoints,
            'totalAnswers' => $totalAnswers,
            'correctAnswers' => $correctAnswers,
            'averagePoints' => $averagePoints
        ]);
        
    } catch (\Illuminate\Contracts\Encryption\DecryptException $e) {
        abort(404, 'User not found');
    }
}
    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     */
    public function show(Customer $customer)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(Customer $customer)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, Customer $customer)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(Customer $customer)
    {
        //
    }
}
