<?php

namespace App\Http\Controllers;

use App\Models\SubCategory;
use App\Models\SubSubCategory;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\View\View;

class SubSubCategoryController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index(Request $request): View
    {
        $query = SubSubCategory::with('subcategory.category')->latest();

        if ($request->filled('search')) {
            $search = $request->search;
            $query->where('name', 'like', "%{$search}%");
        }

        $subsubcategories = $query->paginate(20);
        $subcategories = SubCategory::with('category')->get();

        return view('admin.subsubcategory', compact('subsubcategories', 'subcategories'));
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request): RedirectResponse
    {
        $validated = $request->validate([
            'subcategory_id' => 'required|exists:subcategories,id',
            'name' => 'required|string|max:255|unique:sub_sub_categories,name',
            'description' => 'nullable|string',
            'status' => 'required|boolean',
        ]);

        try {
            SubSubCategory::create($validated);
            
            return redirect()->back()
                ->with('success', 'Sub-Subcategory created successfully!');
                
        } catch (\Exception $e) {
            return redirect()->back()
                ->with('error', 'Failed to create sub-subcategory. Please try again.')
                ->withInput();
        }
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, SubSubCategory $subsubcategory): RedirectResponse
    {
        // Note: Route parameter binding usually requires matching name, 
        // verify route definition matches {subsubcategory}
        
        $validated = $request->validate([
            'subcategory_id' => 'required|exists:subcategories,id',
            'name' => 'required|string|max:255|unique:sub_sub_categories,name,' . $subsubcategory->id,
            'description' => 'nullable|string',
            'status' => 'required|boolean',
        ]);

        try {
            $subsubcategory->update($validated);
            
            return redirect()->route('subsubcategories.index')
                ->with('success', 'Sub-Subcategory updated successfully!');
                
        } catch (\Exception $e) {
            return redirect()->back()
                ->with('error', 'Failed to update sub-subcategory. Please try again.')
                ->withInput();
        }
    }

    /**
     * Remove the specified resource from storage.
     */
     public function destroy(SubSubCategory $subsubcategory): RedirectResponse
    {
        try {
            $subsubcategory->delete();
            
            return redirect()->back()
                ->with('success', 'Sub-Subcategory deleted successfully!');
                
        } catch (\Exception $e) {
            return redirect()->back()
                ->with('error', 'Failed to delete sub-subcategory. Please try again.');
        }
    }
}
