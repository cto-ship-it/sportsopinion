<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Models\Category;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Str;

class CategoryController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index(Request $request)
    {
        try {
            $search = $request->input('search');
            
            $categories = Category::when($search, function ($query, $search) {
                return $query->where('name', 'like', '%' . $search . '%')
                           ->orWhere('description', 'like', '%' . $search . '%');
            })
            ->orderBy('created_at', 'desc')
            ->paginate(20);

            return view('admin.category', compact('categories'));
        } catch (\Exception $e) {
            return redirect()->back()->with('error', 'Failed to fetch categories: ' . $e->getMessage());
        }
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        // This method is not needed as we're using modal
        return redirect()->route('categories.index');
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        try {
            $validator = Validator::make($request->all(), [
                'name' => 'required|string|max:255|unique:categories,name',
                'description' => 'nullable|string',
                'image' => 'nullable|image|mimes:jpeg,png,jpg,gif,webp',
                'status' => 'required|boolean',
            ], [
                'name.required' => 'Category name is required.',
                'name.unique' => 'Category name already exists.',
                'image.image' => 'The file must be an image.',
                'image.mimes' => 'The image must be a JPEG, PNG, JPG, GIF, or WEBP file.',
                'image.max' => 'The image size must not exceed 2MB.',
            ]);

            if ($validator->fails()) {
                return redirect()->back()
                    ->withErrors($validator)
                    ->withInput()
                    ->with('error', 'Validation failed!');
            }

            $imagePath = null;
            if ($request->hasFile('image')) {
                $imagePath = $request->file('image')->store('categories', 'public');
            }

            Category::create([
                'name' => $request->name,
                'description' => $request->description,
                'image' => $imagePath,
                'status' => $request->status,
            ]);

            return redirect()->route('categories.index')
                ->with('success', 'Category created successfully!');

        } catch (\Exception $e) {
            return redirect()->back()
                ->withInput()
                ->with('error', 'Failed to create category: ' . $e->getMessage());
        }
    }

    /**
     * Display the specified resource.
     */
    public function show(Category $category)
    {
        // This method is not needed for now
        return redirect()->route('categories.index');
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(Category $category)
    {
        // This method is not needed as we're using modal
        return redirect()->route('categories.index');
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, Category $category)
    {
        try {
            $validator = Validator::make($request->all(), [
                'name' => 'required|string|max:255|unique:categories,name,' . $category->id,
                'description' => 'nullable|string',
                'image' => 'nullable|image|mimes:jpeg,png,jpg,gif,webp',
                'status' => 'required|boolean',
            ], [
                'name.required' => 'Category name is required.',
                'name.unique' => 'Category name already exists.',
                'image.image' => 'The file must be an image.',
                'image.mimes' => 'The image must be a JPEG, PNG, JPG, GIF, or WEBP file.',
                'image.max' => 'The image size must not exceed 2MB.',
            ]);

            if ($validator->fails()) {
                return redirect()->back()
                    ->withErrors($validator)
                    ->withInput()
                    ->with('error', 'Validation failed!');
            }

            $imagePath = $category->image;
            
            // Handle image update
            if ($request->hasFile('image')) {
                // Delete old image if exists
                if ($category->image && Storage::disk('public')->exists($category->image)) {
                    Storage::disk('public')->delete($category->image);
                }
                
                $imagePath = $request->file('image')->store('categories', 'public');

            }

            $category->update([
                'name' => $request->name,
                'description' => $request->description,
                'image' => $imagePath,
                'status' => $request->status,
            ]);

            return redirect()->route('categories.index')
                ->with('success', 'Category updated successfully!');

        } catch (\Exception $e) {
            return redirect()->back()
                ->withInput()
                ->with('error', 'Failed to update category: ' . $e->getMessage());
        }
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(Category $category)
    {
        try {
            // Delete image if exists
            if ($category->image && Storage::disk('public')->exists($category->image)) {
                Storage::disk('public')->delete($category->image);
            }

            $category->delete();

            return redirect()->route('categories.index')
                ->with('success', 'Category deleted successfully!');

        } catch (\Exception $e) {
            return redirect()->back()
                ->with('error', 'Failed to delete category: ' . $e->getMessage());
        }
    }

    /**
     * Update category status (AJAX)
     */
    public function updateStatus(Request $request, Category $category)
    {
        try {
            $request->validate([
                'status' => 'required|boolean',
            ]);

            $category->update(['status' => $request->status]);

            return response()->json([
                'success' => true,
                'message' => 'Status updated successfully!',
                'status' => $category->status
            ]);

        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Failed to update status: ' . $e->getMessage()
            ], 500);
        }
    }
}