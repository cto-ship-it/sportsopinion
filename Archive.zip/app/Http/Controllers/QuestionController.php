<?php

namespace App\Http\Controllers;

use App\Models\Category;
use App\Models\CustomerAnswer;
use App\Models\Question;
use App\Services\BroadcastNotificationService;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Storage;

class QuestionController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
{
    $categories = Category::all();
    $questions = Question::with('category')->latest()->paginate(20);

    return view('admin.questions', compact('categories', 'questions'));
}

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     */
public function store(Request $request)
{
    // dd($request->all());
    $validated = $request->validate([
        'category_id'     => 'required|exists:categories,id',
        'subcategory_id'  => 'nullable|exists:subcategories,id',
        'sub_sub_category_id' => 'nullable|exists:sub_sub_categories,id',
        'banner_image'    => 'nullable|image|mimes:jpg,jpeg,png,webp|max:2048',
        'banner_link'     => 'nullable|url|max:255',
        'question'        => 'required|string|max:500',
        'options'         => 'required|array|size:2',
        'options.*'       => 'required|string|max:255',
        'publish_at'      => 'nullable|date',
        'expiry_date'     => 'required|date|after:now',
        'points'          => 'required|numeric|min:0',
        'attempt_point'   => 'required|numeric|min:0',
    ]);

    if ($request->hasFile('banner_image')) {
        $validated['banner_image'] = $request->file('banner_image')->store('banners', 'public');
    }

    // $validated['options'] = json_encode($validated['options']);
    $validated['answer'] = null;
    $validated['answer_status'] = 'pending';

    $question = \App\Models\Question::create($validated);

    $payload = [
        'title' => 'New Question Added!',
        'message' => "A new question is available: " . substr($question->question, 0, 50) . "...",
        'type' => 'question',
        'data' => [
            'question_id'   => $question->id,
            'category_id'   => $question->category_id,
            'subcategory_id'=> $question->subcategory_id,
            'banner_link'   => $question->banner_link ?? null,
        ],
    ];

    try {
        $broadcastService = app(\App\Services\BroadcastNotificationService::class);
        $broadcastService->send($payload);
    } catch (\Throwable $e) {
        Log::error('Broadcast notification failed: ' . $e->getMessage());
    }

    return redirect()->back()->with('success', 'Question added successfully and notifications sent!');
}



    /**
     * Display the specified resource.
     */
    public function show(Question $question)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(Question $question)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
public function update(Request $request, $id)
{
    $question = Question::findOrFail($id);

    $validated = $request->validate([
        'category_id'    => 'required|exists:categories,id',
        'subcategory_id' => 'nullable|exists:subcategories,id',
        'sub_sub_category_id' => 'nullable|exists:sub_sub_categories,id',
        'banner_image'   => 'nullable|image|mimes:jpg,jpeg,png,webp|max:2048',
        'banner_link'    => 'nullable|url|max:255',
        'question'       => 'required|string|max:500',
        'options'        => 'required|array|size:2',
        'options.*'      => 'required|string|max:255',
        'publish_at'     => 'nullable|date',
        'expiry_date'    => 'required|date|after:now',
        'points'         => 'required|numeric|min:0',
        'attempt_point'  => 'nullable|integer|min:0',
    ]);

    if ($request->hasFile('banner_image')) {
        if ($question->banner_image && Storage::disk('public')->exists($question->banner_image)) {
            Storage::disk('public')->delete($question->banner_image);
        }

        $validated['banner_image'] = $request->file('banner_image')->store('banners', 'public');
    } else {
        $validated['banner_image'] = $question->banner_image;
    }

    $validated['options'] = $request->options;

    $validated['answer'] = $question->answer;
    $validated['answer_status'] = $question->answer_status;

    $question->update($validated);

    return redirect()->back()->with('success', 'Question updated successfully!');
}



    /**
     * Remove the specified resource from storage.
     */
    public function destroy($id)
{
    $question = Question::findOrFail($id);

    // Delete banner image if exists
    if ($question->banner_image) {
        Storage::disk('public')->delete($question->banner_image);
    }

    $question->delete();

    return redirect()->back()->with('success', 'Question deleted successfully!');
}

public function updateStatus($id, $status, BroadcastNotificationService $notificationService)
{
    $validAnswers = ['A', 'B'];
    if (!in_array($status, $validAnswers)) {
        abort(400, 'Invalid answer key');
    }

    $question = Question::findOrFail($id);

    if ($question->answer_status === 'declared') {
        return redirect()->back()->with('error', 'Answer already declared for this question.');
    }

    DB::beginTransaction();

    try {
        $question->update([
            'answer' => $status,
            'answer_status' => 'declared',
        ]);

        $questionPoints = $question->points ?? 0;

        $answers = CustomerAnswer::where('question_id', $id)
            ->with('customer')
            ->get();

        foreach ($answers as $answer) {
            if (!$answer->customer) continue;

            $isCorrect = ($answer->selected_option === $status);

            $answer->update([
                'is_correct' => $isCorrect,
                'points_awarded' => $isCorrect ? $questionPoints : 0,
            ]);

            if ($isCorrect && $questionPoints > 0) {
                $answer->customer->increment('points', $questionPoints);
            }
        }

        DB::commit();

        $winningAnswers = $answers->where('selected_option', $status);
        $losingAnswers = $answers->where('selected_option', '!=', $status);

        if ($winningAnswers->count() > 0) {
            $winnerIds = $winningAnswers->pluck('customer_id')->unique()->toArray();
            $payloadWinner = [
                'title' => '🎉 Congratulations!',
                'message' => "Your answer to '{$question->question}' was correct! You earned {$questionPoints} points.",
                'type' => 'winner_announcement',
                'data' => ['question_id' => $id, 'correct_option' => $status],
            ];
            $notificationService->sendToSpecificCustomers($winnerIds, $payloadWinner);
        }

        if ($losingAnswers->count() > 0) {
            $loserIds = $losingAnswers->pluck('customer_id')->unique()->toArray();
            $payloadLoser = [
                'title' => '😔 Better Luck Next Time!',
                'message' => "The correct answer for '{$question->question}' was Option {$status}. Try again next time!",
                'type' => 'loser_announcement',
                'data' => ['question_id' => $id, 'correct_option' => $status],
            ];
            $notificationService->sendToSpecificCustomers($loserIds, $payloadLoser);
        }

        return redirect()->back()->with('success', "Answer '{$status}' declared successfully! Winners have been awarded.");
    } catch (\Throwable $e) {
        DB::rollBack();
        Log::error("Failed to declare answer for question {$id}: " . $e->getMessage());
        return redirect()->back()->with('error', 'Something went wrong while updating the answer.');
    }
}


}
