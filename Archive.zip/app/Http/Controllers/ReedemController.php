<?php

namespace App\Http\Controllers;

use App\Models\CustomerRedeemRequest;
use App\Models\Reedem;
use App\Models\Rewards;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\Services\BroadcastNotificationService;

class ReedemController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        //
    }

    public function pending()
    {
        $redeemRequests = CustomerRedeemRequest::with(['reward', 'customer'])
        ->where('status','pending')
        ->latest()
        ->paginate(20);
        // dd($redeemRequests);
        return view('admin.reedem.pending', compact('redeemRequests'));
    }

    public function processing()
    {
        $redeemRequests = CustomerRedeemRequest::with(['reward', 'customer'])
        ->where('status','approved')
        ->latest()
        ->paginate(20);
        return view('admin.reedem.processing',compact('redeemRequests'));
    }

    public function complete()
    {
        $redeemRequests = CustomerRedeemRequest::with(['reward', 'customer'])
        ->where('status','complete')
        ->latest()
        ->paginate(20);
        return view('admin.reedem.complete',compact('redeemRequests'));
    }

    public function cancel()
    {
        $redeemRequests = CustomerRedeemRequest::with(['reward', 'customer'])
        ->where('status','cancel')
        ->latest()
        ->paginate(20);
        return view('admin.reedem.cancel' ,compact('redeemRequests'));
    }


    public function updateStatus($id, $status)
    {
        DB::transaction(function () use ($id, $status) {

            $request = CustomerRedeemRequest::findOrFail($id);

            // Only run logic if status actually changed
            if ($request->status === $status) {
                return;
            }

            $customer = $request->customer;
            $oldStatus = $request->status;

            // --- Handle refund if cancelled ---
            if ($status === 'cancel' && $oldStatus !== 'cancel') {
                $customer->points += $request->points;
                $customer->save();
            }

            // --- Handle approval timestamp ---
            if ($status === 'approved') {
                $request->approved_at = now();
            }

            $request->status = $status;
            $request->save();

            // --- Send Notification ---
            $notificationService = new BroadcastNotificationService();

            // Customize message per status
            switch ($status) {
                case 'approved':
                    $title = 'Redeem Request Approved';
                    $message = "Your redeem request for {$request->points} points has been approved.";
                    $type = 'redeem_approved';
                    break;

                case 'cancel':
                    $title = 'Redeem Request Cancelled';
                    $message = "Your redeem request for {$request->points} points was cancelled. Points have been refunded to your account.";
                    $type = 'redeem_cancelled';
                    break;

                case 'pending':
                    $title = 'Redeem Request Pending';
                    $message = "Your redeem request for {$request->points} points is now pending review.";
                    $type = 'redeem_pending';
                    break;

                default:
                    $title = 'Redeem Status Updated';
                    $message = "Your redeem request status has been updated to {$status}.";
                    $type = 'redeem_update';
            }

            $payload = [
                'title' => $title,
                'message' => $message,
                'type' => $type,
                'data' => [
                    'redeem_id' => $request->id,
                    'status' => $status,
                    'points' => $request->points,
                ],
            ];

            $notificationService->sendToSpecificCustomers([$customer->id], $payload);
        });

        return redirect()->back()->with('success', 'Status updated and customer notified successfully.');
    }


    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     */
    public function show(Reedem $reedem)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(Reedem $reedem)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, Reedem $reedem)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(Reedem $reedem)
    {
        //
    }
}
