<?php

require __DIR__ . '/vendor/autoload.php';

$app = require_once __DIR__ . '/bootstrap/app.php';
$app->make('Illuminate\Contracts\Console\Kernel')->bootstrap();

use Illuminate\Http\Request;
use App\Http\Controllers\Api\CustomerAuthController;

echo "Testing login flow...\n\n";

// Test login
$controller = app(CustomerAuthController::class);

$request = Request::create('/api/customer/login', 'POST', [
    'email' => 'coolpriyanshsingh2005@gmail.com',
    'mpin' => '1234', // Use your actual MPIN
]);

try {
    $response = $controller->login($request);
    $data = json_decode($response->getContent(), true);
    
    echo "Login Response:\n";
    echo json_encode($data, JSON_PRETTY_PRINT) . "\n\n";
    
    if (isset($data['token'])) {
        echo "✓ Token received: " . substr($data['token'], 0, 20) . "...\n\n";
        
        // Test profile fetch with token
        $profileRequest = Request::create('/api/customer/profile', 'GET');
        $profileRequest->headers->set('Authorization', 'Bearer ' . $data['token']);
        
        $profileResponse = $controller->profile($profileRequest);
        $profileData = json_decode($profileResponse->getContent(), true);
        
        echo "Profile Response:\n";
        echo json_encode($profileData, JSON_PRETTY_PRINT) . "\n";
    }
} catch (\Throwable $e) {
    echo "✗ Error: " . $e->getMessage() . "\n";
}
