-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 07, 2026 at 11:16 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `sport-opinion`
--

-- --------------------------------------------------------

--
-- Table structure for table `app_notifications`
--

CREATE TABLE `app_notifications` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `customer_id` bigint(20) UNSIGNED NOT NULL,
  `title` varchar(255) DEFAULT NULL,
  `message` text DEFAULT NULL,
  `type` varchar(255) DEFAULT NULL,
  `data` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`data`)),
  `is_read` tinyint(1) NOT NULL DEFAULT 0,
  `read_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `banners`
--

CREATE TABLE `banners` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `location` varchar(255) NOT NULL COMMENT 'home, redeem, etc.',
  `image` varchar(255) NOT NULL COMMENT 'Path to banner image',
  `link` varchar(255) DEFAULT NULL COMMENT 'Optional banner link',
  `expiry_date` date DEFAULT NULL COMMENT 'Banner expiry date',
  `status` enum('active','inactive') NOT NULL DEFAULT 'inactive',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `banners`
--

INSERT INTO `banners` (`id`, `location`, `image`, `link`, `expiry_date`, `status`, `created_at`, `updated_at`) VALUES
(2, 'home', 'banners/58wOS4pSwbOryGtZmdfweawp2bDyVQ7xaUQ8tO3v.jpg', 'https://dailyopinion.in/login', '2025-10-15', 'active', '2025-10-13 04:39:16', '2025-10-13 04:39:16');

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL,
  `description` text DEFAULT NULL,
  `image` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 1 COMMENT '1 = Active, 0 = Inactive'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`id`, `name`, `description`, `image`, `created_at`, `updated_at`, `status`) VALUES
(1, 'CRIC', 'Test your cricket knowledge and share your opinion on the latest matches & players.', NULL, '2025-10-13 02:27:06', '2025-10-13 02:27:06', 1),
(2, 'POL', 'Stay engaged with political happenings and voice your stand.', NULL, '2025-10-13 02:27:06', '2025-10-13 02:27:06', 1),
(3, 'Business', 'Keep up with the market trends, companies, and financial news.', NULL, '2025-10-13 02:27:06', '2025-10-13 02:27:06', 1),
(4, 'Entertainment', 'From movies to celebrities share your take on what’s trending.', NULL, '2025-10-13 02:27:06', '2025-10-13 02:27:06', 1),
(5, 'Cricket', 'Test your cricket knowledge and share your opinion on the latest matches & players.', 'categories/9mLNbMvRZACZLld9uMmOcXraPzjZ8sj4rm3QQegM.jpg', '2025-10-14 06:09:05', '2025-11-04 05:04:11', 1),
(6, 'Stock Market', 'Keep up with the market trends, companies, and financial news.', NULL, '2025-10-14 06:09:05', '2025-10-14 06:09:05', 1);

-- --------------------------------------------------------

--
-- Table structure for table `customerfcmtokens`
--

CREATE TABLE `customerfcmtokens` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `customer_id` bigint(20) UNSIGNED NOT NULL,
  `token` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `customers`
--

CREATE TABLE `customers` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL,
  `phone` varchar(255) DEFAULT NULL,
  `dob` date DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `referral_code` varchar(255) NOT NULL,
  `referred_by` varchar(255) DEFAULT NULL,
  `mpin` varchar(255) NOT NULL,
  `profile_pic` varchar(255) DEFAULT NULL,
  `points` int(11) DEFAULT 100,
  `status` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `customers`
--

INSERT INTO `customers` (`id`, `name`, `phone`, `dob`, `email`, `referral_code`, `referred_by`, `mpin`, `profile_pic`, `points`, `status`, `created_at`, `updated_at`) VALUES
(1, 'John Doe', '9876543210', NULL, NULL, '', NULL, '$2y$12$u35h59oU3X4vZZ8Z.PVoEea0qikx6oL3ST661OZNCGLc.MSwBcmAK', NULL, 100, 1, '2025-10-11 02:34:20', '2025-10-11 02:34:20'),
(2, 'Satyam Singh', '9625724273', '2000-02-24', NULL, '', NULL, '$2y$12$ai4GGEOJSbZRuwImA4sd0eLNHUOWDxUhVFmmQWww8iW7VpeaCOuvm', 'customers/1760595585_nature wallpaper.jpg', 320, 1, '2025-10-11 02:39:43', '2025-11-01 02:16:11'),
(3, 'Adil Hussain', '9876543218', NULL, 'adil@example.com', '', NULL, '$2y$12$VHvgPSZ6wTCiOPTU.ZDcl.aYWSRjwuuWut9SON2bfRG2vBZOedkZu', NULL, 100, 0, '2025-10-11 04:19:27', '2025-10-16 07:12:30'),
(4, 'sonu', '7735946601', NULL, NULL, 'QFQY3819', NULL, '$2y$12$0UZvEQKUcPahzvBPoM6/2eBMZpSicIy5KHZrsg/i0x3rZUbEYJvVy', NULL, 100, 1, '2025-10-24 07:28:48', '2025-10-31 05:24:18'),
(5, 'Satyam', NULL, NULL, 'satyamsingh962572@gmail.com', 'KRZ24456', NULL, '$2y$12$KvukozabpLwwk9bSR3gHLu0TI1We964HGPdJs1a2Az2KFydSJrE.C', NULL, 100, 1, '2025-11-11 05:08:37', '2025-11-11 05:08:37');

-- --------------------------------------------------------

--
-- Table structure for table `customer_address`
--

CREATE TABLE `customer_address` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `customer_id` bigint(20) UNSIGNED NOT NULL,
  `state` varchar(255) DEFAULT NULL,
  `district` varchar(255) DEFAULT NULL,
  `city` varchar(255) DEFAULT NULL,
  `pincode` varchar(255) DEFAULT NULL,
  `address` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `customer_address`
--

INSERT INTO `customer_address` (`id`, `customer_id`, `state`, `district`, `city`, `pincode`, `address`, `created_at`, `updated_at`) VALUES
(1, 3, 'California', 'Los Angeles', 'Los Angeles', '90001', '123 Main St', '2025-10-11 05:08:35', '2025-10-11 05:08:35'),
(2, 2, 'uttarpradesh', 'hello', NULL, NULL, NULL, '2025-10-16 00:49:45', '2025-10-16 00:49:45');

-- --------------------------------------------------------

--
-- Table structure for table `customer_answers`
--

CREATE TABLE `customer_answers` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `customer_id` bigint(20) UNSIGNED NOT NULL,
  `question_id` bigint(20) UNSIGNED NOT NULL,
  `answer` text NOT NULL,
  `points` int(11) NOT NULL DEFAULT 0,
  `is_correct` tinyint(1) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `customer_answers`
--

INSERT INTO `customer_answers` (`id`, `customer_id`, `question_id`, `answer`, `points`, `is_correct`, `created_at`, `updated_at`) VALUES
(1, 2, 13, 'Yes', 0, NULL, '2025-10-29 11:57:03', NULL),
(2, 2, 12, 'Yes', 20, NULL, '2025-10-22 11:57:11', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `customer_bank_details`
--

CREATE TABLE `customer_bank_details` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `customer_id` bigint(20) UNSIGNED NOT NULL,
  `account_holder_name` varchar(255) NOT NULL,
  `ifsc` varchar(20) NOT NULL,
  `account_no` varchar(30) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `customer_redeem_requests`
--

CREATE TABLE `customer_redeem_requests` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `customer_id` bigint(20) UNSIGNED NOT NULL,
  `reward_id` bigint(20) UNSIGNED NOT NULL,
  `points` int(10) UNSIGNED NOT NULL,
  `status` enum('pending','approved','complete','cancel') NOT NULL DEFAULT 'pending',
  `remarks` varchar(255) DEFAULT NULL,
  `approved_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `customer_redeem_requests`
--

INSERT INTO `customer_redeem_requests` (`id`, `customer_id`, `reward_id`, `points`, `status`, `remarks`, `approved_at`, `created_at`, `updated_at`) VALUES
(1, 2, 3, 100, 'cancel', NULL, '2025-10-24 11:34:33', '2025-10-24 12:03:12', '2025-11-01 02:16:11');

-- --------------------------------------------------------

--
-- Table structure for table `failed_jobs`
--

CREATE TABLE `failed_jobs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `uuid` varchar(255) NOT NULL,
  `connection` text NOT NULL,
  `queue` text NOT NULL,
  `payload` longtext NOT NULL,
  `exception` longtext NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `faqs`
--

CREATE TABLE `faqs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `question` text NOT NULL,
  `answer` longtext NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `faqs`
--

INSERT INTO `faqs` (`id`, `question`, `answer`, `created_at`, `updated_at`) VALUES
(1, 'What is the “Daily Opinion” app about?', 'Daily Opinion lets users share their views on trending topics and see what others think. Every day brings a new poll or question to keep discussions fresh and relevant.', '2025-10-13 06:14:26', '2025-10-13 06:14:26');

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(255) NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2014_10_12_000000_create_users_table', 1),
(2, '2014_10_12_100000_create_password_reset_tokens_table', 1),
(3, '2019_08_19_000000_create_failed_jobs_table', 1),
(4, '2019_12_14_000001_create_personal_access_tokens_table', 1),
(6, '2025_10_10_064819_create_customers_table', 2),
(7, '2025_10_11_100503_create_customer_address_table', 3),
(8, '2025_10_10_065348_create_points_table', 4),
(9, '2025_10_10_070641_create_rewards_table', 4),
(10, '2025_10_10_072048_create_reedems_table', 4),
(11, '2025_10_13_074058_create_categories_table', 5),
(12, '2025_10_13_082558_create_banners_table', 6),
(13, '2025_10_13_113043_create_f_a_q_s_table', 7),
(14, '2025_10_14_063517_create_questions_table', 8),
(15, '2025_10_14_082628_create_customer_answers_table', 9),
(21, '2025_10_14_104451_create_sub_categories_table', 10),
(22, '2025_10_15_120924_update_questions_table', 10),
(23, '2025_10_16_053617_update_customer_table', 11),
(26, '2025_10_17_051430_udpate_rewards_table', 12),
(28, '2025_10_23_113858_create_customerfcmtokens_table', 13),
(29, '2025_10_23_125359_add_referral_columns_to_customers_table', 14),
(30, '2025_10_24_074526_create_customer_redeem_requests_table', 15),
(31, '2025_10_25_070027_create_app_notifications_table', 16),
(32, '2025_11_01_100929_add_role_and_permissions_to_users_table', 17),
(33, '2025_11_12_075917_create_customer_bank_details_table', 18),
(34, '2026_01_07_094650_add_sub_sub_category_and_publish_at_to_questions_table', 19);

-- --------------------------------------------------------

--
-- Table structure for table `password_reset_tokens`
--

CREATE TABLE `password_reset_tokens` (
  `email` varchar(255) NOT NULL,
  `token` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `personal_access_tokens`
--

CREATE TABLE `personal_access_tokens` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `tokenable_type` varchar(255) NOT NULL,
  `tokenable_id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL,
  `token` varchar(64) NOT NULL,
  `abilities` text DEFAULT NULL,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `expires_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `personal_access_tokens`
--

INSERT INTO `personal_access_tokens` (`id`, `tokenable_type`, `tokenable_id`, `name`, `token`, `abilities`, `last_used_at`, `expires_at`, `created_at`, `updated_at`) VALUES
(1, 'App\\Models\\Customer', 1, 'CustomerAuthToken', 'a55d027f5967ebd8e99616b638b76e837557b18fab136353532188839c974278', '[\"*\"]', NULL, NULL, '2025-10-11 02:34:20', '2025-10-11 02:34:20'),
(2, 'App\\Models\\Customer', 1, 'CustomerAuthToken', '49fd1b01f66634d57c0ffcfa5493890a0428e947da55d104350c2999cf3175d2', '[\"*\"]', NULL, NULL, '2025-10-11 02:46:50', '2025-10-11 02:46:50'),
(3, 'App\\Models\\Customer', 3, 'CustomerAuthToken', '5287011258c9a0f4fba42780900f800e05b8007fb91fcde29bd8201c0b676c4a', '[\"*\"]', NULL, NULL, '2025-10-11 04:19:27', '2025-10-11 04:19:27'),
(5, 'App\\Models\\Customer', 3, 'CustomerAuthToken', '83efe72dd9fbe905fb58bce4757b17118c1dcb9f9eda35c265b41779b5a22b75', '[\"*\"]', '2025-10-11 05:16:41', NULL, '2025-10-11 04:30:52', '2025-10-11 05:16:41'),
(6, 'App\\Models\\Customer', 2, 'CustomerAuthToken', '23618af976a69f8c164f077071bb64ada10293656ca8c55998c7c51d927e1266', '[\"*\"]', '2025-10-11 05:28:56', NULL, '2025-10-11 05:17:40', '2025-10-11 05:28:56'),
(7, 'App\\Models\\Customer', 2, 'CustomerAuthToken', '6ee45753ca32155a96fe7e29563298762d97735ec6ec835118e04189c1ff1c62', '[\"*\"]', NULL, NULL, '2025-10-11 06:09:48', '2025-10-11 06:09:48'),
(8, 'App\\Models\\Customer', 2, 'CustomerAuthToken', '65240116b9c58b4039635c6596470c106a2e64e4e3c18aee12c6f40f6aa200d2', '[\"*\"]', '2025-10-16 00:49:45', NULL, '2025-10-16 00:37:29', '2025-10-16 00:49:45'),
(9, 'App\\Models\\Customer', 4, 'CustomerAuthToken', '2db0bc5f7b7e40a049dba80f1865be79382e5e011c89431d953a3d6f1d3f9c66', '[\"*\"]', NULL, NULL, '2025-10-24 07:28:49', '2025-10-24 07:28:49'),
(10, 'App\\Models\\Customer', 5, 'CustomerAuthToken', '8772b7d5bae0ee50ef5f81cf63fe9adc6716eadaee49f60106fb602651b338e7', '[\"*\"]', NULL, NULL, '2025-11-11 05:08:37', '2025-11-11 05:08:37');

-- --------------------------------------------------------

--
-- Table structure for table `points`
--

CREATE TABLE `points` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `questions`
--

CREATE TABLE `questions` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `category_id` bigint(20) UNSIGNED NOT NULL,
  `banner_image` varchar(255) DEFAULT NULL,
  `banner_link` varchar(255) DEFAULT NULL,
  `publish_at` timestamp NULL DEFAULT NULL,
  `question` text NOT NULL,
  `options` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`options`)),
  `answer` char(1) DEFAULT NULL,
  `answer_status` enum('pending','declared') DEFAULT 'pending',
  `points` int(11) NOT NULL DEFAULT 0,
  `expiry_date` datetime DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `subcategory_id` bigint(20) UNSIGNED DEFAULT NULL,
  `sub_sub_category_id` bigint(20) UNSIGNED DEFAULT NULL,
  `attempt_point` int(11) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `questions`
--

INSERT INTO `questions` (`id`, `category_id`, `banner_image`, `banner_link`, `publish_at`, `question`, `options`, `answer`, `answer_status`, `points`, `expiry_date`, `created_at`, `updated_at`, `subcategory_id`, `sub_sub_category_id`, `attempt_point`) VALUES
(2, 1, 'banners/eKCgwDU4Y382yU7ygslFNgrJNYsGBa0A0oxpQPCG.png', 'https://admin.dailyopinion.in/admin/banners', NULL, 'which team will win today ?', NULL, NULL, 'pending', 500, NULL, '2025-10-14 02:03:38', '2025-10-14 02:26:02', NULL, NULL, 0),
(3, 6, 'banners/7hAW3hTlmFOVZe48w7ztDr3QRGODlgxJQNOycqKU.png', 'https://admin.dailyopinion.in/admin/banners', NULL, 'this is stock market question?', NULL, NULL, 'pending', 50, NULL, '2025-10-15 05:30:23', '2025-10-15 05:33:12', NULL, NULL, 0),
(4, 6, 'banners/CgVtSjphgxWhbFYuhF58aHA54DyrshLnzs5OVs9K.png', 'https://admin.dailyopinion.in/admin/banners', NULL, 'this is stock market question?', NULL, NULL, 'pending', 50, NULL, '2025-10-15 05:30:24', '2025-10-15 05:30:24', NULL, NULL, 0),
(5, 1, 'banners/PcmQVYJtIevDORrm7uRJHRmRYlvUnijCxnw8ar2t.png', 'https://admin.dailyopinion.in/admin/banners', NULL, 'hello', NULL, NULL, 'pending', 20, NULL, '2025-10-15 05:31:20', '2025-10-15 05:31:20', NULL, NULL, 0),
(6, 5, 'banners/U0NFoBxeP8OPezhaNccYULnE4QEJwYnZVA2iLMRS.png', 'https://admin.dailyopinion.in/admin/banners', NULL, 'this is dummy question', NULL, NULL, 'pending', 50, NULL, '2025-10-15 06:53:38', '2025-10-15 06:53:38', NULL, NULL, 0),
(7, 6, 'banners/Q2P9U68bEt31Mf8tS9S5loqC0Hq4OPGX6wCC4bpG.png', 'https://admin.dailyopinion.in/admin/banners', NULL, 'this is polotical questions?', NULL, NULL, 'pending', 50, NULL, '2025-10-15 07:24:35', '2025-10-15 07:51:02', 2, NULL, 0),
(8, 1, 'banners/cricket1.jpg', 'https://espncricinfo.com', NULL, 'Who won the IPL 2024 title?', NULL, NULL, 'pending', 10, NULL, '2025-10-16 07:10:28', '2025-10-16 07:10:28', 1, NULL, 0),
(9, 1, 'banners/cricket2.jpg', 'https://espncricinfo.com', NULL, 'Which player scored the most runs in IPL 2023?', NULL, NULL, 'pending', 15, NULL, '2025-10-16 07:10:28', '2025-10-16 07:10:28', 1, NULL, 0),
(10, 1, 'banners/worldcup1.jpg', 'https://icc-cricket.com', NULL, 'Which country has the most Cricket World Cup titles?', NULL, NULL, 'pending', 10, NULL, '2025-10-16 07:10:28', '2025-10-16 07:10:28', 2, NULL, 0),
(11, 1, 'banners/worldcup2.jpg', 'https://icc-cricket.com', NULL, 'Who was the man of the match in World Cup 2019 final?', NULL, NULL, 'pending', 15, NULL, '2025-10-16 07:10:28', '2025-10-16 07:10:28', 2, NULL, 0),
(12, 1, 'banners/legends1.jpg', 'https://cricket.com', NULL, 'Who is known as “The Wall” in Indian cricket?', NULL, NULL, 'pending', 10, NULL, '2025-10-16 07:10:28', '2025-10-23 05:47:12', 3, NULL, 0),
(13, 1, 'banners/legends2.jpg', 'https://cricket.com', NULL, 'How many centuries did Sachin Tendulkar score in ODIs?', NULL, NULL, 'pending', 20, NULL, '2025-10-16 07:10:28', '2025-10-23 05:51:49', 3, NULL, 0),
(14, 1, 'banners/tournament1.jpg', 'https://bcci.tv', NULL, 'Where will the next T20 World Cup be held?', NULL, NULL, 'pending', 10, NULL, '2025-10-16 07:10:28', '2025-10-16 07:10:28', 4, NULL, 0),
(15, 1, 'banners/fantasy1.jpg', 'https://fantasycricket.com', NULL, 'Who would be a must-pick bowler for fantasy IPL 2025?', NULL, NULL, 'pending', 5, NULL, '2025-10-16 07:10:28', '2025-10-16 07:10:28', 5, NULL, 0),
(16, 1, 'banners/fantasy2.jpg', 'https://fantasycricket.com', NULL, 'Which all-rounder gives the best fantasy points in T20s?', NULL, NULL, 'pending', 10, NULL, '2025-10-16 07:10:28', '2025-10-23 05:45:22', 5, NULL, 0),
(17, 1, 'banners/tournament2.jpg', 'https://bcci.tv', NULL, 'Which country is hosting the ICC Champions Trophy 2025?', NULL, NULL, 'pending', 10, NULL, '2025-10-16 07:10:28', '2025-10-16 07:10:28', 4, NULL, 0),
(18, 2, 'banners/election1.jpg', 'https://electioncommission.gov', NULL, 'Which party won the majority in the 2024 elections?', NULL, NULL, 'pending', 10, NULL, '2025-10-16 07:10:28', '2025-10-16 07:10:28', 6, NULL, 0),
(19, 2, 'banners/election2.jpg', 'https://electioncommission.gov', NULL, 'Who is the current Prime Minister of India?', NULL, NULL, 'pending', 5, NULL, '2025-10-16 07:10:28', '2025-10-16 07:10:28', 6, NULL, 0),
(20, 2, 'banners/policy1.jpg', 'https://indiagov.in', NULL, 'What is the key goal of the Digital India policy?', NULL, NULL, 'pending', 15, NULL, '2025-10-16 07:10:28', '2025-10-16 07:10:28', 7, NULL, 0),
(21, 2, 'banners/policy2.jpg', 'https://indiagov.in', NULL, 'Which scheme focuses on rural employment in India?', NULL, NULL, 'pending', 10, NULL, '2025-10-16 07:10:28', '2025-10-16 07:10:28', 7, NULL, 0),
(22, 2, 'banners/foreign1.jpg', 'https://mea.gov.in', NULL, 'Which countries signed the new trade deal in 2024?', NULL, NULL, 'pending', 10, NULL, '2025-10-16 07:10:28', '2025-10-16 07:10:28', 8, NULL, 0),
(23, 2, 'banners/foreign2.jpg', 'https://mea.gov.in', NULL, 'Which country hosted the G20 summit 2024?', NULL, NULL, 'pending', 10, NULL, '2025-10-16 07:10:28', '2025-10-16 07:10:28', 8, NULL, 0),
(24, 2, 'banners/scandal1.jpg', 'https://news.com', NULL, 'Which minister resigned after corruption charges in 2023?', NULL, NULL, 'pending', 10, NULL, '2025-10-16 07:10:28', '2025-10-16 07:10:28', 9, NULL, 0),
(25, 2, 'banners/public1.jpg', 'https://surveyindia.com', NULL, 'Do you think political debates influence voter opinion?', NULL, NULL, 'pending', 5, NULL, '2025-10-16 07:10:28', '2025-10-16 07:10:28', 10, NULL, 0),
(26, 2, 'banners/public2.jpg', 'https://surveyindia.com', NULL, 'Should voting be made compulsory?', NULL, NULL, 'pending', 5, NULL, '2025-10-16 07:10:28', '2025-10-16 07:10:28', 10, NULL, 0),
(27, 2, 'banners/scandal2.jpg', 'https://news.com', NULL, 'Was media coverage fair in the latest political scandal?', NULL, NULL, 'pending', 10, NULL, '2025-10-16 07:10:28', '2025-10-16 07:10:28', 9, NULL, 0),
(28, 3, 'banners/market1.jpg', 'https://moneycontrol.com', NULL, 'What caused the Nifty 50 to rise in Q2 2024?', NULL, NULL, 'pending', 10, NULL, '2025-10-16 07:10:28', '2025-10-16 07:10:28', 11, NULL, 0),
(29, 3, 'banners/market2.jpg', 'https://moneycontrol.com', NULL, 'Which sector performed best in 2024?', NULL, NULL, 'pending', 10, NULL, '2025-10-16 07:10:28', '2025-10-16 07:10:28', 11, NULL, 0),
(30, 3, 'banners/topstocks1.jpg', 'https://nseindia.com', NULL, 'Which stock gained the most this week?', NULL, NULL, 'pending', 10, NULL, '2025-10-16 07:10:28', '2025-10-16 07:10:28', 12, NULL, 0),
(31, 3, 'banners/crypto1.jpg', 'https://coinmarketcap.com', NULL, 'Which cryptocurrency surged in early 2024?', NULL, NULL, 'pending', 10, NULL, '2025-10-16 07:10:28', '2025-10-16 07:10:28', 13, NULL, 0),
(32, 3, 'banners/crypto2.jpg', 'https://coinmarketcap.com', NULL, 'Do you think Bitcoin will cross $100k in 2025?', NULL, NULL, 'pending', 15, NULL, '2025-10-16 07:10:28', '2025-10-16 07:10:28', 13, NULL, 0),
(33, 3, 'banners/invest1.jpg', 'https://zerodha.com', NULL, 'What’s your go-to long-term investment strategy?', NULL, NULL, 'pending', 10, NULL, '2025-10-16 07:10:28', '2025-10-16 07:10:28', 14, NULL, 0),
(34, 3, 'banners/invest2.jpg', 'https://groww.in', NULL, 'Should beginners invest in mutual funds or stocks?', NULL, NULL, 'pending', 10, NULL, '2025-10-16 07:10:28', '2025-10-16 07:10:28', 14, NULL, 0),
(35, 3, 'banners/startup1.jpg', 'https://yourstory.com', NULL, 'Which upcoming IPO are you most excited about?', NULL, NULL, 'pending', 10, NULL, '2025-10-16 07:10:28', '2025-10-16 07:10:28', 15, NULL, 0),
(36, 3, 'banners/startup2.jpg', 'https://yourstory.com', NULL, 'Should startups rely on venture capital or bootstrapping?', NULL, NULL, 'pending', 10, NULL, '2025-10-16 07:10:28', '2025-10-16 07:10:28', 15, NULL, 0),
(37, 3, 'banners/topstocks2.jpg', 'https://nseindia.com', NULL, 'Which company saw a major drop after Q1 earnings?', NULL, NULL, 'pending', 10, NULL, '2025-10-16 07:10:28', '2025-10-16 07:10:28', 12, NULL, 0),
(38, 4, 'banners/movie1.jpg', 'https://imdb.com', NULL, 'Which movie won Best Picture in 2024 Oscars?', NULL, NULL, 'pending', 10, NULL, '2025-10-16 07:10:28', '2025-10-16 07:10:28', 16, NULL, 0),
(39, 4, 'banners/movie2.jpg', 'https://rottentomatoes.com', NULL, 'Who was the highest-grossing actor of 2024?', NULL, NULL, 'pending', 10, NULL, '2025-10-16 07:10:28', '2025-10-16 07:10:28', 16, NULL, 0),
(40, 4, 'banners/celeb1.jpg', 'https://variety.com', NULL, 'Which celebrity topped the social media charts this month?', NULL, NULL, 'pending', 10, NULL, '2025-10-16 07:10:28', '2025-10-16 07:10:28', 17, NULL, 0),
(41, 4, 'banners/celeb2.jpg', 'https://etonline.com', NULL, 'Which Bollywood couple recently got married?', NULL, NULL, 'pending', 5, NULL, '2025-10-16 07:10:28', '2025-10-16 07:10:28', 17, NULL, 0),
(42, 4, 'banners/music1.jpg', 'https://spotify.com', NULL, 'Which artist released the most streamed album in 2024?', NULL, NULL, 'pending', 10, NULL, '2025-10-16 07:10:28', '2025-10-16 07:10:28', 18, NULL, 0),
(43, 4, 'banners/music2.jpg', 'https://spotify.com', NULL, 'Do you prefer indie or mainstream music?', NULL, NULL, 'pending', 5, NULL, '2025-10-16 07:10:28', '2025-10-16 07:10:28', 18, NULL, 0),
(44, 4, 'banners/tv1.jpg', 'https://netflix.com', NULL, 'Which new Netflix series became most watched in 2024?', NULL, NULL, 'pending', 10, NULL, '2025-10-16 07:10:28', '2025-10-16 07:10:28', 19, NULL, 0),
(45, 4, 'banners/tv2.jpg', 'https://hotstar.com', NULL, 'Which TV show had the most shocking season finale?', NULL, NULL, 'pending', 10, NULL, '2025-10-16 07:10:28', '2025-10-16 07:10:28', 19, NULL, 0),
(46, 4, 'banners/awards1.jpg', 'https://hollywoodreporter.com', NULL, 'Who won Best Director at the Filmfare Awards 2024?', NULL, NULL, 'pending', 10, NULL, '2025-10-16 07:10:28', '2025-10-16 07:10:28', 20, NULL, 0),
(47, 4, 'banners/awards2.jpg', 'https://hollywoodreporter.com', NULL, 'Was the Oscar 2024 results fair according to you?', NULL, NULL, 'pending', 5, NULL, '2025-10-16 07:10:28', '2025-10-16 07:10:28', 20, NULL, 0),
(48, 3, 'banners/dwn78ptgcmRvGs1ZCuH9MNKmtcD5Dy4PF5iWEbvt.jpg', 'https://hollywoodreporter.com', NULL, 'this is dummy questions', NULL, NULL, 'pending', 400, '2025-10-24 20:12:00', '2025-10-18 01:04:36', '2025-10-18 01:31:32', 14, NULL, 0),
(49, 2, 'banners/W2JQh5Ojtnv2NdKC0x5gXe1CukMXmEI29kPFDLsk.jpg', 'https://admin.dailyopinion.in/admin/banners', NULL, 'this is dummy questions', NULL, NULL, 'pending', 100, '2025-10-30 17:40:00', '2025-10-23 01:34:59', '2025-10-23 05:58:56', 10, NULL, 0),
(50, 1, 'banners/AyiaJOuUfOQ6U1GUAUoJ2ns4SYVWKros6hyVFtga.jpg', 'https://hollywoodreporter.com', NULL, 'this is cricket dummy questions?', NULL, NULL, 'pending', 100, '2025-10-28 18:42:00', '2025-10-23 01:37:05', '2025-10-23 04:59:50', 3, NULL, 100),
(51, 2, 'banners/H3KGgKS9SJ95nyajqvxWJjndra5uVCL8sUWLr3IV.png', NULL, NULL, 'this is dummy question', NULL, NULL, 'pending', 100, '2025-11-06 18:49:00', '2025-11-05 05:19:28', '2025-11-05 05:19:28', 10, NULL, 10),
(52, 2, 'banners/Yxk6TovBAYBV88vSNEc8ijSFi7zl1zKO44Kb8JVO.png', NULL, NULL, 'this is dummy question', NULL, NULL, 'pending', 100, '2025-11-19 20:26:00', '2025-11-05 05:22:23', '2025-11-05 05:22:23', 10, NULL, 10),
(53, 1, 'banners/L3R18Cm7mDCLdbNlPWwF27KMbp3VSVbsxGiV7nuR.png', 'https://admin.dailyopinion.in/admin/banners', NULL, 'test question', NULL, NULL, 'pending', 100, '2025-11-13 18:27:00', '2025-11-05 05:26:23', '2025-11-05 05:26:23', 3, NULL, 10),
(56, 1, 'banners/YAC2LhTNHQsQxKDamUMmxFaol9ZY3QitonAn3uI7.png', 'https://admin.dailyopinion.in/admin/banners', NULL, 'test question', '[\"true\",\"false\"]', 'A', 'declared', 100, '2025-11-06 18:56:00', '2025-11-05 05:54:14', '2025-11-05 06:06:40', 6, NULL, 10),
(57, 2, NULL, NULL, NULL, 'test', '[\"right\",\"wrong\"]', 'A', 'declared', 100, '2025-11-21 22:22:00', '2025-11-05 06:18:04', '2025-11-05 06:18:13', 8, NULL, 10),
(58, 4, NULL, NULL, '2026-01-07 10:06:00', 'test question one', '[\"aa\",\"bb\"]', NULL, 'pending', 100, '2026-01-08 15:35:00', '2026-01-07 04:35:21', '2026-01-07 04:35:21', 21, 1, 10);

-- --------------------------------------------------------

--
-- Table structure for table `reedems`
--

CREATE TABLE `reedems` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `rewards`
--

CREATE TABLE `rewards` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `image` varchar(255) DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `description` text DEFAULT NULL,
  `points` int(11) NOT NULL DEFAULT 0,
  `expiry_date` date DEFAULT NULL,
  `status` enum('active','inactive') NOT NULL DEFAULT 'active',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `rewards`
--

INSERT INTO `rewards` (`id`, `image`, `name`, `description`, `points`, `expiry_date`, `status`, `created_at`, `updated_at`) VALUES
(3, 'rewards/dcLt5VN4wagGmrBkwPEeTZlHhK0POzahvjOuTOxy.jpg', 'Big reward', 'this is big rewards', 200, '2025-10-20', 'active', '2025-10-17 00:39:03', '2025-10-17 00:39:03'),
(4, 'rewards/g6kA6gzK7epqngLcnYBoGFdtoPW4eMbfvoqY2a5U.jpg', 'Satyam Singh', 'this is dummy rewards', 500, '2025-10-28', 'active', '2025-10-17 00:47:56', '2025-10-23 02:19:16');

-- --------------------------------------------------------

--
-- Table structure for table `subcategories`
--

CREATE TABLE `subcategories` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `category_id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL,
  `description` text DEFAULT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `subcategories`
--

INSERT INTO `subcategories` (`id`, `category_id`, `name`, `description`, `status`, `created_at`, `updated_at`) VALUES
(1, 2, 'polotical', 'this is polotical question?', 1, '2025-10-15 07:24:04', '2025-10-15 07:24:04'),
(2, 6, 'stock price', 'this is stock questions.', 1, '2025-10-15 07:50:47', '2025-10-15 07:50:47'),
(3, 1, 'IPL Trivia', 'Test your IPL knowledge and player stats.', 1, '2025-10-16 06:40:39', '2025-10-16 06:40:39'),
(4, 1, 'World Cup Moments', 'Relive and discuss the best World Cup highlights.', 1, '2025-10-16 06:40:39', '2025-10-16 06:40:39'),
(5, 1, 'Cricket Legends', 'Talk about iconic cricketers and their legacy.', 1, '2025-10-16 06:40:39', '2025-10-16 06:40:39'),
(6, 1, 'Upcoming Tournaments', 'Predictions and discussions about upcoming cricket events.', 1, '2025-10-16 06:40:39', '2025-10-16 06:40:39'),
(7, 1, 'Fantasy League Tips', 'Share and get fantasy cricket team strategies.', 1, '2025-10-16 06:40:39', '2025-10-16 06:40:39'),
(8, 2, 'Elections 2025', 'Debate the upcoming elections and candidates.', 1, '2025-10-16 06:40:39', '2025-10-16 06:40:39'),
(9, 2, 'Government Policies', 'Discuss new policies and their impact.', 1, '2025-10-16 06:40:39', '2025-10-16 06:40:39'),
(10, 2, 'International Relations', 'Conversations about foreign policy and diplomacy.', 1, '2025-10-16 06:40:39', '2025-10-16 06:40:39'),
(11, 2, 'Political Scandals', 'Expose, discuss, and analyze recent political events.', 1, '2025-10-16 06:40:39', '2025-10-16 06:40:39'),
(12, 2, 'Public Opinion', 'Polls and discussions on trending political issues.', 1, '2025-10-16 06:40:39', '2025-10-16 06:40:39'),
(13, 3, 'Market Analysis', 'Discuss daily market movements and analysis.', 1, '2025-10-16 06:40:39', '2025-10-16 06:40:39'),
(14, 3, 'Top Gainers & Losers', 'Share insights on stocks performing well or poorly.', 1, '2025-10-16 06:40:39', '2025-10-16 06:40:39'),
(15, 3, 'Crypto Trends', 'Explore cryptocurrency trends and predictions.', 1, '2025-10-16 06:40:39', '2025-10-16 06:40:39'),
(16, 3, 'Investment Tips', 'Financial strategies and portfolio discussions.', 1, '2025-10-16 06:40:39', '2025-10-16 06:40:39'),
(17, 3, 'Startups & IPOs', 'Talk about new startups and upcoming IPOs.', 1, '2025-10-16 06:40:39', '2025-10-16 06:40:39'),
(18, 4, 'Movie Reviews', 'Share your opinions on latest movies and web series.', 1, '2025-10-16 06:40:39', '2025-10-16 06:40:39'),
(19, 4, 'Celebrity News', 'Stay updated with entertainment world gossip.', 1, '2025-10-16 06:40:39', '2025-10-16 06:40:39'),
(20, 4, 'Music & Artists', 'Discuss trending songs, albums, and artists.', 1, '2025-10-16 06:40:39', '2025-10-16 06:40:39'),
(21, 4, 'TV Shows', 'Review and discuss the most popular TV series.', 1, '2025-10-16 06:40:39', '2025-10-16 06:40:39'),
(22, 4, 'Awards & Events', 'Coverage and opinions on entertainment award shows.', 1, '2025-10-16 06:40:39', '2025-10-16 06:40:39');

-- --------------------------------------------------------

--
-- Table structure for table `sub_sub_categories`
--

CREATE TABLE `sub_sub_categories` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `subcategory_id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL,
  `description` text DEFAULT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `sub_sub_categories`
--

INSERT INTO `sub_sub_categories` (`id`, `subcategory_id`, `name`, `description`, `status`, `created_at`, `updated_at`) VALUES
(1, 21, 'Test', 'Test description', 1, '2026-01-06 06:13:34', '2026-01-06 06:13:34');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) NOT NULL,
  `remember_token` varchar(100) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `role` varchar(255) DEFAULT NULL,
  `permissions` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`permissions`))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `email_verified_at`, `password`, `remember_token`, `created_at`, `updated_at`, `role`, `permissions`) VALUES
(1, 'Test User', 'admin@gmail.com', NULL, '$2y$12$Lyp56FH/InxeUeS/P2OTju85knvqBC6Fs2KIrQ91Rz0gELXooWCyG', NULL, '2025-10-10 02:48:56', '2026-01-07 04:20:03', 'super_admin', '{\"dashboard\":\"1\",\"users\":\"1\",\"points\":\"1\",\"subcategories\":\"1\",\"rewards\":\"1\",\"reedem.pending\":\"1\",\"reedem.processing\":\"1\",\"reedem.complete\":\"1\",\"reedem.cancel\":\"1\",\"question\":\"1\",\"banners\":\"1\",\"faqs\":\"1\",\"roles\":\"1\",\"permissions\":\"1\",\"categories\":\"1\"}'),
(5, 'atul', 'atul@gmail.com', NULL, '$2y$12$8KNdEMJoJwpcMIhk981lkOkX7H5YsOa/aT0YbVxgd7Dm6rXZdgrKS', NULL, '2025-11-01 05:16:28', '2025-11-01 06:02:25', 'admin', '{\"dashboard\":\"1\",\"question\":\"1\",\"banners\":\"1\",\"faqs\":\"1\"}'),
(6, 'satyam', 'satyam@gmail.com', NULL, '$2y$12$LCupmdYSVaMCfuv1M9UFmulgFsnv7r8x0y.fb4GE7zvdlALT7lehy', NULL, '2025-11-01 05:18:43', '2025-11-01 05:58:58', 'admin', '[]');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `app_notifications`
--
ALTER TABLE `app_notifications`
  ADD PRIMARY KEY (`id`),
  ADD KEY `app_notifications_customer_id_index` (`customer_id`);

--
-- Indexes for table `banners`
--
ALTER TABLE `banners`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `customerfcmtokens`
--
ALTER TABLE `customerfcmtokens`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `customerfcmtokens_token_unique` (`token`),
  ADD KEY `customerfcmtokens_customer_id_foreign` (`customer_id`);

--
-- Indexes for table `customers`
--
ALTER TABLE `customers`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `customers_phone_unique` (`phone`),
  ADD UNIQUE KEY `customers_email_unique` (`email`);

--
-- Indexes for table `customer_address`
--
ALTER TABLE `customer_address`
  ADD PRIMARY KEY (`id`),
  ADD KEY `customer_address_customer_id_foreign` (`customer_id`);

--
-- Indexes for table `customer_answers`
--
ALTER TABLE `customer_answers`
  ADD PRIMARY KEY (`id`),
  ADD KEY `customer_answers_customer_id_foreign` (`customer_id`),
  ADD KEY `customer_answers_question_id_foreign` (`question_id`);

--
-- Indexes for table `customer_bank_details`
--
ALTER TABLE `customer_bank_details`
  ADD PRIMARY KEY (`id`),
  ADD KEY `customer_bank_details_customer_id_foreign` (`customer_id`);

--
-- Indexes for table `customer_redeem_requests`
--
ALTER TABLE `customer_redeem_requests`
  ADD PRIMARY KEY (`id`),
  ADD KEY `customer_redeem_requests_customer_id_foreign` (`customer_id`),
  ADD KEY `customer_redeem_requests_reward_id_foreign` (`reward_id`);

--
-- Indexes for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`);

--
-- Indexes for table `faqs`
--
ALTER TABLE `faqs`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `password_reset_tokens`
--
ALTER TABLE `password_reset_tokens`
  ADD PRIMARY KEY (`email`);

--
-- Indexes for table `personal_access_tokens`
--
ALTER TABLE `personal_access_tokens`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `personal_access_tokens_token_unique` (`token`),
  ADD KEY `personal_access_tokens_tokenable_type_tokenable_id_index` (`tokenable_type`,`tokenable_id`);

--
-- Indexes for table `points`
--
ALTER TABLE `points`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `questions`
--
ALTER TABLE `questions`
  ADD PRIMARY KEY (`id`),
  ADD KEY `questions_category_id_foreign` (`category_id`),
  ADD KEY `questions_subcategory_id_foreign` (`subcategory_id`);

--
-- Indexes for table `reedems`
--
ALTER TABLE `reedems`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `rewards`
--
ALTER TABLE `rewards`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `subcategories`
--
ALTER TABLE `subcategories`
  ADD PRIMARY KEY (`id`),
  ADD KEY `subcategories_category_id_index` (`category_id`),
  ADD KEY `subcategories_status_index` (`status`);

--
-- Indexes for table `sub_sub_categories`
--
ALTER TABLE `sub_sub_categories`
  ADD PRIMARY KEY (`id`),
  ADD KEY `sub_sub_categories_subcategory_id_foreign` (`subcategory_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `app_notifications`
--
ALTER TABLE `app_notifications`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `banners`
--
ALTER TABLE `banners`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `customerfcmtokens`
--
ALTER TABLE `customerfcmtokens`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `customers`
--
ALTER TABLE `customers`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `customer_address`
--
ALTER TABLE `customer_address`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `customer_answers`
--
ALTER TABLE `customer_answers`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `customer_bank_details`
--
ALTER TABLE `customer_bank_details`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `customer_redeem_requests`
--
ALTER TABLE `customer_redeem_requests`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `faqs`
--
ALTER TABLE `faqs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=35;

--
-- AUTO_INCREMENT for table `personal_access_tokens`
--
ALTER TABLE `personal_access_tokens`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `points`
--
ALTER TABLE `points`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `questions`
--
ALTER TABLE `questions`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=59;

--
-- AUTO_INCREMENT for table `reedems`
--
ALTER TABLE `reedems`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `rewards`
--
ALTER TABLE `rewards`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `subcategories`
--
ALTER TABLE `subcategories`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;

--
-- AUTO_INCREMENT for table `sub_sub_categories`
--
ALTER TABLE `sub_sub_categories`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `app_notifications`
--
ALTER TABLE `app_notifications`
  ADD CONSTRAINT `app_notifications_customer_id_foreign` FOREIGN KEY (`customer_id`) REFERENCES `customers` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `customerfcmtokens`
--
ALTER TABLE `customerfcmtokens`
  ADD CONSTRAINT `customerfcmtokens_customer_id_foreign` FOREIGN KEY (`customer_id`) REFERENCES `customers` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `customer_address`
--
ALTER TABLE `customer_address`
  ADD CONSTRAINT `customer_address_customer_id_foreign` FOREIGN KEY (`customer_id`) REFERENCES `customers` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `customer_answers`
--
ALTER TABLE `customer_answers`
  ADD CONSTRAINT `customer_answers_customer_id_foreign` FOREIGN KEY (`customer_id`) REFERENCES `customers` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `customer_answers_question_id_foreign` FOREIGN KEY (`question_id`) REFERENCES `questions` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `customer_bank_details`
--
ALTER TABLE `customer_bank_details`
  ADD CONSTRAINT `customer_bank_details_customer_id_foreign` FOREIGN KEY (`customer_id`) REFERENCES `customers` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `customer_redeem_requests`
--
ALTER TABLE `customer_redeem_requests`
  ADD CONSTRAINT `customer_redeem_requests_customer_id_foreign` FOREIGN KEY (`customer_id`) REFERENCES `customers` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `customer_redeem_requests_reward_id_foreign` FOREIGN KEY (`reward_id`) REFERENCES `rewards` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `questions`
--
ALTER TABLE `questions`
  ADD CONSTRAINT `questions_category_id_foreign` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `questions_subcategory_id_foreign` FOREIGN KEY (`subcategory_id`) REFERENCES `subcategories` (`id`) ON DELETE SET NULL;

--
-- Constraints for table `subcategories`
--
ALTER TABLE `subcategories`
  ADD CONSTRAINT `subcategories_category_id_foreign` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `sub_sub_categories`
--
ALTER TABLE `sub_sub_categories`
  ADD CONSTRAINT `sub_sub_categories_subcategory_id_foreign` FOREIGN KEY (`subcategory_id`) REFERENCES `subcategories` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
