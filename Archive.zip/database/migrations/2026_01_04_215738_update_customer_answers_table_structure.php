<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        // Step 1: Drop the status column
        Schema::table('customer_answers', function (Blueprint $table) {
            $table->dropColumn('status');
        });
        
        // Step 2: Add is_correct column
        Schema::table('customer_answers', function (Blueprint $table) {
            $table->boolean('is_correct')->nullable()->after('points');
        });
        
        // Step 3: Rename answer to selected_option
        Schema::table('customer_answers', function (Blueprint $table) {
            $table->renameColumn('answer', 'selected_option');
        });
        
        // Step 4: Rename points to points_awarded
        Schema::table('customer_answers', function (Blueprint $table) {
            $table->renameColumn('points', 'points_awarded');
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        // Reverse step 4
        Schema::table('customer_answers', function (Blueprint $table) {
            $table->renameColumn('points_awarded', 'points');
        });
        
        // Reverse step 3
        Schema::table('customer_answers', function (Blueprint $table) {
            $table->renameColumn('selected_option', 'answer');
        });
        
        // Reverse step 2
        Schema::table('customer_answers', function (Blueprint $table) {
            $table->dropColumn('is_correct');
        });
        
        // Reverse step 1
        Schema::table('customer_answers', function (Blueprint $table) {
            $table->enum('status', ['Pending','Yes','No'])->default('Pending');
        });
    }
};
