<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('translations_cache', function (Blueprint $table) {
            $table->id();
            $table->string('translatable_type'); // Model type (Question, Answer, etc.)
            $table->unsignedBigInteger('translatable_id'); // Model ID
            $table->string('field_name'); // Field being translated (question_text, answer_text, etc.)
            $table->string('source_language', 10)->default('en'); // Original language
            $table->string('target_language', 10); // Target translation language
            $table->text('original_content'); // Original text
            $table->text('translated_content'); // Translated text
            $table->timestamp('translated_at')->useCurrent();
            $table->timestamps();

            // Composite index for fast lookups
            $table->index(['translatable_type', 'translatable_id', 'field_name', 'target_language'], 'translation_lookup_idx');
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('translations_cache');
    }
};
