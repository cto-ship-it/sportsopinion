<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::table('questions', function (Blueprint $table) {
            $table->unsignedBigInteger('sub_sub_category_id')->nullable()->after('subcategory_id');
            $table->timestamp('publish_at')->nullable()->after('banner_link');
            
            // Optional: Add foreign key constraint if sub_sub_categories table exists
            // $table->foreign('sub_sub_category_id')->references('id')->on('sub_sub_categories')->nullOnDelete();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::table('questions', function (Blueprint $table) {
            $table->dropColumn(['sub_sub_category_id', 'publish_at']);
        });
    }
};
