<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::table('rewards', function (Blueprint $table) {
            // Add new columns only if they don't already exist
            if (!Schema::hasColumn('rewards', 'image')) {
                $table->string('image')->nullable()->after('id');
            }
            if (!Schema::hasColumn('rewards', 'name')) {
                $table->string('name')->after('image');
            }
            if (!Schema::hasColumn('rewards', 'description')) {
                $table->text('description')->nullable()->after('name');
            }
            if (!Schema::hasColumn('rewards', 'points')) {
                $table->integer('points')->default(0)->after('description');
            }
            if (!Schema::hasColumn('rewards', 'expiry_date')) {
                // Make it nullable to avoid 0000-00-00 issues
                $table->date('expiry_date')->nullable()->after('points');
            }
            if (!Schema::hasColumn('rewards', 'status')) {
                $table->enum('status', ['active', 'inactive'])->default('active')->after('expiry_date');
            }
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::table('rewards', function (Blueprint $table) {
            $table->dropColumn([
                'image',
                'name',
                'description',
                'points',
                'expiry_date',
                'status',
            ]);
        });
    }
};
