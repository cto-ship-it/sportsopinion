<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('customer_redeem_requests', function (Blueprint $table) {
            $table->id();
            $table->foreignId('customer_id')->constrained()->onDelete('cascade');
            $table->foreignId('reward_id')->constrained('rewards')->onDelete('cascade');
            $table->integer('points')->unsigned(); // number of points to redeem
            $table->enum('status', ['pending', 'approved', 'complete','cancel'])->default('pending');
            $table->string('remarks')->nullable(); // optional admin note or rejection reason
            $table->timestamp('approved_at')->nullable(); // when approved
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('customer_redeem_requests');
    }
};
