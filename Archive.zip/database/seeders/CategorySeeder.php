<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\Category;
use Illuminate\Support\Str;

class CategorySeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        $categories = [
            [
                'name' => 'Cricket',
                'description' => 'Test your cricket knowledge and share your opinion on the latest matches & players.',
            ],
            [
                'name' => 'POL',
                'description' => 'Stay engaged with political happenings and voice your stand.',
            ],
            [
                'name' => 'Stock Market',
                'description' => 'Keep up with the market trends, companies, and financial news.',
            ],
            [
                'name' => 'Entertainment',
                'description' => 'From movies to celebrities share your take on what’s trending.',
            ],
        ];

        foreach ($categories as $data) {
            Category::updateOrCreate(
                ['name' => $data['name']], // Prevent duplicates
                [
                    'description' => $data['description'],
                ]
            );
        }
    }
}
